import { actionTypes } from "../actions/ReferralActions";

const initialState = {};

const referral = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.REFERRAL_LINKS:
      return {
        ...state, referral_links: action.payload
      };
    // case actionTypes.FRIENDS_REFERRAL_LIST:
    //   return {
    //     ...state, friendsList: action.payload
    //   };
    // case actionTypes.COMMISSION_HISTORY_LIST:
    //   return {
    //     ...state, commissionList: action.payload
    //   };
    case actionTypes.CUSTOM_PLANS:
      return {
        ...state, customPlans: action.payload
      };
    default:

      return state;
  }
}
export default referral;
