import { actionTypes } from "../actions/OrderActions";

const initialState = {};

const orders = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.ORDERS_HISTORY:
      return {
        ...state, ordersHistory: action.payload
      };
      case actionTypes.TRADE_HISTORY:
      return {
        ...state, tradeHistory: action.payload
      };
    case actionTypes.PAIR_LIST:
      return {
        ...state, pairList: action.payload
      };
    // case actionTypes.COMMISSION_HISTORY_LIST:
    //   return {
    //     ...state, commissionList: action.payload
    //   };
    // case actionTypes.CUSTOM_PLANS:
    //   return {
    //     ...state, customPlans: action.payload
    //   };
    default:

      return state;
  }
}
export default orders;
