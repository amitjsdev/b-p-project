import { actionTypes } from "../actions/WalletActions";

const initialState = {
    walletbalance: []
};

const walletbalance = (state = initialState, action) => {
  switch (action.type) {
      
    case actionTypes.GET_USER_BALANCE_REQUEST:
      return {
        ...state,walletbalance: action.payload
        
      };
      case actionTypes.GET_USER_TOTAL_BALANCE:
        return {
          ...state,walletTotalbalance: action.payload
          
        };
      
    default:
      return state;
  }
};

export default walletbalance;
