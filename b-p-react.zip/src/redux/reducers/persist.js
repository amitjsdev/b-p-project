import { actionTypes } from "../actions/PersistActions";

const initialState = {
  //0 never login
  // 1 already logins
  //2 default value
  isUserFirstTimeLogin: 2,
  pair: "",
  theme:false
};

const persist = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.UPDATE_FIRST_TIME_LOGIN_STATE:
      return {
        ...state,
        isUserFirstTimeLogin: action.payload,
      };
      case actionTypes.CHNAGE_THEME:
        return Object.assign({}, state, {
          theme: (state.theme = action.data),
        });
  
    case actionTypes.SAVE_PAIR:
      return {
        ...state,
        pair: action.payload,
      };
    default:
      return state;
  }
};

export default persist;
