import { actionTypes } from "../actions/ExchangeActions";

const initialState = {
  theme: false,
  pairList: [],
  seletedPair: "usdt_btc",
  pair1: "",
  pair2: "",
  lastPrice: 0, //Last Price
  statChange: 0, //24H Change
  statChangeprcent: 0, //24H Change percetage
  statHigh: 0, //24H High
  statLow: 0, //24H Low
  statVolume: 0, //24H Volume

  statOpen: 0, // stat open
  mintradefee: 0,
  tradebuyfee: 0,
  tradesellfee: 0,
  lastPriceSingle: 0,
  sidePairStat: [],
  orderresponse: "",
  tradeOrder: [],
  walletbuybalance: 0,
  walletsellbalance: 0,
  buyOrder: [],
  sellOrder: [],
  openOrder: [],
  completeOrder: [],
  graphData: {},
  amount_decimal: 0,
  price_decimal: 0,
};

const exchange = (state = initialState, action) => {
  //  if(action.type ==actionTypes.LASTPRICE){
  //    alert(action.price)
  //  }
  switch (action.type) {
    case actionTypes.STATE_DATA_UPDATE:
      
      return {
        ...state,
        [action.payload.prop]: action.payload.value,
      };
    case actionTypes.SAVE_PAIR_LIST:
      return {
        ...state,
        pairList: action.payload,
      };
    case actionTypes.SIDEPAIRSTATS:
      return Object.assign({}, state, {
        ...state,
        sidePairStat: (state.sidePairStat = { ...action.data }),
      });
    case actionTypes.LASTPRICESINGLE:
      return Object.assign({}, state, {
        lastPriceSingle: (state.lastPriceSingle = action.price),
      });

    case actionTypes.LASTPRICE:
      return {
        ...state,
        lastPrice: action.price,
      };

    case actionTypes.TRADEORDER:
      return Object.assign({}, state, {
        tradeOrder: (state.tradeOrder = action.data),
      });
    case actionTypes.WALLETBUYBALANCE:
      return Object.assign({}, state, {
        walletbuybalance: (state.walletbuybalance = action.price),
      });
    case actionTypes.WALLETSELLBALANCE:
      return Object.assign({}, state, {
        walletsellbalance: (state.walletsellbalance = action.price),
      });
    case actionTypes.BUYORDER:
      return Object.assign({}, state, {
        buyOrder: [...action.data],
      });
    case actionTypes.OPENORDER:
      // return Object.assign({}, state, {
      // openOrder: state.openOrder = action.data
      // });
      return {
        ...state,
        openOrder: [...action.data],
      };
    case actionTypes.SELLORDER:
      // return Object.assign({}, state, {
      //   sellOrder: state.sellOrder = action.data
      // });
      return {
        ...state,
        sellOrder: [...action.data],
      };
    case actionTypes.COMPLETEORDER:
      return Object.assign({}, state, {
        completeOrder: (state.completeOrder = action.data),
      });
    case actionTypes.STATVOLUME:
      return  {
        ...state,
        statVolume: action.data,
      };
    case actionTypes.STATHIGH:
      return Object.assign({}, state, {
        statHigh: (state.statHigh = action.data),
      });
    case actionTypes.STATLOW:
      return Object.assign({}, state, {
        statLow: (state.statLow = action.data),
      });
    case actionTypes.STATCHANGE:
      return Object.assign({}, state, {
        statChange: (state.statChange = action.data),
      });
    case actionTypes.STATCHANGEPERCEN:
      return Object.assign({}, state, {
        statChangeprcent: (state.statChangeprcent = action.data),
      });
    case actionTypes.CHNAGE_THEME:
      return Object.assign({}, state, {
        theme: (state.theme = action.data),
      });

    case actionTypes.SAVE_GRAPH:
      return Object.assign({}, state, {
        graphData: (state.graphData = { ...action.data }),
      });

    default:
      return state;
  }
};

export default exchange;
