import { ReferralService } from "../../services/ReferralService";
import { startLoading, stopLoading } from "./LoadingActions";
import { toast } from "../../components/Toast/Toast";
import { AUTH_TOKEN_KEY } from "../../constant";
import {removeToken,setLocalStorage,getToken} from '../../Helpers/storageHelper';



/** seting action types */
export const actionTypes = {
  REFERRAL_LINKS: "REFERRAL_LINKS",
  FRIENDS_REFERRAL_LIST: "FRIENDS_REFERRAL_LIST",
  COMMISSION_HISTORY_LIST: 'COMMISSION_HISTORY_LIST',
  CUSTOM_PLANS: 'CUSTOM_PLANS',
};

export function get_Custom_plans(data) {
  return {
    type: actionTypes.CUSTOM_PLANS,
    payload: data
  };
}

export function getReferralLinks(data) {
  return {
    type: actionTypes.REFERRAL_LINKS,
    payload: data
  };
}

export function getFreindReferral(data) {
  return {
    type: actionTypes.FRIENDS_REFERRAL_LIST,
    payload: data
  };
}

export function getCommissionHistory(data) {
  return {
    type: actionTypes.COMMISSION_HISTORY_LIST,
    payload: data
  };
}

export const getReferralToken = data => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      ReferralService.getReferralToken(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          //toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const getReferralHistory = data => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      ReferralService.getReferralHistory(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
         // toast.success(res.data.message);
          dispatch(stopLoading());
          dispatch(getReferralLinks(res.data.data));
          resolve(res)
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const getCustomPlans = () => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      ReferralService.getCustomPlans({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          //toast.success(res.data.message);
          dispatch(stopLoading());
          dispatch(get_Custom_plans(res.data.data));
          resolve(res)
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};
