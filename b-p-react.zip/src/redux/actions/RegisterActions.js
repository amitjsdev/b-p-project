import { ENCRYPT_KEY } from "../../constant";
import { UserService } from "../../services/UserService";

/** seting action types */
export const actionTypes = {
  REGISTER_USER_REQUEST: "REGISTER_USER_REQUEST",
  REGISTER_USER_SUCCESS: "REGISTER_USER_SUCCESS",
  REGISTER_USER_ERROR: "REGISTER_USER_ERROR",
  REGISTER_FORM_UPDATE: "REGISTER_FORM_UPDATE",
};

/*
 * Action creators for login
 */

export function saveRegisterData(data) {
  return {
    type: actionTypes.REGISTER_FORM_UPDATE,
    payload: data,
  };
}

export function userRegister(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      UserService.login(data)
        .then((res) => {
          //   toast.success(res.data.message);

          resolve(res);
        })
        .catch((ex) => {
          reject(ex);
        });
    });
}


export function requestEncryption(data) {
  
  let CryptoJS = require("crypto-js");
  // Encrypt
  let ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), ENCRYPT_KEY);
  return ciphertext.toString();

  // // Decrypt
  // var bytes  = CryptoJS.AES.decrypt(ciphertext.toString(), ENCRYPT_KEY);
  // var plaintext = bytes.toString(CryptoJS.enc.Utf8);
  // console.log('ciphertext--',plaintext)
  // debugger
}