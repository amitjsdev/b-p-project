import { WalletService } from '../../services/WalletService';
import { startLoading, stopLoading } from './LoadingActions';
import { toast } from '../../components/Toast/Toast';
import { AUTH_TOKEN_KEY } from '../../constant';
import {removeToken,setLocalStorage,getToken} from '../../Helpers/storageHelper';
import { string } from 'yup/lib/locale';
/** seting action types */
export const actionTypes = {
  GET_USER_BALANCE_REQUEST: 'GET_USER_BALANCE_REQUEST',
  GET_USER_TOTAL_BALANCE: 'GET_USER_TOTAL_BALANCE'
};

/*
 * Action creators for login
 */

export function saveUserBalance(data) {
  return {
    type: actionTypes.GET_USER_BALANCE_REQUEST,
    payload : data
  };
}

export function saveTotalBalance(data) {
  return {
    type: actionTypes.GET_USER_TOTAL_BALANCE,
    payload : data
  };
}


export function getSingleCoinHistory(coin,networkName) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getSingleCoinHistory({coinToken:coin,network:networkName},{
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getWalletHistory() {
    return (dispatch, getState) =>
      new Promise((resolve, reject) => {
        dispatch(startLoading());
        WalletService.getWalletHistory({
          jwt: getToken(AUTH_TOKEN_KEY),
        })
          .then((res) => {
            dispatch(stopLoading());
            resolve(res);
          })
          .catch((ex) => {
            if(ex.status == 408){
              toast.error('Session timeout');
              removeToken(AUTH_TOKEN_KEY, '', 1);
              setLocalStorage('')
              window.location.replace(`/login`);
            }
            toast.error(ex.data.message);
            dispatch(stopLoading());
  
            reject(ex);
          });
      });
  }

export function getUserBalance(currencyPreferences) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getUserBalance(currencyPreferences,{
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(saveUserBalance(res.data.data));
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function checkBreachedTokens() {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.checkBreachedTokens({
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getActiveCoins(coin) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getActiveCoins(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}
export function getCoinBalance(coin) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getUserBalanceParticularCoin(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          //toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getTradePairList() {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getTradePairList({
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getCoinDepositAddress(coin,network) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getCoinDepositAddress(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      },network)
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getCoinNetworkList(coin) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getCoinNetworkList(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getDepositTxnHistory(coin,network) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getDepositTxnHistory(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      },network)
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}
export function getWithdrawTxnHistory(coin) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getWithdrawTxnHistory(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getUserBalanceParticularCoin(coin,network) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getUserBalanceParticularCoin(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      },network)
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
         //S toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getCoinContractAddress() {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getCoinContractAddress({
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getCurrencyDetails(coin,network) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getCurrencyDetails(coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      },network)
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function withdrawRequestValidation(data, coin) {
  
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.withdrawRequestValidation(data, coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}
export function withdrawRequest(data, coin) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.withdrawRequest(data, coin, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          toast.success(res.data.message);

          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getWithdrawDepositTxnHistory(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.getWithdrawDepositTxnHistory(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());

          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getCurrentPrice(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      WalletService.getCurrentPrice(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          //toast.error(ex.data.message);
          reject(ex);
        });
    });
}

export function getCoinDetail(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      WalletService.getCoinDetail(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
         // toast.error(ex.data.message);
          reject(ex);
        });
    });
}

export function getSwapHistory(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      WalletService.getSwapHistory(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          reject(ex);
        });
    });
}

export function getSwapPairs(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      WalletService.getSwapPairs(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          reject(ex);
        });
    });
}



export function swappingOrder(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      WalletService.swappingOrder(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          if(res?.data.code == 400){
            toast.error(res?.data?.msg);
          }else{
          toast.success(res.data.message);
          }
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            // toast.error('Session timeout');
            // removeToken(AUTH_TOKEN_KEY, '', 1);
            // setLocalStorage('')
            // window.location.replace(`/login`);
          }
          if(ex.data.code == 400){
            toast.error(ex.data.msg);
          }
          // console.log('exexex',ex?.data?.msg,ex.data.code)
          dispatch(stopLoading());

          reject(ex);
        });
    });
}