import { AUTH_TOKEN_KEY, ENCRYPT_KEY, DECRYPT_KEY } from "../../constant";
import { ExchangeService } from "../../services/ExchangeService";
import { startLoading, stopLoading } from "./LoadingActions";
import {removeToken,setLocalStorage,getToken} from '../../Helpers/storageHelper';
import {toast} from '../../components/Toast/Toast'

/** seting action types */
export const actionTypes = {
  SAVE_PAIR_LIST: "SAVE_PAIR_LIST",
  SAVE_COIN_STAT: "SAVE_COIN_STAT",
  STATE_DATA_UPDATE: "STATE_DATA_UPDATE",
  SIDEPAIRSTATS: "SIDEPAIRSTATS",
  LASTPRICESINGLE: "LASTPRICESINGLE",
  LASTPRICE: "LASTPRICE",
  TRADEORDER: "TRADEORDER",
  WALLETBUYBALANCE: "WALLETBUYBALANCE",
  WALLETSELLBALANCE: "WALLETSELLBALANCE",
  BUYORDER: "BUYORDER",
  OPENORDER: "OPENORDER",
  SELLORDER: "SELLORDER",
  COMPLETEORDER: "COMPLETEORDER",
  STATVOLUME: "STATVOLUME",
  STATHIGH: "STATHIGH",
  STATLOW: "STATLOW",
  STATCHANGE: "STATCHANGE",
  STATCHANGEPERCEN: "STATCHANGEPERCEN",
  CHNAGE_THEME: "CHNAGE_THEME",
  SAVE_GRAPH: "SAVE_GRAPH",
};

/*
 * Action creators for login

 */
export function saveGraphData(data) {
  return {
    type: actionTypes.SAVE_GRAPH,
    data: data,
  };
}

export function changeTheme(data) {
  return {
    type: actionTypes.CHNAGE_THEME,
    data: data,
  };
}
export function saveSellOrder(data) {
  return {
    type: actionTypes.SELLORDER,
    data: data,
  };
}
export function saveStatChange(data) {
  return {
    type: actionTypes.STATCHANGE,
    data: data,
  };
}
export function saveStatChangePercentage(data) {
  return {
    type: actionTypes.STATCHANGEPERCEN,
    data: data,
  };
}
export function saveStatLow(data) {
  return {
    type: actionTypes.STATLOW,
    data: data,
  };
}
export function saveStatHigh(data) {
  return {
    type: actionTypes.STATHIGH,
    data: data,
  };
}

export function saveStatVolume(data) {
  return {
    type: actionTypes.STATVOLUME,
    data: data,
  };
}

export function saveCompletedOrders(data) {
  return {
    type: actionTypes.COMPLETEORDER,
    data: data,
  };
}

export function saveOpenOrders(data) {
  return {
    type: actionTypes.OPENORDER,
    data: data,
  };
}

export function saveBuyOrders(data) {
  return {
    type: actionTypes.BUYORDER,
    data: data,
  };
}
export function saveBuyWalletBalance(data) {
  return {
    type: actionTypes.WALLETBUYBALANCE,
    price: data,
  };
}
export function saveSellWalletBalance(data) {
  return {
    type: actionTypes.WALLETSELLBALANCE,
    price: data,
  };
}
export function saveTradeOrder(data) {
  return {
    type: actionTypes.TRADEORDER,
    data: data,
  };
}
export function saveLastPrice(price) {
  return {
    type: actionTypes.LASTPRICE,
    price: price,
  };
}
export function saveLastPriceSingle(price) {
  return {
    type: actionTypes.LASTPRICESINGLE,
    price: price,
  };
}

export function saveStatData(data) {
  return {
    type: actionTypes.STATE_DATA_UPDATE,
    payload: data,
  };
}

export function saveSidePairData(data) {
  return {
    type: actionTypes.SIDEPAIRSTATS,
    data: data,
  };
}

export function savePairList(data) {
  return {
    type: actionTypes.SAVE_PAIR_LIST,
    payload: data,
  };
}

export function saveCoinStat(data) {
  return {
    type: actionTypes.SAVE_COIN_STAT,
    payload: data,
  };
}

export function getPairList() {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      ExchangeService.getPairList()
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}

export function getCoinStat(params) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      ExchangeService.getCoinStat()
        .then((res) => {
          //   toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}

export function getCommodityPrice(params) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      ExchangeService.getCommodityPrice()
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}

/// Buy Sell orders ///

export function placeOrder(data) {

  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      ExchangeService.placeOrder(
        { data: requestEncryption(data) },
        {
          jwt: getToken(AUTH_TOKEN_KEY),
        }
      )
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}

export function requestEncryption(data) {
  let CryptoJS = require("crypto-js");
  // Encrypt
  let ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), ENCRYPT_KEY);

  return ciphertext.toString();

  // // Decrypt
  // var bytes  = CryptoJS.AES.decrypt(ciphertext.toString(), '2ed5ebe2294ecd0e0f08eab7690d2a6aa98');
  // var plaintext = bytes.toString(CryptoJS.enc.Utf8);
  // console.log(plaintext);
  // debugger
}

export function tradeOrderList(data) {
  return (dispatch) =>
    new Promise((resolve, reject) => {
      // dispatch(startLoading()); //temp stopped

      ExchangeService.tradeOrderList(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}

export function getTotalSupply(coin) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      ExchangeService.getTotalSupply(coin)
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}

export function CancelOpenOrder(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      ExchangeService.CancelOpenOrder(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          reject(ex);
          dispatch(stopLoading());
        });
    });
}
