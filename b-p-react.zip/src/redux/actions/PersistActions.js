import { justPairSwap } from "../../Helpers/Normailize";

/** seting action types */
export const actionTypes = {
  UPDATE_FIRST_TIME_LOGIN_STATE: "UPDATE_FIRST_TIME_LOGIN_STATE",
  SAVE_PAIR: "SAVE_PAIR",
  CHNAGE_THEME:"CHNAGE_THEME"
};

/*
 * Action creators
 */
export function changeTheme(data) {
  return {
    type: actionTypes.CHNAGE_THEME,
    data: data,
  };
}

export function updateFirstTimeLoginState(data) {
  return {
    type: actionTypes.UPDATE_FIRST_TIME_LOGIN_STATE,
    payload: data,
  };
}

export function savePairPersist(data) {
  return {
    type: actionTypes.SAVE_PAIR,
    payload: justPairSwap(data),
  };
}
