import { UserService } from '../../services/UserService';
import { SecurityService } from '../../services/SecurityService';
import { AUTH_TOKEN_KEY } from "../../constant";
import { startLoading, stopLoading } from './LoadingActions';
import {toast} from '../../components/Toast/Toast'
import {removeToken,setLocalStorage,getToken} from '../../Helpers/storageHelper';

// import { AUTH_TOKEN_KEY } from '../../constant';
// import { setToken } from '../../Helpers/storageHelper';

/** seting action types */
export const actionTypes = {
  LOGIN_USER_REQUEST: 'LOGIN_USER_REQUEST',
  LOGIN_USER_SUCCESS: 'LOGIN_USER_SUCCESS',
  LOGIN_USER_ERROR: 'LOGIN_USER_ERROR',
};

/*
 * Action creators for login
 */

// export function loginUserRequest() {
//   return {
//     type: actionTypes.LOGIN_USER_REQUEST,
//   };
// }

export const getUserInfoAfterLoginOnly = (token) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getUserInfo({
        jwt: token,
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};
export const token_verification = (data) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.token_verification(data, {
        jwt: data.userToken,
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const verifygoogle2fa = (data) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.verifygoogle2fa(data, {
        jwt: data.userToken,
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export const token_verification_google = (data) => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.token_verification_google(data, {
        jwt: data.userToken,
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export const send2faEmailVerification = (token) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.send2faEmailVerification({
        jwt: token,
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export function userLogin(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.login(data)
        .then((res) => {
          dispatch(stopLoading());
          if(res.data.is_email_active == 1 || res.data.is_google_2fa_active == 1){
          }else{
            toast.success(res.data.message);
          }
          // if(res.data.isUserLogin==1){
          // setToken(AUTH_TOKEN_KEY, res.data.JwtToken,1); // 6 hrs

          // }
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function verifyUserEmail(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.verifyUsersEmail(data)
        .then((res) => {
          dispatch(stopLoading());
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function verifyUserDevice(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.verifyUserDevice(data)
        .then((res) => {
          dispatch(stopLoading());
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function userRegistration(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.userRegistrationApi(data)
        .then((res) => {
          dispatch(stopLoading());
          // setToken(AUTH_TOKEN_KEY, res.data.JwtToken);
          // we will save token after successfully
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function forgotUserPassword(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.forgetPassword(data)
        .then((res) => {
          dispatch(stopLoading());
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function resetUserPassword(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.resetPassword(data)
        .then((res) => {
          dispatch(stopLoading());
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function checkEmailAlreadyExist(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      // dispatch(startLoading())
      UserService.checkEmailExist(data)
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function checkMobileAlreadyExist(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      // dispatch(startLoading())
      UserService.checkMobileExist(data)
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function getUserIpAddress() {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      UserService.getIp()
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}

export function resendVerificationMail(data) {
  return (dispatch, getState) =>
    new Promise((resolve, reject) => {
      dispatch(startLoading());
      UserService.resendVerificationMail(data)
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message);
          dispatch(stopLoading());

          reject(ex);
        });
    });
}
