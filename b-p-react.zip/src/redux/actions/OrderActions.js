import { OrderServices } from "../../services/OrderServices";
import { startLoading, stopLoading } from "./LoadingActions";
import { toast } from "../../components/Toast/Toast";
import { AUTH_TOKEN_KEY } from "../../constant";
import {removeToken,setLocalStorage,getToken} from '../../Helpers/storageHelper';

/** seting action types */
export const actionTypes = {
  ORDERS_HISTORY: "ORDERS_HISTORY",
  PAIR_LIST: "PAIR_LIST",
  TRADE_HISTORY: "TRADE_HISTORY",

  //   FRIENDS_REFERRAL_LIST: "FRIENDS_REFERRAL_LIST",
  //   COMMISSION_HISTORY_LIST: 'COMMISSION_HISTORY_LIST',
  //   CUSTOM_PLANS: 'CUSTOM_PLANS',
};

export function getOrderHistory(data) {
  return {
    type: actionTypes.ORDERS_HISTORY,
    payload: data,
  };
}
export function getPiarListData(data) {
  return {
    type: actionTypes.PAIR_LIST,
    payload: data,
  };
}

export function getTradeList(data) {
  return {
    type: actionTypes.TRADE_HISTORY,
    payload: data,
  };
}

// export function getReferralLinks(data) {
//   return {
//     type: actionTypes.REFERRAL_LINKS,
//     payload: data
//   };
// }

// export function getFreindReferral(data) {
//   return {
//     type: actionTypes.FRIENDS_REFERRAL_LIST,
//     payload: data
//   };
// }

// export function getCommissionHistory(data) {
//   return {
//     type: actionTypes.COMMISSION_HISTORY_LIST,
//     payload: data
//   };
// }


export const orderHistoryCsv = (data) => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      OrderServices.orderHistoryCsv(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          //toast.success(res.data.message);
          dispatch(stopLoading());
       //   dispatch(getPiarListData(res.data.data));
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex.data.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export const getPairList = (data) => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      OrderServices.getPairList(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          //toast.success(res.data.message);
          dispatch(stopLoading());
          dispatch(getPiarListData(res.data.data));
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex.data.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export const getOrderList = (data) => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      OrderServices.getOrderList(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          //toast.success(res.data.message);
          dispatch(stopLoading());
          dispatch(getOrderHistory(res.data));
          resolve(res);
        })
        .catch((ex) => {
          // if(ex.status == 408){
          //   toast.error('Session timeout');
          //   removeToken(AUTH_TOKEN_KEY, '', 1);
          //   setLocalStorage('')
          //   window.location.replace(`/login`);
          // }
          toast.error(ex?.data?.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export const getTradeHistory = (data) => {
  return (dispatch, getState) => {
    let state = getState();
    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      OrderServices.getTradeHistory(data, {
        jwt: getToken(AUTH_TOKEN_KEY),
      })
        .then((res) => {
          //toast.success(res.data.message);
          dispatch(stopLoading());
          dispatch(getTradeList(res.data));
          resolve(res);
        })
        .catch((ex) => {
          if(ex.status == 408){
            toast.error('Session timeout');
            removeToken(AUTH_TOKEN_KEY, '', 1);
            setLocalStorage('')
            window.location.replace(`/login`);
          }
          toast.error(ex?.data?.message);
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};
