import { fetch } from "./Fetch";
import { API_HOST } from "../constant";

//Api s
const getOrderList = (data, options) => {
  return fetch(
    "post",
    `${API_HOST}trading/trade/list-order`,
    data,
    options,
    ""
  );
};

const getPairList = (options) => {
  return fetch("get", `${API_HOST}trading/trade/pair-list`, {}, options, "");
};

const getTradeHistory = (data,options) => {
  return fetch(
    "post",
    `${API_HOST}trading/trade/trade-history`,
    data,
    options,
    ""
  );
};

const orderHistoryCsv = (data,options) => {
  return fetch(
    "post",
    `${API_HOST}trading/trade/list-order`,
    data,
    options,
    ""
  );}

export const OrderServices = {
  getOrderList,
  getPairList,
  getTradeHistory,
  orderHistoryCsv,
};
