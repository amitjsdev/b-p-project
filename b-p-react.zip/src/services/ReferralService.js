import { fetch } from './Fetch';
import { API_HOST } from '../constant';



const getReferralList = (options) => {
  return fetch('get', `${API_HOST}users/user/annoucements`, {}, options, '');
};

const getFriendsList = (options) => {
  return fetch('get', `${API_HOST}users/user/annoucements`, {}, options, '');
};

const getCommissionList = (options) => {
  return fetch('get', `${API_HOST}users/user/annoucements`, {}, options, '');
};

const genrateReferralLink = (data, options) => {
  return fetch('post', `${API_HOST}users/user/check_ip_token`, data, options, '');
};
//Api s
const getReferralToken = (data, options) => {
  return fetch('post', `${API_HOST}users/referral/get_referral_token`, data, options, '');
};

const getReferralHistory = (data, options) => {
  return fetch('get', `${API_HOST}users/referral/get_user_referral_history?offset=${data.offset}`, {}, options, '');
};

const getCustomPlans = (options) => {
  return fetch('get', `${API_HOST}users/referral/get_Custom_plans`, {}, options, '');
}

export const ReferralService = {
  getCustomPlans,
  getReferralHistory,
  getReferralToken,
  getReferralList,
  getFriendsList,
  getCommissionList,
  genrateReferralLink,
};
