import { fetch } from './Fetch';
import { API_HOST } from '../constant';

const getIp = () => {
  return fetch('get', 'https://jsonip.com');
};

const get2FaImage = (data, options) => {
  return fetch('post', `${API_HOST}users/user/google2fa`, data, options, '');
};

const google2faValidate = (data, options) => {
  return fetch(
    'post',
    `${API_HOST}users/user/google2faValidate`,
    data,
    options,
    ''
  );
};

const google2faDisable = (data, options) => {
  return fetch(
    'post',
    `${API_HOST}users/user/google2faDisable`,
    data,
    options,
    ''
  );
};
const uploadRawFile = (data, options) => {
  return fetch('post', `${API_HOST}users/file/upload`, data, options, '');
};
const getFileById = (data, options) => {
  return fetch('post', `${API_HOST}users/file/getFile`, data, options, '');
};

const removeKycDoc = (data, options) => {
  return fetch('post', `${API_HOST}users/file/deleteFile`, data, options, '');
};
const removeSelfieDoc = (data, options) => {
  return fetch('post', `${API_HOST}users/file/deleteFile`, data, options, '');
};
const getUserKycDetails = (options) => {
  return fetch('get', `${API_HOST}users/user/kyc`, {}, options, '');
};

const getUserProfile = (options) => {
  return fetch('get', `${API_HOST}users/profile/get`, {}, options, '');
};
const updateProfile = (data, options) => {
  return fetch('post', `${API_HOST}users/file/getFile`, data, options, '');
};

const getUserInfo = (options) => {
  return fetch('get', `${API_HOST}users/share/get-user-info`, {}, options, '');
};
const getUserTrustedDevice = (options) => {
  return fetch('get', `${API_HOST}users/user/userAgentInfo`, {}, options, '');
};
const resetUserPassword = (data, options) => {
  return fetch(
    'post',
    `${API_HOST}users/user/resetPassword`,
    data,
    options,
    ''
  );
};

const updateUserProfile = (data, options) => {
  return fetch('post', `${API_HOST}users/profile/update`, data, options, '');
};

const updateUserKyc = (data, options) => {
  return fetch('post', `${API_HOST}users/user/kyc`, data, options, '');
};

const addUserBank = (data, options) => {
  return fetch('post', `${API_HOST}users/bank/add`, data, options, '');
};

const getUserBank = (options) => {
  return fetch('get', `${API_HOST}users/bank/list`, {}, options, '');
};
const updateUserBank = (data, id, options) => {
  return fetch('put', `${API_HOST}users/bank/update/${id}`, data, options, '');
};
const send2faEmailVerification = (options) => {
  return fetch(
    'get',
    `${API_HOST}users/user/send2faEmailVerification`,
    {},
    options,
    ''
  );
};

const token_verification = (data, options) => {
  return fetch(
    'post',
    `${API_HOST}users/user/token-verification`,
    data,
    options,
    ''
  );
};
const token_verification_google = (data, options) => {
  return fetch(
    'post',
    `${API_HOST}users/user/google2faAuthenticate`,
    data,
    options,
    ''
  );
};

const verifygoogle2fa = (data, options) => {
  return fetch(
    'post',
    `${API_HOST}users/user/verifygoogle2fa`,
    data,
    options,
    ''
  );
};


const check_ip_token = (data, options) => {
  return fetch('post', `${API_HOST}users/user/check_ip_token`, data, options, '');
};


const getAnnouncements = (options) => {
  return fetch('get', `${API_HOST}users/user/annoucements`, {}, options, '');
};

const getUserActivities = (options) => {
  return fetch('get', `${API_HOST}users/user/userActivities`, {}, options, '');
}

const getImageBuffer = (data,options) => {
  return fetch('post', `${API_HOST}users/file/getImageBuffer`, data, options, '');
}

const getNotification = (data,options) => {
  return fetch('get', `${API_HOST}users/user/notifications?offset=${data.offset}`, {}, options, '');
}



export const SecurityService = {
  getNotification,
  getImageBuffer,
  getUserActivities,
  getAnnouncements,
  check_ip_token,
  verifygoogle2fa,
  token_verification_google,
  token_verification,
  send2faEmailVerification,
  updateUserBank,
  getIp,
  get2FaImage,
  google2faValidate,
  google2faDisable,
  uploadRawFile,
  getFileById,
  removeKycDoc,
  removeSelfieDoc,
  getUserProfile,
  updateProfile,
  getUserKycDetails,
  getUserInfo,
  resetUserPassword,
  updateUserProfile,
  getUserTrustedDevice,
  updateUserKyc,
  addUserBank,
  getUserBank,
};
