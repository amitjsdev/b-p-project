import { fetch } from "./Fetch";
import { API_HOST } from "../constant";
import { localeData } from "moment";

const getPairList = (options) => {
  return fetch("get", `${API_HOST}trading/trade/pair-list`, {}, options, "");
};
const getCoinStat = (options) => {
  return fetch("get", `${API_HOST}trading/trade/coin_stat`, {}, options, "");
};

const getCommodityPrice = (options) => {
  return fetch(
    "get",
    `${API_HOST}trading/trade/get-commodity-price`,
    {},
    options,
    ""
  );
};

const placeOrder = (data, options) => {
  return fetch(
    "post",
    `${API_HOST}trading/trade/place-order`,
    data,
    options,
    ""
  );
};
const tradeOrderList = (data, options) => {
  return fetch(
    "post",
    `${API_HOST}trading/trade/list-order`,
    data,
    options,
    ""
  );
};

const getTotalSupply = (data) => {
  return fetch("post", `${API_HOST}wallet/getTokenSupply`, data);
};

const CancelOpenOrder = (data, options) => {
  return fetch(
    "post",
    `${API_HOST}trading/trade/cancel-order`,
    data,
    options,
    ""
  );
};

export const ExchangeService = {
  getPairList,
  getCoinStat,
  getCommodityPrice,
  placeOrder,
  tradeOrderList,
  getTotalSupply,
  CancelOpenOrder,
};
