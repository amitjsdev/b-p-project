import { fetch } from './Fetch';
import { API_HOST } from '../constant';
import {requestEncryption} from '../redux/actions/RegisterActions';

const getUserBalance = (currency,options) => {
  return fetch('get', `${API_HOST}wallet/balances`, {}, options, '');
};
const getWalletHistory = (options) => {
    return fetch('get', `${API_HOST}wallet/balancesHistory`, {}, options, '');
  };
  
  const getSingleCoinHistory = (values,options) => {
    let {coinToken,network} = values;
    return fetch('get', `${API_HOST}wallet/balancesHistory?coinToken=${coinToken}&network=${network}`, {}, options, '');
  };

const getActiveCoins = (options) => {
  return fetch('get', `${API_HOST}wallet/active-all-coins`, {}, options, '');
};
const getcoinContractAddress = (options) => {
  return fetch(
    'get',
    `${API_HOST}wallet/coin-contract-address`,
    {},
    options,
    ''
  );
};

const getUserBalanceParticularCoin = (coin, options,network) => {
  return fetch('get', `${API_HOST}wallet/${coin}/get_balance?network=${network}`, {}, options, '');
};

const getCoinDepositAddress = (coin, options,network) => {
  return fetch('get', `${API_HOST}wallet/${coin}/get_address?network=${network}`, {}, options, '');
};

const getCoinNetworkList = (coin, options) => {
  return fetch('get', `${API_HOST}wallet/${coin}/get_networks_list`, {}, options, '');
};

const checkBreachedTokens = (options) => {
  return fetch(
    'get',
    `${API_HOST}trading/trade/checkBreachedTokens`,
    {},
    options,
    ''
  );
};
const getTradePairList = (options) => {
  return fetch('get', `${API_HOST}trading/trade/pair-list`, {}, options, '');
};

const getDepositTxnHistory = (data, options) => {
  // type=1 //depost
  return fetch(
    'get',
    `${API_HOST}wallet/${data.coin}/get_deposit_transactions/${data.page}`,
    {},
    options,
    ''
  );
};

const getWithdrawTxnHistory = (data, options) => {
  // type=1 //depost
  return fetch(
    'get',
    `${API_HOST}wallet/${data.coin}/get_withdraw_transactions/${data.page}`,
    {},
    options,
    ''
  );
};

const getWithdrawDepositTxnHistory = (data, options) => {
  return fetch('post', `${API_HOST}wallet/getTransactions`, data, options, '');
};

const getCoinContractAddress = (options) => {
  return fetch(
    'get',
    `${API_HOST}wallet/coin-contract-address`,
    {},
    options,
    ''
  );
};

const getCurrencyDetails = (coin, options) => {
  return fetch(
    'get',
    `${API_HOST}wallet/${coin}/currency_detials`,
    {},
    options,
    ''
  );
};
const withdrawRequestValidation = (data, coin, options) => {
  let requestData = requestEncryption(data);
  return fetch(
    'post',
    `${API_HOST}wallet/${coin}/withdraw_request_validation`,
    {data:requestData},
    options,
    ''
  );
};
const withdrawRequest = (data, coin, options) => {
  let requestData = requestEncryption(data);
  return fetch(
    'post',
    `${API_HOST}wallet/${coin}/withdraw_request`,
    {data:requestData},
    options,
    ''
  );
};

const getCoinDetail = (data, options) => {
  return fetch('post', `${API_HOST}trading/trade/swap/get_coin_detail`, data, options, '');
};
const getCurrentPrice = (data, options) => {
  return fetch('post', `${API_HOST}trading/trade/swap/getcoinCurrentPrice`, data, options, '');
};
const getSwapHistory = (data, options) => {
  return fetch('post', `${API_HOST}trading/trade/swap/swap-history`, data, options, '');
};
const getSwapPairs = (data, options) => {
  return fetch('get', `${API_HOST}trading/trade/swap/swap-pairs`, {}, options, '');
};

const swappingOrder = (data, options) => {
  return fetch('post', `${API_HOST}trading/trade/swap/swapping`, data, options, '');
};


export const WalletService = {
  swappingOrder,
  getSwapPairs,
  getCoinDetail,
  getSwapHistory,
  getCurrentPrice,
  withdrawRequest,
  withdrawRequestValidation,
  getCoinContractAddress,
  getWithdrawDepositTxnHistory, //combined for withdraw and deposit with some filters
  getDepositTxnHistory,
  getWithdrawTxnHistory,
  getTradePairList,
  getUserBalanceParticularCoin,
  getUserBalance,
  getWalletHistory,
  checkBreachedTokens,
  getActiveCoins,
  getcoinContractAddress,
  getCoinDepositAddress,
  getCoinNetworkList,
  getCurrencyDetails,
  getSingleCoinHistory,
};
