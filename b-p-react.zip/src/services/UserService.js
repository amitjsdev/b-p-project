import { fetch } from './Fetch';
import { API_HOST, ENCRYPT_KEY } from '../constant';
import {requestEncryption} from '../redux/actions/RegisterActions';

const login = (user) => {
  //  return fetch('post', `${API_HOST}users/user/login`, user);
  let data = requestEncryption(user);
  return fetch('post', `${API_HOST}users/user/login`, {data:data});
};
 
const verifyUsersEmail = (token) => {
  return fetch('post', `${API_HOST}users/user/verify-email`, token);
};

const verifyUserDevice = (token) => {
  return fetch('post', `${API_HOST}users/user/authneticateDevice`, token);
};

const userRegistrationApi = (token) => {
  let data = requestEncryption(token);
 return fetch('post', `${API_HOST}users/user/register`, {data:data});
};

// const getIp = () => {
//   return fetch('get', 'https://jsonip.com');
// };

const getIp = () => {
  return fetch('get', 'https://ipapi.co/json/');
};


const forgetPassword = (data) => {
  return fetch('post', `${API_HOST}users/user/forgotPassword`, data);
};

const resetPassword = (data) => {
  return fetch('post', `${API_HOST}users/user/forgotPasswordReset`, data);
};

const checkEmailExist = (data) => {
  return fetch('post', `${API_HOST}users/user/check_email_exist`, data);
};
const checkMobileExist = (data) => {
  return fetch('post', `${API_HOST}users/user/check_mobileNumber_exist`, data);
};
const resendVerificationMail = (data) => {
  return fetch('post', `${API_HOST}users/user/resend_verification_email`, data);
};

const checkIpToken = (data) => {
  return fetch("post", `${API_HOST}users/user/check_ip_token`, { token: data });
};
export const UserService = {
  checkIpToken,
  login,
  getIp,
  forgetPassword,
  verifyUsersEmail,
  userRegistrationApi,
  resetPassword,
  checkEmailExist,
  checkMobileExist,
  verifyUserDevice,
  resendVerificationMail,
};
