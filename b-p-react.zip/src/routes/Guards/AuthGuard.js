import React, { useEffect } from "react";
import { Route, Redirect,useHistory } from "react-router-dom";
import { connect } from "react-redux";
import { AUTH_TOKEN_KEY } from "../../constant";
import {check_ip_token,getUserProfile,getUserInfo} from "../../redux/actions/SecurityActions"
import {removeToken,setLocalStorage,getToken} from '../../Helpers/storageHelper';

const AuthGuard = ({ component: Component, ...rest },props) => {
  let history = useHistory();
  const { isUserFirstTimeLogin,check_ip_token,getUserProfile,getUserInfo } = rest;
  var isAuthenticated = false;
  var tokens = getToken(AUTH_TOKEN_KEY);

  if (tokens !== null && tokens !== undefined) {
    isAuthenticated = true;
  }

  useEffect(()=>{
    let emailData;
    if(!!isAuthenticated){
    // props.check_ip_token({ "issuer":""}).then((res)=>{
      getUserProfile().then((res)=>{
        emailData = res[0]?.email
      })

    check_ip_token({token:tokens}).then((res)=>{
      if (!res.data.data) {
        removeToken(AUTH_TOKEN_KEY, '', 1);
        setLocalStorage('')
        history.push(`/login`);
      }
    })
    getUserInfo();
  }

 },[])

 
  return (
    <Route
      {...rest}
      render={props =>
        isAuthenticated ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: tokens == null || tokens == undefined ? `/login` : `/auth/dashboard`,
              state: {
                from: props.location
              }
            }}
          />
        )
      }
    />
  );
};

const mapStateToProps = state => {
  return {
    isUserFirstTimeLogin: state.persist.isUserFirstTimeLogin

  };
};

const mapDisptachToProps = dispatch => {
  return {
    getUserProfile:()=>dispatch(getUserProfile()),
    getUserInfo:()=>dispatch(getUserInfo()),
    check_ip_token: (data) => dispatch(check_ip_token(data)),
    

  }
}

export default connect(
  mapStateToProps,
  mapDisptachToProps
)(AuthGuard);
