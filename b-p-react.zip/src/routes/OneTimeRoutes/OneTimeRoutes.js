import React, { Component } from "react";
import { Route, Redirect, Switch } from "react-router-dom";
import { withRouter } from "react-router";
// import Signin from "../../Pages/PublicPages/Signin/Signin";
import Footer from "../../components/common/Footer/Footer";
import Google2FaFirstLogin from "../../Pages/PublicPages/Google2FaFirstLogin"


class OneTimeRoutes extends Component {
  state = {};
  render() {
    return (
      <>
        <Switch>
     
            <Route
              path={`/auth/dashboard`}
              component={Google2FaFirstLogin} 
              exact={true}       
            />       
                  
                 
        </Switch>
        <Footer />
       </>
    );
  }
}

export default withRouter(OneTimeRoutes);
