import React from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "../../../components/common/CustomTable/CustomTable.scss";
import moment from "moment";
import ReactPaginate from "react-paginate";
import { tSExportAssignment } from "@babel/types";

import { smallestunitFormat } from "../../../Helpers/Normailize";

function SwapTransaction(props) {
  const { swapData, getSwapHistory, currentPair } = props;

  const handlePageClick = (event, val) => {
    const newPage = event.selected + 1;
    getSwapHistory(newPage, currentPair);
  };

  return (
    <PerfectScrollbar
    // onScrollY={(container) =>
    //   console.log(`scrolled to: ${container.scrollTop}.`)
    // }
    >
      <Table className={`customTable ${props.className}`}>
        <thead>
          <tr>
            <th>Date</th>
            {/* <th>Type</th> */}
            <th>Pair</th>
            <th>Amount</th>
            <th>Price</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          {swapData?.data && swapData?.data?.length > 0 ? (
            swapData?.data.map((item) => {
              // let totalAmount =
              //   smallestunitFormat(item?.price) *
              //   smallestunitFormat(item?.amount);
              return (
                <tr>
                  <td>{moment(item?.created_at).format("MM/DD/YYYY")}</td>
                  {/* <td>{item?.type == }</td> */}
                  <td>{item?.symbol}</td>
                  <td>{item?.origQty}</td>
                  <td>
                  {smallestunitFormat(item?.price)}</td>
                  <td>{item?.status == 1 ? 'Pending' : item?.status == 2 ? 'Completed' : '-'}</td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan="10" className="text-center noTransaction_found">
                No Transactions Found
              </td>
            </tr>
          )}
        </tbody>
      </Table>
      {/* {console.log('swapData',swapData)} */}
      {swapData?.totalCount && swapData?.totalCount > 0 && (
        <ReactPaginate
          className="paginationStyle"
          breakLabel="..."
          nextLabel=">"
          onPageChange={(e) => handlePageClick(e, "trade")}
          pageRangeDisplayed={5}
          // pageCount={100}
          pageCount={Math.ceil(swapData?.totalCount / 5)}
          previousLabel="<"
          renderOnZeroPageCount={null}
        />
      )}
    </PerfectScrollbar>
  );
}

export default SwapTransaction;
