import React, { useState, useEffect } from "react";
import { Row, Col, Form } from "react-bootstrap";
// import 'bootstrap/dist/css/bootstrap.css';
// import Spinner from 'react-bootstrap/Spinner';
import MainCard from "../../../components/common/MainCard/MainCard";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CurrencyInput from "../../../components/common/CurrencyInput/CurrencyInput";
// import ChartImage from "../../../theme/images/chart_img.png";
import SwapTransaction from "./SwapTransaction";
import "./Swap.scss";
import CustomSearch from "../../../components/common/CustomSearch/CustomSearch";
import SelectPair from "../../../components/common/SelectPair/SelectPair";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { toast } from "../../../components/Toast/Toast";
import {
  getUserBalance,
  getWalletHistory,
  getActiveCoins,
  getCoinDepositAddress,
  getUserBalanceParticularCoin,
  getDepositTxnHistory,
  getCurrencyDetails,
  getWithdrawDepositTxnHistory,
  getCoinNetworkList,
  getCurrentPrice,
  getCoinDetail,
  getSwapHistory,
  getSwapPairs,
  swappingOrder,
} from "../../../redux/actions/WalletActions";

import { smallestunitFormat, bn_operations } from "../../../Helpers/Normailize";

import priceData from "../../../assets/btcdata.json";
import moment from "moment";
import { connect } from "react-redux";
import queryString from "query-string";
import { useHistory, useParams } from "react-router-dom";

import ReactHighcharts from "react-highcharts/ReactHighstock.src";
import { ENV_VAR, SMALLESTUNIT, KYC_APPROVED } from "../../../constant";
import { getUserInfo } from "../../../redux/actions/SecurityActions";

function Swap(props) {
  const { theme, walletTotalbalance } = props;
  const parsed = queryString.parse(props.location.search);
  const [selectedCoinFirst, setSelectedCoinFirst] = useState("btc");

  const [selectedCoinSecond, setSelectedCoinSecond] = useState("eth");

  const [selectedCoinName, setSelectedCoinName] = useState([
    "BITCOIN",
    "ETHEREUM",
  ]);
  const [graphBalance, setGraphBalance] = useState(0);
  const [graphData, setGraphData] = useState([]);
  const [minfeErr, setMinfeErr] = useState(false);

  const [tokenData, setTokenData] = useState([]);
  const [userInfo, setUserInfo] = useState(props.user_info_status);
  const [networkName, setNetworkName] = useState("");

  const [networkApi, setNetworkApi] = useState(false);
  const [swapButton, setSwapButton] = useState(true);

  const [networkoptions, setNetworkoptions] = useState([]);
  const [withdrawNewtwork, setWithdrawNewtwork] = useState("");
  const [currentToken, setCurrentToken] = useState([null, null]);
  const [userSelectedCoinBalance, setSelectedUserCoinBalance] = useState();
  const [curencyDetails, setCurencyDetails] = useState({});
  const [minWithdraw, setMinWithdraw] = useState(0);
  const [transactionFee, setTransactionFee] = useState(0);
  const [withdrawLimit, setWithdrawLimit] = useState(0);
  const [currentUrl, setCurrentUrl] = useState("");
  const [amountRange, setAmountRange] = useState(0);
  const [withdrawAmount, setWithdrawAmount] = useState(0);
  const [amount, setAmount] = useState("");
  const [secondAmount, setSecondAmount] = useState("");

  const [priceLOad, setPriceLoad] = useState(false);

  const [firstCointLimit, setFirstCoinLimit] = useState([]);
  const [conversionPrice, setConversionPrice] = useState(0);

  const [page, setPage] = useState(1);
  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;
  const [swapData, setSwapData] = useState([]);
  const [swapFilterData, setSwapFilterData] = useState([]);

  const [intervalApi, setIntervalApi] = useState(false);
  const [intervalAmount, setIntervalAmount] = useState("");
  const [intervalType, setIntervalType] = useState("");

  const [pairList, setPairList] = useState([]);
  const [currentPair, setCurrentPair] = useState("");
  const [limitError, setLimitError] = useState("");
  const [secondLimitError, setSecondLimitError] = useState("");
  const [conversionError, setConversionError] = useState("");
  const [showFee, setShowFee] = useState("");

  const [decimalLimit, showDecimalLimit] = useState("");

  const [markup, setMarkup] = useState("");


  
  
  // const [totalValue, setTotalValue] = useState(walletTotalbalance);

  const lineChartCurrency = "USD";

  //select pair for swap history
  const handleChangeSwapPair = (e) => {
    setCurrentPair(e.target.value);
  };

  const handleChangeToken = (e) => {
    setShowFee('');
    setSecondLimitError('');
    setLimitError('');
    clearTimeout(timer);
    let currentData = tokenData.filter((item) => item.value == e.value);
    let removeCurrentData = tokenData.filter((item) => item.value != e.value);
    setSecondAmount("");
    setAmount("");
    setCurencyDetails({});
    setMinWithdraw(0);
    setTransactionFee(0);
    setWithdrawLimit(0);
    // setWithdrawHistory([]);
    // setWithdrawHistoryRecords(0);
    setGraphBalance(0);
    setGraphData([]);

    setNetworkApi(false);
    setNetworkName("");
    setSelectedCoinFirst(currentData[0].value);

    // setSelectedCoinName([currentData[0].fullName,selectedCoinName[1]]);
    // setCurrentToken(currentData,currentToken[1]);

    if (selectedCoinName[1] == currentData[0].fullName) {
      setSelectedCoinSecond(removeCurrentData[0].value);
      setSelectedCoinName([
        currentData[0].fullName,
        removeCurrentData[0].fullName,
      ]);
      setCurrentToken([currentData, removeCurrentData[0]]);
    } else {
      setSelectedCoinName([currentData[0].fullName, selectedCoinName[1]]);
      setCurrentToken([currentData, currentToken[1]]);
    }

    setCurrentUrl(
      `/auth/swap?getCoin=${e.value}&coinName=${currentData[0].fullName}`
    );
  };

  const resetFilter = () => {
    setCurrentPair("");
    setDateRange([null, null]);
    setPage(1);
    getSwapHistory(1, "", "resetDate");
  };

  const swapOrderSubmit = () => {
    const  obj = {
      firstcoin:selectedCoinFirst,
      scndcoin:selectedCoinSecond,
      price:amount,
      amount:secondAmount,
      input: markup
    }
    props.swappingOrder(obj).then((res)=>{
          if(res?.data.code != 400){
            getSwapHistory(1, currentPair);
            setAmount('');
            setSecondAmount('')
          }
    })
    .catch((error)=>{

    });
  }

  const onSubmit = () => {
    getSwapHistory(1, currentPair);
  };

  const handleChangeSecondToken = (e) => {
    setShowFee('');
    showDecimalLimit('');
    setSecondLimitError('');
    setLimitError('');
    clearTimeout(timer);
    let currentData = tokenData.filter((item) => item.value == e.value);
    let removeCurrentData = tokenData.filter((item) => item.value != e.value);

    setCurencyDetails({});
    setMinWithdraw(0);
    setTransactionFee(0);
    setWithdrawLimit(0);
    // setWithdrawHistory([]);
    // setWithdrawHistoryRecords(0);
    setGraphBalance(0);
    setGraphData([]);
    setNetworkApi(false);
    setNetworkName("");
    setAmount("");
    setSecondAmount("");

    if (selectedCoinName[0] == currentData[0].fullName) {
      setSelectedCoinName([
        removeCurrentData[0].fullName,
        currentData[0].fullName,
      ]);
      setCurrentToken([removeCurrentData[0], currentData]);
      setSelectedCoinFirst(removeCurrentData[0].value);
    } else {
      setSelectedCoinName([selectedCoinName[0], currentData[0].fullName]);
      setCurrentToken([currentToken[0], currentData]);
    }
    setSelectedCoinSecond(currentData[0].value);
    setCurrentUrl(
      `/auth/swap?getCoin=${e.value}&coinName=${currentData[0].fullName}`
    );
  };

  const getCurrencyDetails = (coin, network) => {
    props
      .getCurrencyDetails(coin, network)
      .then((res) => {
        setCurencyDetails(res.data.data);
        setMinWithdraw(res.data.data.minimum_withdraw);
        setTransactionFee(res.data.data.withdraw_fee);
        if (props.user_info_status.kycStatus != KYC_APPROVED) {
          setWithdrawLimit(res.data.data.without_kyc_withdraw_limit);
        } else {
          setWithdrawLimit(res.data.data.with_kyc_withdraw_limit);
        }
      })
      .catch((error) => {});
  };

  const getCoinDetail = async () => {
    await props
      .getCoinDetail({ coin: selectedCoinFirst, othercoin: selectedCoinSecond })
      .then((res) => {
        // timeOut(intervalAmount,intervalType)
        let resultData = res.data.tokenDetail;
        setFirstCoinLimit(resultData);
        setConversionPrice(res.data.coinconversionPrice);
        if (intervalApi) {
          validate(intervalAmount, intervalType);
        }
        setConversionError('');
        setSwapButton(false);
      })
      .catch((error) => {
        if(error?.data?.code == 400){
          setSwapButton(true);
          clearTimeout(timer)
          setConversionPrice('')
          setConversionError(error?.data?.message)
        }
        // setFirstCoinLimit([]);
      });
  };

  const withdrawAllInPercent = (percent) => {
    if (
      userSelectedCoinBalance &&
      userSelectedCoinBalance.length > 0 &&
      userSelectedCoinBalance[0]?.balance > 0
    ) {
      setAmountRange(percent);
      setMinfeErr(false);
      let totalBalance = userSelectedCoinBalance[0]?.balance / SMALLESTUNIT;
      let balanceInPercent = (totalBalance * percent) / 100;
       let amountVal;
      if (balanceInPercent.toString().includes(".")) {
        amountVal = checkToFixed(
          balanceInPercent,
          balanceInPercent.toString().split(".")[1]
        );
      } else {
        amountVal = balanceInPercent;
      }


      setWithdrawAmount(amountVal);
      validate(amountVal, "have_amount");
    } else {
      toast.error("Please add balance in your wallet!");
      // setAmount(0);
    }
  };

  // calculating final amount after deduction of transaction fee
  const validate = (bal, amountType) => {
    if (amountType == "have_amount") {
      if (bal == "." || bal[0] == ".") {
        setAmount("0" + bal);
        setWithdrawAmount("0" + bal);
        bal = "0" + bal;
        checkMinAmountError(bal);
      } else {
        setAmount(bal);
        checkMinAmountError(bal);
      }
      setSecondLimitError('')
      setSecondAmount("");
      if (bal > 0) {
        // if (parseFloat(bal) < parseFloat(firstCointLimit.min_amount)) {
        //   setSwapButton(true);
        // } else if (parseFloat(bal) > parseFloat(firstCointLimit.max_amount)) {
        //   setSwapButton(true);
        // } else {
        setPriceLoad(true);
        setSwapButton(false);
        props
          .getCurrentPrice({
            amount: bal.toString(),
            coinid: selectedCoinFirst,
            swapcoin: selectedCoinSecond,
            firstCoin:selectedCoinFirst,

          })
          .then((res) => {
            setMarkup(res?.data?.input);
            setShowFee(res?.data?.Feemsg);
            showDecimalLimit(res?.data?.stepSize);
            let coinPrice = res?.data?.Amountcoin;
            let amountVal;
            if (coinPrice > 0) {
              if (coinPrice.toString().includes(".")) {
                amountVal = checkToFixed(
                  coinPrice,
                  coinPrice.toString().split(".")[1]
                );
              } else {
                amountVal = coinPrice;
              }
              setSecondAmount(amountVal);
            } else {
              setAmount(coinPrice);
            }
            setPriceLoad(false);
            setLimitError('')
            setSwapButton(false);

          })
          .catch((error) => {
            setMarkup('');
            setShowFee('');
            showDecimalLimit('')
            if(error?.data?.code == 400){
              setSwapButton(true);
              setLimitError(error?.data?.message)
            }
            setPriceLoad(false);
          });
        // }
      }else{
        showDecimalLimit('')
        setShowFee('')
        setSwapButton(true);
        if(bal){
          setLimitError('Swapping amount should not be 0')
        }else{
          setLimitError('');
        }
      }
    }
    if (amountType == "want_amount") {
      if(bal.toString().includes('.') && bal > 0){
       let lengthVal = bal.toString().split('.')[1].length;
       if(!!decimalLimit && lengthVal > decimalLimit){
            return false;
       }
       if(decimalLimit == 0){
        return false;
       }
      }
      
      setLimitError('');
      setPriceLoad(true);
      if (bal == "." || bal[0] == ".") {
        setSecondAmount("0" + bal);
        // setWithdrawAmount("0" + bal);
        bal = "0" + bal;
        // checkMinAmountError(bal);
      } else {
        setSecondAmount(bal);
        // checkMinAmountError(bal);
      }
      if (bal > 0) {
      props
        .getCurrentPrice({
          amount: bal,
          coinid: selectedCoinSecond ,
          swapcoin: selectedCoinFirst,
          firstCoin:selectedCoinFirst
        })
        .then((res) => {
          setMarkup(res?.data?.input);
          showDecimalLimit(res?.data?.stepSize);
          setShowFee(res?.data?.Feemsg)
          let coinPrice = res?.data?.Amountcoin;
          if (coinPrice > 0) {
            let amountVal;
             if (coinPrice.toString().includes(".")) {
                amountVal = checkToFixed(
                  coinPrice,
                  coinPrice.toString().split(".")[1]
                );
              } else {
                amountVal = coinPrice;
              }
            setAmount(amountVal);
          } else {
            setAmount(coinPrice);
          }
          setPriceLoad(false);
          setSecondLimitError('')
          setSwapButton(false);
        })
        .catch((error) => {
          setAmount('');
          setMarkup('')
          setShowFee('')
          showDecimalLimit('');
           if(error?.data?.code == 400){
            setSwapButton(true);
              setSecondLimitError(error?.data?.message)
            }
            setPriceLoad(false);
        });

      }else{
        setShowFee('');
        showDecimalLimit('');
        setSwapButton(true);
        if(bal){
          setAmount(0);
          setSecondLimitError('Swapping amount should not be 0')
        }else{
          setAmount('');
          setSecondLimitError('');
        }
      }
    }
  };

  const checkToFixed = (coinPrice, val) => {
    if (val.toString().length > 8) {
      return coinPrice.toFixed(8);
    } else {
      return coinPrice;
    }
  };
  // check if entered amount  is   less than min withdraw limit
  const checkMinAmountError = (bal) => {
    if (bal < props.minWithdraw / SMALLESTUNIT) {
      setMinfeErr(true);
    } else {
      setMinfeErr(false);
    }
  };

  const getCoinDepositAddress = (coin, network) => {
    props
      .getCoinDepositAddress(coin, network)
      .then((res) => {
        let coinAddessData = res.data.data;
        if (coinAddessData) {
          getParticularCoinBalance(selectedCoinFirst, networkName);
        }
      })
      .catch((error) => {});
  };

  // /getParticularCoinBalance
  const getParticularCoinBalance = (coin, network) => {
    //   alert(coin)
    props
      .getUserBalanceParticularCoin(coin, network)
      .then((res) => {
        setSelectedUserCoinBalance(res.data.data);
      })
      .catch((error) => {});
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    //connectSocket()
    if (tokenData && tokenData.length == 0) {
      getSwapHistory(1, "");
      getActiveCoins();
    }
    if (Object.keys(userInfo).length == 0) {
      props.getUserInfo().then((res) => {
        setUserInfo(res.data.data);
      });
    }

    let data = {
      coin: selectedCoinFirst,
      page: page,
    };
    if (selectedCoinFirst !== "" && networkName == "") {
      getCoinDetail(intervalAmount, intervalType);
      props.getSwapPairs().then((res) => {
        setPairList(res?.data?.data);
      });

      props
        .getCoinNetworkList(selectedCoinFirst)
        .then((res) => {
          const networksList = [];
          let resData = res.data.data;
          resData &&
            resData.length > 0 &&
            resData.map((item) => {
              networksList.push({
                value: item.network_name,
                label: item.full_name,
              });
            });
          setNetworkoptions(networksList);
          setNetworkApi(true);
          setNetworkName(resData[0].network_name);
          setWithdrawNewtwork(resData[0].network_name);
        })
        .catch((error) => {});
    }
    if (networkApi) {
      getCoinDepositAddress(selectedCoinFirst, networkName);
      getCurrencyDetails(selectedCoinFirst, networkName);
    }
  }, [selectedCoinFirst, networkName]);

  useEffect(() => {
    if(!!conversionPrice && conversionPrice > 0){
      timeOut();
    }
  }, [conversionPrice]);

  let timer;
  const timeOut = () => {
    timer = window.setTimeout(function () {
      getCoinDetail(intervalAmount, intervalType);
    }, 5000);
  };

  //get swap history
  const getSwapHistory = (pageVal, checkPair, resetDate) => {
    let startFromDate = "";
    let endToDate = "";
    if (resetDate == "resetDate") {
      startFromDate = "";
      endToDate = "";
    } else {
      startFromDate =
        startDate !== null ? moment(startDate).format("YYYY-MM-DD") : "";
      endToDate = endDate !== null ? moment(endDate).format("YYYY-MM-DD") : "";
    }

    // let pair = currentPair;

    let data = {
      fromDate: startFromDate,
      toDate: endToDate,
      page: pageVal,
      pair: checkPair
    };

    
    props
      .getSwapHistory(data)
      .then((res) => {
        let resultData = res.data;
        setSwapData(resultData);
        setSwapFilterData(resultData);
        // setConversionPrice(res.data.coinconversionPrice)
      })
      .catch((error) => {
        setFirstCoinLimit([]);
      });
  };

  let optionVal =
    tokenData &&
    tokenData.length > 0 &&
    tokenData.findIndex((item) => item.value == selectedCoinFirst);
  let optionValSecond =
    tokenData &&
    tokenData.length > 0 &&
    tokenData.findIndex((item) => item.value == selectedCoinSecond);

  const getActiveCoins = () => {
    props
      .getActiveCoins()
      .then((res) => {
        let tokenList = [];
        let data = res.data?.coinList;
        const uniqueChars = data.filter(
          (v, i, a) => a.findIndex((t) => t.full_name === v.full_name) === i
        );
        uniqueChars &&
          uniqueChars.length > 0 &&
          uniqueChars.forEach((item) => {
            let historyBalance = [];
            // historyBalance.push(item.amount)
            tokenList.push({
              fullName: item.full_name,
              value: item.coin,
              label: (
                <div>
                  {item?.coin_image ? (
                    <img src={item?.coin_image} className="optionIcon" />
                  ) : (
                    ""
                  )}
                  {item.coin.toUpperCase()}
                </div>
              ),
            });
          });
        tokenList.sort(function (a, b) {
          var textA = a.value.toUpperCase();
          var textB = b.value.toUpperCase();
          return textA < textB ? -1 : textA > textB ? 1 : 0;
        });
        setTokenData(tokenList);
      })
      .catch((error) => {});
  };

  const handleDateChange = (e, dateName) => {
    setDateRange(e);
  };

  const handleChange = (e) => {
    setAmountRange(0)
    const { value, name } = e.target;
    if (name === "withdrawAddress") {
      // setAddress(value);
    } else {
      if (/^\d*(\.\d{0,8})?$/.test(value)) {
        if (name == "have_amount") {
          setIntervalAmount(value);
          setIntervalType("have_amount");
          validate(value, "have_amount");
        } else {
          setIntervalAmount(value);
          setIntervalType("want_amount");
          validate(value, "want_amount");
        }
        clearTimeout(timer)
        timeOut()
      } else {
        setIntervalAmount("");
        setIntervalType("");
        validate("", "");
        setIntervalApi(false);
      }
    }
    // window.location.replace(`/auth/deposit?getCoin=${e.value}`)
  };

  useEffect(() => {
    if (graphData && graphData.length == 0 && walletTotalbalance > 0) {
      getWalletHistory();
    }
  }, [walletTotalbalance, props.theme]);

  //get balance history

  const getWalletHistory = () => {
    // if (!!lineChartCurrency) {

    props.getWalletHistory(lineChartCurrency).then((res) => {
      let jsonData = [];
      let result = res?.data?.data;
      let historyBalance = [];
      // setGraphData

      var today = new Date();
      var date =
        today.getFullYear() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getDate();
      let currentDate = moment(today).format("YYYY-MM-DD") + "T00:00:00.000Z";

      let itemCount = 0;
      result &&
        result.length > 0 &&
        result.forEach((item) => {
          itemCount++;
          let resData = moment(item.date).format("YYYY-M-D");
          if (new Date(resData).getTime() != new Date(date).getTime()) {
            var datum = new Date(item.date).getTime();
            jsonData.push([datum, item.amount]);
            historyBalance.push(item.amount);
          }
        });

      // let totalBalance = historyBalance.reduce(function (index, item) {
      //   return index + parseFloat(item);
      // }, 0);
      if (result.length == itemCount) {
        var datum = new Date(currentDate).getTime();
        jsonData.push([datum, parseFloat(walletTotalbalance)]);
      }
      setGraphData(jsonData);
      setGraphBalance(parseFloat(walletTotalbalance));
    });
    //}
  };

  //line stock start
  const options = {
    style: "currency",
    currency: lineChartCurrency ? lineChartCurrency : "USD",
  };
  const numberFormat = new Intl.NumberFormat("en-US", options);
  const configPrice = {
    yAxis: [
      {
        lineWidth: 0,
        gridLineColor: "#e8e8e8",
        offset: 15,
        opposite: false,

        labels: {
          formatter: function () {
            return numberFormat.format(this.value);
          },
          x: 0,
          style: {
            color: "#5f658a",
            position: "absolute",
          },
          align: "right",
        },
      },
    ],
    tooltip: {
      shared: true,
      formatter: function () {
        return `<p style="color:#fff">Balance: ${
          numberFormat.format(this.y, 0) +
          '</b><br/><span style="color:#fff">' +
          moment(this.x).format("MMM Do YYYY")
        }</span></p>`;
      },
      backgroundColor: "#3486ff",
      color: "#fff",
      fillText: "#fff",
    },
    plotOptions: {
      series: {
        showInNavigator: true,
        // gapSize: 12,
        color: "#00be00",
      },
      // color:'#fff'
    },
    rangeSelector: {
      selected: 1,
      // enabled: false
    },
    // title: {
    //   text: `Wallet Balance <br>
    //   <span class="balanceAmount">11,899.00 USD</span>`,
    //   color: "#fff",
    // },
    title: {
      text: `<span class="${
        theme == "dark---" ? "darkTheme" : ""
      } graphTile">Wallet Balance</span> <br><br>
    <span class="${
      theme == "dark" ? "darkTheme" : ""
    } balanceAmount">${graphBalance} ${lineChartCurrency}</span>`,
      color: theme == "dark" ? "#fff" : "#050823",
      align: "left",
    },

    credits: {
      enabled: false,
    },

    legend: {
      enabled: true,
    },
    chart: {
      backgroundColor: theme == "dark" ? "#fff" : "#050823",
      height: 470,
      inputPosition: {
        x: +13,
      },
    },
    // style: {
    //   "color": "#fff"
    // },
    xAxis: {
      offset: 15,
      type: "datetime",
      style: {
        color: "#5f658a",
      },
    },
    rangeSelector: {
      floating: true,
      x: 450,
      y: -50,
      buttons: [
        {
          type: "day",
          count: 1,
          text: "1d",
          color: 'blue'
        },
        {
          type: "day",
          count: 7,
          text: "7d",
        },
        {
          type: "month",
          count: 1,
          text: "1m",
        },
        {
          type: "month",
          count: 3,
          text: "3m",
        },
        {
          type: "all",
          text: "All",
        },
      ],
      selected: 4,
    },
    navigator: {
      enabled: false,
    },
    series: [
      {
        pointStart: graphData && graphData.length > 0 && graphData[0][0],
        name: "Price",
        data: graphData,
      },
    ],
  };
  //line stock end
  return (
    <>
      <div className="swapMain">
        <Row className="swapTop_Row mx-0">
          <Col xs={12} md={12} lg={12} xl={7} className="chartCol">
            <div className="walletChart_Style">
              <ReactHighcharts config={configPrice}></ReactHighcharts>
            </div>
          </Col>
          <Col xs={12} md={12} lg={12} xl={5} className="swapCrypto_Col">
            <MainCard title="Swap Crypto" className="m-0">
              <Row className="swapCurrency_Row">
                <Col xs={12}>
                  <Form.Label className="d-flex justify-content-between">
                    I have {selectedCoinName[0].toUpperCase()}
                    <span className="balanceTxt">
                      Balance:{" "}
                      <span>
                        {userSelectedCoinBalance &&
                        userSelectedCoinBalance.length > 0
                          ? smallestunitFormat(
                              userSelectedCoinBalance[0].balance +
                                userSelectedCoinBalance[0].locked_balance
                            )
                          : "0.00"}{" "}
                        {selectedCoinFirst.toUpperCase()}{" "}
                      </span>
                    </span>
                  </Form.Label>
                  <CurrencyInput
                    // inputPlaceholder={
                    //   firstCointLimit?.min_amount
                    //     ? firstCointLimit?.min_amount +
                    //       " - " +
                    //       firstCointLimit?.max_amount
                    //     : "Enter amount*"
                    // }
                    inputPlaceholder={`Enter amount*`}
                    name={`have_amount`}
                    amountValue={amount}
                    handleChange={handleChange}
                    tokenData={tokenData}
                    defaultValue={
                      currentToken[0] && Object.keys(currentToken[0]).length > 0
                        ? currentToken[0]
                        : tokenData[0]
                    }
                    value={
                      currentToken[0] && Object.keys(currentToken[0]).length > 0
                        ? currentToken[0]
                        : tokenData[optionVal]
                    }
                    className="internalInput mb-0"
                    placeholder="Amount"
                    handleChangeToken={handleChangeToken}
                  />
                  {limitError != '' && <span style={{ color: "red" }}> {limitError}</span>}
                  {/* <span style={{ color: "red" }}>
                    {!!firstCointLimit?.max_amount &&
                      parseFloat(amount) >
                        parseFloat(firstCointLimit?.max_amount) &&
                      "The amount has to be lower than " +
                        firstCointLimit.max_amount}
                  </span>
                  <span style={{ color: "red" }}>
                    {!!firstCointLimit?.min_amount &&
                      amount != "" &&
                      parseFloat(amount) <
                        parseFloat(firstCointLimit?.min_amount) &&
                      "The amount has to be higher than " +
                        firstCointLimit.min_amount}
                  </span> */}
                </Col>
                <Col xs={12} lg={12} className="amount_range">
                  <button
                    onClick={() => withdrawAllInPercent(25)}
                    className={amountRange == 25 ? `active` : ""}
                  >
                    25%
                  </button>
                  <button
                    onClick={() => withdrawAllInPercent(50)}
                    className={amountRange == 50 ? `active` : ""}
                  >
                    50%
                  </button>
                  <button
                    onClick={() => withdrawAllInPercent(75)}
                    className={amountRange == 75 ? `active` : ""}
                  >
                    75%
                  </button>
                  <button
                    onClick={() => withdrawAllInPercent(100)}
                    className={amountRange == 100 ? `active` : ""}
                  >
                    100%
                  </button>
                </Col>
                {/* {priceLOad && (
                  <Spinner className="priceLoader" animation="border" />
                )} */}
                <Col xs={12}>
                  <Form.Label>
                    I want {selectedCoinName[1].toUpperCase()}
                  </Form.Label>
                  <CurrencyInput
                    inputPlaceholder={"Enter amount*"}
                    handleChange={handleChange}
                    amountValue={secondAmount != "" ? secondAmount : ""}
                    name={`want_amount`}
                    tokenData={tokenData}
                    defaultValue={``}
                    value={
                      currentToken[1] && Object.keys(currentToken[1]).length > 0
                        ? currentToken[1]
                        : tokenData[optionValSecond]
                    }
                    className="internalInput mb-0"
                    placeholder="Amount"
                    handleChangeToken={handleChangeSecondToken}
                  />
                  {secondLimitError != '' && <span style={{ color: "red" }}> {secondLimitError}</span>}

                  
                    {!!conversionPrice && conversionPrice > 0 ? (
                      <>
                      <p className="text-center convertedCurrency">  {`1 ${selectedCoinFirst} = ${conversionPrice} ${selectedCoinSecond}`} </p>
                      </>
                    ) : (
                      conversionError != '' && <p style={{color: 'red'}} className="text-center convertedCurrency"> 
                        {conversionError}</p>
                    )}
          
                <p className="text-center feeInfo">  {showFee} </p>

                </Col>
                <Col xs={12}>
                  <ButtonPrimary
                    onClick={swapOrderSubmit}
                    disabled={swapButton || !amount || !secondAmount }
                    buttontext="SWAP"
                    className="internalComn_btn mb-0"
                  />
                </Col>
              </Row>
            </MainCard>
          </Col>
        </Row>
        <Row className="mx-0">
          <Col xs={12} md={12} lg={12} xl={12}>
            <MainCard className="mb-0">
              <div className="swapTable_headrow">
                <p>Swapping History</p>
                <div className="filterInput_div">
                  <div className="d-flex align-items-center justify-content-between dateSelect_div">
                    <Form.Group
                      className={`customInput internalInput`}
                      // controlId={props.controlId}
                    >
                      <Form.Label></Form.Label>
                      <DatePicker
                        selectsRange={true}
                        startDate={startDate}
                        endDate={endDate}
                        className={`form-control internalInput`}
                        placeholderText="MM/DD/YYYY - MM/DD/YYYY"
                        onChange={(update) => {
                          handleDateChange(update);
                        }}
                        required={true}
                      />
                    </Form.Group>
                  </div>
                  <SelectPair
                    selectedVal={currentPair}
                    placeholder="Pair"
                    name="swapPair"
                    handleChangeSwapPair={handleChangeSwapPair}
                    pairList={pairList}
                  />
                  {/* <CustomSearch
                    handleSearch={handleSearch}
                   placeholder="Search" /> */}
                  <ButtonPrimary
                    onClick={resetFilter}
                    buttontext="Reset"
                    className="internalComn_btn me-2"
                  />
                  <ButtonPrimary
                    onClick={onSubmit}
                    buttontext="Submit"
                    className="internalComn_btn"
                  />
                </div>
              </div>
              <div className="tableOuter_Div deposit_Table">
                <SwapTransaction
                  currentPair={currentPair}
                  getSwapHistory={getSwapHistory}
                  swapData={swapData}
                />
              </div>
            </MainCard>
          </Col>
        </Row>
      </div>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletTotalbalance: state.walletbalance?.walletTotalbalance,
    theme: state.persist.theme ? "dark" : "light",
    user_info_status: state.security.userProfile,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getUserInfo: () => dispatch(getUserInfo()),
    getCoinNetworkList: (coin, network) =>
      dispatch(getCoinNetworkList(coin, network)),
    getCoinDepositAddress: (coin, network) =>
      dispatch(getCoinDepositAddress(coin, network)),
    getCurrencyDetails: (coin, network) =>
      dispatch(getCurrencyDetails(coin, network)),
    getUserBalanceParticularCoin: (coin, network) =>
      dispatch(getUserBalanceParticularCoin(coin, network)),
    // updateUserKyc: (data) => dispatch(updateUserKyc(data)),
    getActiveCoins: () => dispatch(getActiveCoins()),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),
    getWalletHistory: () => dispatch(getWalletHistory()),
    getCurrentPrice: (data) => dispatch(getCurrentPrice(data)),
    getCoinDetail: (data) => dispatch(getCoinDetail(data)),
    getSwapHistory: (data) => dispatch(getSwapHistory(data)),
    getSwapPairs: (data) => dispatch(getSwapPairs(data)),
    swappingOrder:(data) => dispatch(swappingOrder(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Swap);
