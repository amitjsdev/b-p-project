import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card, ListGroup, Tabs, Tab, Modal } from "react-bootstrap";
import CircularGraph from "../../../theme/images/circular_graph.png";
import MainCard from "../../../components/common/MainCard/MainCard";
import ButtonOutline from "../../../components/common/ButtonOutline/ButtonOutline";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "./Dashboard.scss";
import { Link } from "react-router-dom";
import DeviceActivity from "./DeviceActivity";
import Announcement from "./Announcement";
import OpenOrder from "./OpenOrder";
import EyeIcon from "../../../theme/images/eye_icon.svg";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import FaitDeposit from "../../../theme/images/FaitDeposit.svg";
import CryptoDeposit from "../../../theme/images/CryptoDeposit.svg";
import NextArrow from "../../../theme/images/NextArrow.svg";
import { connect } from "react-redux";
import {
  getUserBalance,
  getWalletHistory,
  getActiveCoins,
} from "../../../redux/actions/WalletActions";
import {
  getUserKycDetails,
  getUserTrustedDevice,
  getAnnouncements,
  getUserActivities,
} from "../../../redux/actions/SecurityActions";

import { getOrderList } from "../../../redux/actions/OrderActions";

import { Doughnut, Chart, Line } from "react-chartjs-2";
import { KYC_APPROVED } from "../../../constant";
import socket from "../../../socket/index";
import DepositModal from "./DepositModal";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1280 },
    items: 1,
  },
  tablet: {
    breakpoint: { max: 1280, min: 464 },
    items: 1,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

function Dashboard(props) {
  const { walletbalance } = props;
  const lineChartCurrency = "USD";
  const [totalValue, setTotalValue] = useState(0.0);
  const [pieData, setPieData] = useState([]);
  const [pieLegend, setPieLegend] = useState([]);
  const [pieLabels, setPieLabels] = useState([]);
  const [bgColors, setBgColor] = useState([]);
  const [activeCoin, setActiveCoin] = useState([]);
  const [securityCount, setSecurityCount] = useState(0);
  const [auth2faEnable, setAuth2faEnable] = useState(0);
  const [trustedDevice, setTrustedDevice] = useState([]);
  const [announcement, setAnnouncement] = useState([]);
  const [activities, setActivities] = useState([]);

  useEffect(async () => {
    if (
      props?.user_info_status?.is_google_2fa_active == 1 ||
      props?.user_info_status?.is_email_active == 1
    ) {
      await setAuth2faEnable(1);
    }
  }, [props?.user_info_status?.is_google_2fa_active]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getActiveCoins();
    getUserKycDetails();
    getUserTrustedDevice();
    getUserActivities();
    getOpenOrder();
    if (announcement && announcement.length == 0) {
      getAnnouncements();
    }
  }, []);

  useEffect(() => {
    if (walletbalance.length > 0) {
      getUserBalance();
    }
  }, [walletbalance]);

  useEffect(() => {
    if (bgColors && bgColors.length >= 0) {
      getPieChart();
    }
  }, [bgColors, props.theme]);

  const getOpenOrder = (historyPage) => {
    let data = {
      page: 1,
      pagination: "",
      search: "",
      pair: "all",
      status: 1,
      type: "",
      fromDate: "",
      toDate: "",
      order_type: 0,
    };
    props.getOrderList(data);
  };

  const getUserActivities = () => {
    props
      .getUserActivities()
      .then((res) => {
        setActivities(res.data.data.activityData);
      })
      .catch((error) => {});
  };

  socket.on("annoucement", (data) => {
    getAnnouncements();
  });

  const getAnnouncements = () => {
    props
      .getAnnouncements()
      .then((res) => {
        setAnnouncement(res.data.data);
      })
      .catch((error) => {});
  };
  const getActiveCoins = () => {
    props
      .getActiveCoins()
      .then((res) => {
        setActiveCoin(res.data.coins);
      })
      .catch((error) => {});
  };

  const getUserKycDetails = async () => {
    props
      .getUserKycDetails()
      .then(async (res) => {
        //await setKycGetDetails(res.data.data);
        if (res.data.data.status == KYC_APPROVED) {
          await setSecurityCount(1);
        }
      })
      .catch((error) => {
        //setIsKycRes(true);
      });
  };

  const [modalShowDeposit, setModalShowDeposit] = React.useState(false);
  const history = useHistory();
  const handleClick = () => history.push("/auth/disableaccount");
  const withdrawPage = () =>
    history.push(`/auth/deposit?getCoin=${activeCoin[0]}&tab=Withdraw`);

  const getUserBalance = () => {
    if (walletbalance && walletbalance.length > 0) {
      // props
      //   .getUserBalance(lineChartCurrency)
      //   .then((res) => {
      // let record = walletbalance;
      let resData = [];
      walletbalance.forEach((item, i) => {
        let balance = item?.price * (item?.balance / 100000000);
        resData.push({
          price: balance,
          full_name: item.full_name.toUpperCase(),
        });
      });
      if (resData && resData.length > 0) {
        resData.sort(function (a, b) {
          return b.price - a.price;
        });

        let totalPrice = resData.reduce(function (accumulator, item) {
          return accumulator + item.price;
        }, 0);
        setTotalValue(totalPrice.toFixed(2));
        let chartPercent = [];
        let ChartVal = [];
        let chartLables = [];
        let pieColors = [
          "#ffca00",
          "#C52B2B",
          "#329BFF",
          "#FF5700",
          "#555470",
          "#00BE00",
        ];
        let bgColors = [];
        let fiveCoinPrice = [];
        resData &&
          resData.length > 0 &&
          resData.forEach((item, i) => {
            if (chartPercent.length < 5) {
              fiveCoinPrice.push(item.price);
              let priceVal = (item.price / totalPrice) * 100;
              chartPercent.push(priceVal.toFixed(4));
              ChartVal.push({
                name: item.full_name,
                percentVal: priceVal.toFixed(4),
              });
              chartLables.push(item.full_name);
              bgColors.push(pieColors[i]);
            }
          });

        //for other coins start
        if (resData && resData.length > 5) {
          let otherTotalPrice = fiveCoinPrice.reduce(function (index, item) {
            return index + parseFloat(item);
          }, 0);
          let otherPrice;
          if (totalPrice > otherTotalPrice) {
            otherPrice = totalPrice - otherTotalPrice;
          } else {
            otherPrice = otherTotalPrice - totalPrice;
          }
          let otherPriceVal = (otherPrice / totalPrice) * 100;
          chartPercent.push(otherPriceVal.toFixed(4));
          ChartVal.push({
            name: "Others",
            percentVal: otherPriceVal.toFixed(4),
          });
          chartLables.push("others");
          bgColors.push(pieColors[5]);
        }
        //for other coins end
        setPieData(chartPercent);
        setPieLegend(ChartVal);
        setPieLabels(chartLables);
        setBgColor(bgColors);
      }
      // })
      // .catch((error) => {});
    }
  };

  //pie chart start
  // const peiChartStart = () => {
  const chartData = pieData;
  const showData = `${totalValue} ${lineChartCurrency}`;
  const data1 = {
    labels: pieLabels,
    datasets: [
      {
        data: chartData,
        backgroundColor: bgColors,
        borderWidth: 0,
      },
    ],
    text: showData,
  };
  const getPieChart = () => {
    var originalDoughnutDraw = Chart.controllers.doughnut.prototype.draw;
    Chart.helpers.extend(Chart.controllers.doughnut.prototype, {
      draw: function () {
        originalDoughnutDraw.apply(this, arguments);
        let fillColor = props.theme;
        var chart = this.chart;
        var width = chart.chart.width,
          height = chart.chart.height,
          ctx = chart.chart.ctx;
        var fontSize = 2;
        ctx.font = fontSize + "em sans-serif";
        ctx.fillStyle = fillColor == "dark" ? "#131841" : "#fff";
        ctx.textBaseline = "middle";
        var text = chart.config.data.text,
          textX = Math.round((width - ctx.measureText(text).width) / 2),
          textY = height / 2;
        ctx.fillText(text, textX, textY);
      },
    });
  };

  const options1 = {
    responsive: true,
    legend: {
      display: false,
      position: "bottom",
      border: "none",
      labels: {
        fontSize: 18,
        fontColor: "#6D7278",
        fontFamily: "kanit light",
      },
    },
    cutoutPercentage: 90,
  };
  //pie chart end
  // };

  const getUserTrustedDevice = () => {
    props
      .getUserTrustedDevice()
      .then((res) => {
        setTrustedDevice(res.data.data.agentInfo);
      })
      .catch((error) => {});
  };

  return (
    <>
      <div className="dashboard_Style">
        {/* Balance detail top row */}
        <Row>
          <Col lg={6} xl={8} className="balanceCard_Col">
            <MainCard className="balanceCard mb-0">
              <Card.Title className="cardTitle_Padding forBtn_heading">
                Balance Detail
                <div className="d-flex align-items-center">
                  <ButtonOutline
                    onClick={() => setModalShowDeposit(true)}
                    buttontext="Deposit"
                    className="outlineBtn_commn modalBtn"
                  />
                  <DepositModal
                    show={modalShowDeposit}
                    onHide={() => setModalShowDeposit(false)}
                  />
                  <ButtonOutline
                    buttontext="Withdraw"
                    className="outlineBtn_commn modalBtn"
                    onClick={withdrawPage}
                  />
                  <Link
                    to={`/auth/wallet?getCoin=${activeCoin[0]}&tab=Withdraw`}
                    className="backarrow_style"
                  />
                </div>
              </Card.Title>
              <Row className="m-0 balanceRow">
                <Col lg={12} xl={4}>
                  <p className="balance_txt">
                    Account Balance <img src={EyeIcon} /> <br />
                    <span>
                      {totalValue} {lineChartCurrency}
                    </span>
                  </p>
                  {/* <p className="balance_txt">
                  Estimated Value <br />
                  <span>$400.09</span>
                </p> */}
                </Col>
                {totalValue > 0 && bgColors.length > 0 && (
                  <Col lg={12} xl={8}>
                    <Row className="fundsAllocation_Row m-0">
                      <Col
                        xs={12}
                        sm={12}
                        md={12}
                        lg={12}
                        xl={8}
                        className="fundsAllocation_graph p-0"
                      >
                        <Doughnut
                          data={data1}
                          options={options1}
                          height={360}
                        />
                      </Col>
                      <Col
                        xs={12}
                        sm={12}
                        md={12}
                        lg={12}
                        xl={4}
                        className="fundsAllocation_List"
                      >
                        <ul>
                          {pieLegend &&
                            pieLegend.length > 0 &&
                            pieLegend.map((item) => {
                              return (
                                <li>
                                  <h2>
                                    {item.percentVal == "NaN" ||
                                    item.percentVal <= 0
                                      ? 0.0
                                      : item.percentVal}
                                    %
                                  </h2>
                                  <p>{item.name}</p>
                                </li>
                              );
                            })}
                        </ul>
                      </Col>
                    </Row>
                  </Col>
                )}
              </Row>
            </MainCard>
          </Col>
          <Col lg={6} xl={4}>
            <MainCard className="rewardCard">
              <Card.Title className="cardTitle_Padding earnHeading_style">
                Earn upto 20% commission: Invite your friends now!
                <Link
                  to="/auth/referral"
                  className="backarrow_style referralArrow"
                />
              </Card.Title>
            </MainCard>
            <MainCard className="announcementcard mb-0">
              <Card.Title className="cardTitle_Padding">
                Announcements
                {/* <Link to="#" className="backarrow_style" /> */}
              </Card.Title>

              <ListGroup>
                <PerfectScrollbar
                  options={{ onScrollX: true, suppressScrollX: true }}
                  // onScrollY={(container) =>
                  //   console.log(`scrolled to: ${container.scrollTop}.`)
                  // }
                >
                  {announcement &&
                    announcement.length > 0 &&
                    announcement.map((res) => {
                      return (
                        <Announcement
                          title={res?.title}
                          content={res?.description}
                          date={res?.created_at}
                        />
                      );
                    })}
                </PerfectScrollbar>
              </ListGroup>
            </MainCard>
          </Col>
        </Row>
        {/* Balance detail second row */}
        <Row>
          <Col lg={6} xl={8} className="pe-0">
            {/* device activity card */}
            <MainCard className="deviceActivity_Card mb-0">
              <Card.Title className="cardTitle_Padding forBtn_heading">
                <div className="d-flex align-items-center">
                  {/* <ButtonOutline
                  buttontext="Disable Account"
                  className="outlineBtn_commn modalBtn disableAccount_Btn"
                  onClick={handleClick}
                /> */}
                  <Link
                    to="/auth/device-management"
                    className="backarrow_style"
                  />
                </div>
              </Card.Title>
              <Tabs
                defaultActiveKey="Activity"
                transition={true}
                id="noanim-tab-example"
                className="deviceActivity_Tab"
              >
                <Tab eventKey="Activity" title="Activity">
                  <ListGroup>
                    <PerfectScrollbar
                      options={{ onScrollX: true, suppressScrollX: true }}
                    >
                      {activities &&
                        activities.length > 0 &&
                        activities.map((res) => {
                          return (
                            <DeviceActivity
                              device={res?.type}
                              location={res?.meta_data}
                              ip={res?.ip_address}
                              date={res?.created_at}
                            />
                          );
                        })}
                    </PerfectScrollbar>
                  </ListGroup>
                </Tab>
                <Tab eventKey="Devices" title="Devices">
                  <ListGroup>
                    <PerfectScrollbar
                      options={{ onScrollX: true, suppressScrollX: true }}
                      // onScrollY={(container) =>
                      //   console.log(`scrolled to: ${container.scrollTop}.`)
                      // }
                    >
                      {trustedDevice &&
                        trustedDevice.length > 0 &&
                        trustedDevice.map((item) => {
                          return (
                            <DeviceActivity
                              device={!!item.device ? item.device : "Other"}
                              location={item.location}
                              ip={item.ipAddress}
                              date={item.updated_at}
                            />
                          );
                        })}
                    </PerfectScrollbar>
                  </ListGroup>
                </Tab>
              </Tabs>
            </MainCard>
          </Col>

          <Col lg={6} xl={4}>
            {/* account seurity card */}
            <MainCard className="accountSecurity_Card mb-0">
              <Card.Title className="cardTitle_Padding">
                Increase your Account Security
                <div className="d-flex align-items-center">
                  {+auth2faEnable + +securityCount}/2
                  <span
                    className={
                      auth2faEnable == 1
                        ? "indicationBar ml-2 isEnabled"
                        : "indicationBar ml-2"
                    }
                  />
                  <span
                    className={
                      securityCount == 1
                        ? "indicationBar ml-2 isEnabled"
                        : "indicationBar ml-1"
                    }
                  />
                  <Link to="/auth/setting" className="backarrow_style" />
                </div>
              </Card.Title>
              <Row className="accoutSecurity_Row">
                <Col xs={12} md={6}>
                  <h3
                    className="linkClasss"
                    onClick={() => {
                      history.push("/auth/select-auth");
                    }}
                  >
                    Enable 2FA <br />
                    {auth2faEnable == 1 ? (
                      <small className="enabled">Enabled</small>
                    ) : (
                      <small className={`disabled`}>Disabled</small>
                    )}
                  </h3>
                </Col>
                <Col xs={12} md={6}>
                  <h3
                    className="linkClasss"
                    onClick={() => {
                      history.push("/auth/kycnotsubmit");
                    }}
                  >
                    Identity Verification (KYC) <br />
                    {securityCount == 1 ? (
                      <small className="enabled">Verified</small>
                    ) : (
                      <small className={`disabled`}>Unverified</small>
                    )}
                  </h3>
                </Col>
              </Row>
            </MainCard>
          </Col>
        </Row>
        {/* Balance detail third row */}
        <Row className="mb-0">
          <Col lg={12} md={12}>
            <MainCard className="openOrder_Card">
              <div className="openorder_head">
                <p>Open Orders</p>
                <Link to="/auth/orders" className="backarrow_style" />
              </div>
              <div className="tableOuter_Div deposit_Table">
                <OpenOrder openorder={props.ordersHistory} />
              </div>
            </MainCard>
          </Col>
        </Row>
      </div>
    </>
  );
}

//export default Dashboard;

const mapStateToProps = (state) => {
  return {
    theme: state.persist.theme ? "dark" : "light",
    user_info_status: state.security.user_info_status,
    ordersHistory: state.orders.ordersHistory,
    walletbalance: state.walletbalance.walletbalance,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getOrderList: (data) => dispatch(getOrderList(data)),
    // updateUserKyc: (data) => dispatch(updateUserKyc(data)),
    getActiveCoins: () => dispatch(getActiveCoins()),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),
    getWalletHistory: () => dispatch(getWalletHistory()),
    getUserKycDetails: () => dispatch(getUserKycDetails()),
    getUserTrustedDevice: () => dispatch(getUserTrustedDevice()),
    getAnnouncements: () => dispatch(getAnnouncements()),
    getUserActivities: () => dispatch(getUserActivities()),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);

// Deposit Modal
