import React from "react";
import { Row, Col, ListGroup } from "react-bootstrap";
import moment from "moment";

function DeviceActivity(props) {
  return (
    <>
      <ListGroup.Item>
        <Row>
          <Col lg={8} md={8} sm={8} xs={8}>
            <p>{props.device}</p>
            <a> {props.location}</a>
          </Col>
          <Col lg={4} md={4} sm={4} xs={4} className="text-right">
            <p> {!!props.ip && props?.ip != 'undefined' ?  props.ip : ''}</p>
            <a> {moment(props.date).format('MMM DD YY, h:mm:ss a')}</a>
          </Col>
        </Row>
      </ListGroup.Item>
    </>
  );
}

export default DeviceActivity;
