import React, { useState } from "react";
import { Row, Col, ListGroup, Modal, Button } from "react-bootstrap";
import moment from "moment";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
function Announcement(props) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = (data) => {
    setModalData(data)
    setShow(true);

  }
const [modalData,setModalData] = useState('')

  return (
    <>
      <ListGroup.Item
        onClick={()=>{handleShow(props)}}
        className="d-flex justify-content-between"
      >
        <Col lg={6} md={6} className="p-0">
          <p className="announceTitle">{props.title}</p>
          {props.content.length > 40 ?
          <p>{`${props.content.substring(0,40)}...`}</p>
          :
          <p>{`${props.content}`}</p>

          }

        </Col>
        <Col lg={3} md={3} className="text-right p-0">
          <a>{moment(props.date).format("DD-MMM-YYYY")}</a>
        </Col>
      </ListGroup.Item>

      {/* notification modal */}
      <Modal
        show={show}
        onHide={handleClose}
        centered
        className="annoucementModal"
      >
        <Modal.Header closeButton>
          <Modal.Title>{modalData?.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        {modalData?.content}
        </Modal.Body>
        <Modal.Footer>
          <ButtonPrimary buttontext="Close" onClick={handleClose} className="annoucementClose internalComn_btn" />
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default Announcement;
