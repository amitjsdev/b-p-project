import React, { useEffect, useState } from "react";
import { Row, Col, Card, ListGroup, Tabs, Tab, Modal } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "./Dashboard.scss";
import { Link } from "react-router-dom";
import "react-multi-carousel/lib/styles.css";
import FaitDeposit from "../../../theme/images/FaitDeposit.svg";
import CryptoDeposit from "../../../theme/images/CryptoDeposit.svg";
import NextArrow from "../../../theme/images/NextArrow.svg";


function DepositModal(props) {
    return (
      <div>
        <Modal
          {...props}
          size="lg"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          className="DisableAccountModal SecurityVerification DepostModal"
        >
          <Modal.Header closeButton>
            <Modal.Title id="contained-modal-title-vcenter">Deposit </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="textDiv">
              <h4 className="modalHeading">Select a way to deposit</h4>
            </div>
  
            <div className="bottomSecOuter">
              <Row className="btnsRow DepositRow">
                <Col className="googleAuthCol" xs={12}>
                  <div className="authOuterDiv depositauthOuterDiv">
                    <div className="depositInnerDiv">
                      <div className="imgSec">
                        <img src={FaitDeposit} />
                      </div>
                      <h4 className="actionsText">Deposit Crypto via Fiat</h4>
                    </div>
                    <div className="nextDiv">
                      <Link to="/auth/deposit">
                        <img src={NextArrow} />
                      </Link>
                    </div>
                  </div>
                </Col>
                <Col className="googleAuthCol" xs={12}>
                  <div className="authOuterDiv depositauthOuterDiv">
                    <div className="depositInnerDiv">
                      <div className="imgSec">
                        <img src={CryptoDeposit} />
                      </div>
                      <h4 className="actionsText">Deposit Crypto</h4>
                    </div>
                    <div className="nextDiv">
                      <Link to="/auth/deposit">
                        <img src={NextArrow} />
                      </Link>
                    </div>
                  </div>
                </Col>
              </Row>
              <Row className="btnsRow">
                <Col xs={12} className="btnsCol">
                  <ButtonPrimary
                    buttontext="Remind me Later"
                    className="internalComn_btn mb-0 authenticationBtn"
                  />
                </Col>
              </Row>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
  

export default DepositModal;
  