import React from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "../../../components/common/CustomTable/CustomTable.scss";
import { smallestunitFormat, bn_operations } from "../../../Helpers/Normailize";
import moment from "moment";

function OpenOrder(props) {
  const {openorder} = props;
  return (
    <PerfectScrollbar
      // onScrollY={(container) =>
      //   console.log(`scrolled to: ${container.scrollTop}.`)
      // }
    >
     {!!openorder && (
        <>
              <Table className={`customTable ${props.className}`}>
                <thead>
                  <tr>
                  <th>Date</th>
                    <th>Price</th>
                    <th>Type</th>
                    <th>Side</th>
                    <th>Excuted Price</th>
                    <th>Filled</th>
                    <th>Amount</th>
                    <th>Total</th>
                    <th>Status</th>
                  </tr>
                </thead>
                {/* NO RECORD FOUND */}
                <tbody>
                  {openorder && openorder?.data.length > 0 ? (
                    openorder?.data.map((item) => {
                      let totalAmount =
                        smallestunitFormat(item?.price) *
                        smallestunitFormat(item?.amount);
                      return (
                        <tr>
                          <td>
                            {moment(item?.created_at).format("DD-MMM-YYYY")}
                          </td>
                          <td>${smallestunitFormat(item?.price)}</td>
                          <td>{item?.type == 1 ? "Market" : "Limit"}</td>
                          <td>{item?.side == 0 ? "Buy" : "Sell"}</td>
                          <td>${smallestunitFormat(item?.excuted_price,8)}</td>
                          <td>${smallestunitFormat(item?.filled_amount,8)}</td>
                          <td>${smallestunitFormat(item?.amount,8)}</td>
                          <td>${totalAmount.toFixed(2)}</td>
                          <td>
                            {item?.status == 1
                              ? "Open"
                              : item?.status == 2
                              ? "Cancelled"
                              : item?.status == 1 &&
                                smallestunitFormat(item?.filled_amount) > 0
                              ? "Partial Open"
                              : item?.status == 2 &&
                                smallestunitFormat(item?.filled_amount) > 0
                              ? "Partial cancelled"
                              : item?.status == 3
                              ? "Completed"
                              : "-"}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="10"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
              {/* {openorder && openorder?.data.length > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e, "open")}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(openorder?.total / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )} */}
          {/* end open Order */}
        </>
      )}
    </PerfectScrollbar>
  );
}

export default OpenOrder;