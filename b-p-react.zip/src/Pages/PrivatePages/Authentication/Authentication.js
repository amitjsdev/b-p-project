import React, { useEffect } from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import WarningIcon from "../../../theme/images/warning_icon.svg";
import "./Authentication.scss";
import {
  getUserProfile,
  getUserInfo,
} from "../../../redux/actions/SecurityActions";
import { connect } from "react-redux";
import { withRouter } from "react-router";

function Authentication(props) {
  let history = useHistory();
  const [infoStatus, setInfoStatus] = React.useState({});
  useEffect(() => {
    getUserInfoStatus();
    return () => {};
  }, []);

  const getUserInfoStatus = () => {
    props
      .getUserInfo()
      .then((res) => {
        setInfoStatus(res.data.data);
      })
      .catch((error) => {});
  };

  const handleClick = () => {
    history.push("/auth/select-auth");
  };
  // const handleClick = () => {
  //   history.push("/auth/enable-authentication");
  // };
  const handleClickDisabled = () => {
    history.push("/auth/select-auth");
    // history.push("/auth/disable-authentication");
  };
  return (
    <>
      {/* <Col xs={12} lg={6} xl={6} className="mx-auto"> */}
      <MainCard className="mainCard_padding authCard_style enableAuth_style">
        <Card.Title className="cardTitle_Padding">
          2-Factor Authentication
        </Card.Title>
        <Col className="text-center authenticationCol_style">
          <div className="warningIcon">
            <img src={WarningIcon} />
          </div>
          {infoStatus && infoStatus?.is_google_2fa_active == 0  && infoStatus?.is_email_active == 0 ? (
            <>
              <p className="warningTxt_style">
                We strongly recommend turning on MFA as an added layer of
                security Enabling MFA helps keep your account safe from hackers.
              </p>
              <ButtonPrimary
                buttontext="Turn ON 2FA"
                className="internalComn_btn mb-0 authenticationBtn"
                onClick={handleClick}
              />
            </>
          ) : (
            <>
              <p className="warningTxt_style">
                Enabling 2FA helps keep your account safe.
                <br />
                We strongly recommend you keep 2FA turned on.
              </p>
              <ButtonPrimary
                buttontext="Turn OFF 2FA"
                className="internalComn_btn mb-0 authenticationBtn"
                onClick={handleClickDisabled}
              />
            </>
          )}
        </Col>
      </MainCard>
      {/* </Col> */}
    </>
  );
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    getUserInfo: () => dispatch(getUserInfo()),
    getUserProfile: () => dispatch(getUserProfile()),
  };
};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Authentication)
);
