import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import ReactCodeInput from "react-code-input";
import ButtonPrimary from "../../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../../components/common/MainCard/MainCard";
import CustomInput from "../../../../components/common/CustomInput/CustomInput";
import CopyIcon from "../../../../theme/images/copy_icon.svg";
import "../../../PublicPages/AuthenticationCode/AuthenticationCode.scss";
import "../Authentication.scss";
import copy from "copy-to-clipboard";
import { Form } from "react-bootstrap";
import "../../../../components/common/CustomInput/CustomInput.scss";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import { google2faValidate, get2FaImage } from "../../../../redux/actions/SecurityActions";



function AuthCode(props) {
  let history = useHistory();
  const handleClick = () => {
    history.push("/auth/disable-authentication");
  };
  const [token, setToken] = useState("");
  const [copyText, setCopyText] = useState(props?.secret);
  const [copied, setCopied] = useState(false);
 let currentIp = localStorage.getItem('currentIp');

  const enableUserGoogleAuth = () => {
    let data = {
      acceptTerms: true,
      secret: props.secret,
      token: token,
      ip: currentIp,
    }
    props.google2faValidate(data).then((res) => {
      if(!!props?.location?.state?.withdraw){
        window.location.replace(props?.location?.state?.withdraw)
      }else{
        window.location.replace('/auth/select-auth')
      }
    }).catch((error) => {
    })
  }

  const handleCopyText = (e) => {
    setCopyText(e.target.value);
  }

  const copyToClipboard = () => {
    copy(copyText);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 5000);
  }

  useEffect(() => {
    if(!props?.secret){
      history.push('/auth/enable-authentication')
    }
    // props.get2FaImage({ "issuer": "" })

  }, [])

  return (
    <>
      {/* <Col xs={12} lg={7} className="mx-auto commonCol_width"> */}
      <MainCard className="mainCard_padding googleAuth_Main authCard_style">
        <Card.Title className="cardTitle_Padding">
          Google Authentication
        </Card.Title>
        <Row className="googleAuth_Row authCont_Style">
          <h3>
            Keep a physical or digital copy of your backup<br />
            code to stay secure.
          </h3>
          <Col xs={12} md={12} lg={12}>
            <Form.Group
              className={`customInput internalInput`}
            >
              <Form.Control
                // defaultValue={}
                disabled={true}
                value={copyText}
                onChange={handleCopyText}
              />
              <a onClick={copyToClipboard} className={`${copied ? 'copiedIocnAuth ' : ''  }showPassword`}>
                <img src={CopyIcon} />
              </a>
              {copied && <p>Copied</p>}
            </Form.Group>

          </Col>
          <Col xs={12} md={12} lg={12}>
            <p className="info_msg">
              We do not recommend sharing or publishing the backup code
              anywhere or with anyone.
            </p>
            <h3>6 digit code displayed by your app</h3>
          </Col>
          <Col xs={12} md={12} lg={12} className="d-flex justify-content-center">
            <ReactCodeInput type="number" value={token} onChange={(code) => setToken(code)} fields={6} />
          </Col>
          <Col xs={12} md={12} lg={12}>
            <ButtonPrimary
              disabled={token.length !== 6}
              onClick={() => enableUserGoogleAuth()}
              buttontext="Continue" className="internalComn_btn" />
          </Col>
        </Row>
      </MainCard>
      {/* </Col> */}
    </>
  );
}



const mapStateToProps = state => {
  return {
    isUserFirstTimeLogin: state.persist.isUserFirstTimeLogin,
    secret: state.security.secret,
    qrImgUrl: state.security.qrImgUrl

  };
};

const mapDispatchToProps = dispatch => {
  return {
    google2faValidate: (data) => dispatch(google2faValidate(data)),
    // get2FaImage: (data) => dispatch(get2FaImage(data))

  };
};
export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(AuthCode));