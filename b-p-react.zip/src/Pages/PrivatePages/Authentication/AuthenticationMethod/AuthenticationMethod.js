import React from "react";
import "./AuthenticationMethod.scss";
import MainCard from "../../../../components/common/MainCard/MainCard";
import { useHistory } from "react-router-dom";
import { Card } from "react-bootstrap";
import EmailVerify from "../../../../theme/images/email_verify.png";
import Shield from "../../../../theme/images/shield.png";
import ButtonPrimary from "../../../../components/common/ButtonPrimary/ButtonPrimary";
import { connect } from "react-redux";

const AuthCard = ({ img, title, text, buttontext, onClick }) => {
  return (
    <Card>
      <div className="authImg">
        <Card.Img src={img} />
      </div>
      <Card.Body>
        <Card.Title>{title}</Card.Title>
        <Card.Text>{text}</Card.Text>
        <ButtonPrimary
          buttontext={buttontext}
          onClick={onClick}
          className="mb-0 internalComn_btn"
        />
      </Card.Body>
    </Card>
  );
};

const AuthenticationMethod = (props) => {
  const {infoStatus} = props;
  let history = useHistory();
  const googleAuth = () => {

    if(infoStatus && infoStatus?.is_google_2fa_active == 0){
      history.push("/auth/enable-authentication");

    }else{
      history.push("/auth/disable-authentication");

    }



    
  };
  const emailAuth = () => {
    history.push("/auth/2fa-with-email");
  };
  return (
    <MainCard title="Choose your Method" className="authMethod_Main">
      <div className="authMethod_Wrap">
        <AuthCard
          img={Shield}
          // title={`${infoStatus && infoStatus?.is_google_2fa_active == 0 ? 'Enable ' : 'Disable '}With Google Auth`}
          title={`Google Auth`}

          text="Some quick example text to build on the card title and make up the
              bulk of the card's content."
              buttontext={`${infoStatus && infoStatus?.is_google_2fa_active == 0 ? 'Enable ' : 'Disable '}`}
              onClick={googleAuth}
        />
        <AuthCard
          img={EmailVerify}
          title={`Email Auth`}

          text="Some quick example text to build on the card title and make up the
              bulk of the card's content."
          buttontext={`${infoStatus && infoStatus?.is_email_active == 0 ? 'Enable ' : 'Disable '}`}
          onClick={emailAuth}
        />
      </div>
    </MainCard>
  );
};



const mapStateToProps = state => {
  return {
      infoStatus:state.security.user_info_status

  };
};

const mapDispatchToProps = dispatch => {
  return {
     
  
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AuthenticationMethod);