import React from "react";
import { useHistory } from "react-router-dom";
import MainCard from "../../../../components/common/MainCard/MainCard";
import CustomInput from "../../../../components/common/CustomInput/CustomInput";
import ReactCodeInput from "react-code-input";
import ButtonPrimary from '../../../../components/common/ButtonPrimary/ButtonPrimary'
import "./EnableWithEmail.scss";
import { connect } from "react-redux";
import {send2faEmailVerification,token_verification} from "../../../../redux/actions/SecurityActions";


const EnableWithEmail = (props) => {
  const {infoStatus} = props;

    let history = useHistory();
    const handleSubmit = () => {
      history.push("/auth/setting");
    };

    const [token, setToken] = React.useState("");
    React.useEffect(()=>{
        props.send2faEmailVerification();
    },[])

    const enableDisableEmailAuth = ()=>{
        let data = {

            isEnabled: infoStatus.is_email_active ==0 ? true:false,
            token: token
        }
        props.token_verification(data).then((res)=>{

            setTimeout(()=>{
                window.location.replace("/auth/select-auth");

            },1000)
        }).catch((error)=>{
        })
    }

  return (
    <MainCard 
    title={`Email Authentication`}
    // title={`${infoStatus && infoStatus?.is_email_active == 0 ? 'Enable ' : 'Disable '}With Email`}
    className="enableEmail_Main">
      <div className="enableEmail_Wrap">
        {/* <CustomInput className="internalInput" placeholder="Email" label="Email Addresses"/> */}
        <p>Enter Your OTP</p>
        <ReactCodeInput type='text' fields={5}  value={token} onChange={(code)=>setToken(code)}/>
        <ButtonPrimary buttontext="Submit" className="internalComn_btn mb-0" onClick={enableDisableEmailAuth}/>
      </div>
    </MainCard>
  );
};


const mapStateToProps = state => {
  return {
      infoStatus:state.security.user_info_status

  };
};

const mapDispatchToProps = dispatch => {
  return {
      send2faEmailVerification: () => dispatch(send2faEmailVerification()),
      token_verification:(data)=>dispatch(token_verification(data))
  
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EnableWithEmail);