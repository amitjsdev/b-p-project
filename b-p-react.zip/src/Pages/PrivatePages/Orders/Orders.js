import React, { useEffect, useState } from "react";
import { Row, Col, Tabs, Tab } from "react-bootstrap";
import MainCard from "../../../components/common/MainCard/MainCard";
import "./Order.scss";
import OrderTable from "./OrderTable";
import { connect } from "react-redux";

import {
  getOrderList,
  getPairList,
  getTradeHistory,
} from "../../../redux/actions/OrderActions";
import moment from "moment";

function Orders(props) {
  const [pairType, setPairType] = useState("all");
  const [orderDateRange, setOrderDateRange] = useState([null, null]);
  const [startOrderDate, endOrderDate] = orderDateRange;
  const [orderStatus, setOrderStatus] = useState("all");
  const [orderPairType, setOrderPairType] = useState("all");
  const [orderSide, setOrderSide] = useState("all");
  const [pageVal, setPageVal] = useState(1);
  const [tradePair, setTradePair] = useState('all');

 

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    // props.getReferralHistory({offset:0});
    //getOrderList('OPEN');
    props.getPairList();
    getOpenOrder();
  }, []);

  const getOpenOrder = (historyPage) => {
    let currentPage = !!historyPage ? historyPage : pageVal;
    let data = {
      page: currentPage,
      pagination: "",
      search: "",
      pair: pairType,
      status: 1,
      type: "",
      fromDate: "",
      toDate: "",
      order_type: 0,
    };
    props.getOrderList(data);
  };

  const getOrderList = (historyPage) => {
    let currentPage = !!historyPage ? historyPage : pageVal;
    let startDate =
      startOrderDate !== null
        ? moment(startOrderDate).format("YYYY-MM-DD")
        : "";
    let endDate =
      endOrderDate !== null ? moment(endOrderDate).format("YYYY-MM-DD") : "";
    let data = {
      page: currentPage,
      pagination: "",
      search: "",
      pair: orderPairType,
      status: orderStatus  == 'completed' ? '3' 
      : orderStatus  == 'cancelled' ? '2' : orderStatus,
      type: orderSide,
      fromDate: startDate,
      toDate: endDate,
    };
    props.getOrderList(data);
  };

  const getTradeHistory = (historyPage) => {
    let currentPage = !!historyPage ? historyPage : pageVal;
    let data = {
      page: currentPage,
      pair: tradePair,
      type: 0,
    };
    props.getTradeHistory(data);
  };

  const getCurrentHistory = (value, pageVal) => {
    setPairType('all')
    setOrderDateRange([null, null])
    setOrderStatus('all')
    setOrderPairType('all')
    setOrderSide('all')
    setTradePair('all')

    if (value === "openOrder") {
      getOpenOrder(pageVal);
    } else if (value === "orderHistory") {
      getOrderList(pageVal);
    } else {
      getTradeHistory(pageVal);
    }
  };
  return (
    <>
      <Row className="orderTable_card">
        <Col xs={12} className="tableCol_Style">
          <MainCard title="&nbsp;">
            <Tabs
              defaultActiveKey="openOrder"
              transition={true}
              className="tableTab_style"
              onSelect={(e) => {
                getCurrentHistory(e, 1);
              }}
            >
              <Tab eventKey="openOrder" title="Open Orders">
                <OrderTable
                openorderTab
                  setPageVal={setPageVal}
                  getOpenOrder={getOpenOrder}
                  pairType={pairType}
                  getOrderList={getOrderList}
                  setPairType={setPairType}
                  openorder={props.ordersHistory}
                  pairList={props.pairList}
                />
              </Tab>
              <Tab eventKey="orderHistory" title="Order History">
                <OrderTable
                  orderHistoryTab
                  setPageVal={setPageVal}
                  ordersHistory={props.ordersHistory}
                  orderStatus={orderStatus}
                  orderPairType={orderPairType}
                  orderSide={orderSide}
                  setOrderSide={setOrderSide}
                  setOrderPairType={setOrderPairType}
                  setOrderStatus={setOrderStatus}
                  endOrderDate={endOrderDate}
                  startOrderDate={startOrderDate}
                  setOrderDateRange={setOrderDateRange}
                  pairType={pairType}
                  getOrderList={getOrderList}
                  setPairType={setPairType}
                  pairList={props.pairList}
                />
              </Tab>
              <Tab eventKey="tradeHistory" title="Trade History">
                <OrderTable
                  pairList={props.pairList}
                  setPageVal={setPageVal}
                  tradeHistory={props.tradeHistory}
                  getTradeHistory={getTradeHistory}
                  setTradePair={setTradePair}
                  tradePair={tradePair}
                />
              </Tab>
            </Tabs>
          </MainCard>
        </Col>
      </Row>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    // user_info_status: state.security.userProfile,
    // user_info_status: state.security.user_info_status,
    ordersHistory: state.orders.ordersHistory,
    pairList: state.orders.pairList,
    tradeHistory: state.orders.tradeHistory,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getOrderList: (data) => dispatch(getOrderList(data)),
    getPairList: () => dispatch(getPairList()),
    getTradeHistory: (data) => dispatch(getTradeHistory(data)),

    // getReferralHistory: (data) => dispatch(getReferralHistory(data)),
    // getCustomPlans: () => dispatch(getCustomPlans()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Orders);
