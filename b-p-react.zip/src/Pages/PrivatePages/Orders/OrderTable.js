import React, { useEffect, useState } from "react";
import { Table, Row, Col, FormLabel, Form } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import SelectPair from "../../../components/common/SelectPair/SelectPair";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "react-perfect-scrollbar/dist/css/styles.css";
import "../../../components/common/CustomTable/CustomTable.scss";
import DatePickerCustom from "../../../components/common/DatePickerCustom/DatePickerCustom";
import CustomCheckbox from "../../../components/common/CustomCheckbox/CustomCheckbox";
import ExportIcon from "../../../theme/images/export_icon.svg";
import CommonModal from "../../../components/common/CommonModal/CommonModal";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import CalanderIcon from "../../../theme/images/CalanderIcon.svg";

import "../../../components/common/CustomInput/CustomInput.scss";
import "react-datepicker/dist/react-datepicker.css";
import "../../../components/common/DatePickerCustom/DatePickerCustom.scss";
import moment from "moment";
import { findAllByTestId } from "@testing-library/dom";
import { smallestunitFormat, bn_operations } from "../../../Helpers/Normailize";

import ImportCsv from "../../../components/common/DownloadCSV";
import ReactPaginate from "react-paginate";
import { connect } from "react-redux";

import { orderHistoryCsv } from "../../../redux/actions/OrderActions";
import { toast } from "../../../components/Toast/Toast";

function OrderTable(props) {
  const {
    setTradePair,
    tradePair,
    getTradeHistory,
    setPageVal,
    getOpenOrder,
    openorder,
    tradeHistory,
    ordersHistory,
    orderSide,
    orderPairType,
    orderStatus,
    setOrderSide,
    setOrderPairType,
    setOrderStatus,
    setPairType,
    pairList,
    getOrderList,
    pairType,
    startOrderDate,
    endOrderDate,
    setOrderDateRange,
  } = props;
  const [modalShow, setModalShow] = React.useState(false);
  const [dateRange, setDateRange] = useState([null, null]);
  const [pairTypeName, setPairTypeName] = useState("");

  const [resetFilter, setResetFilter] = useState(false);
  const [checkedVal, setCheckedVal] = useState(false);

  const [exportVal, setExportVal] = useState("");
  const [startDateNew, setStartDateNew] = useState(null);
  const [endDateNew, setEndDateNew] = useState(null);

  const [exportData, setExportData] = useState("");

  const [filterTrade, setFilterTrade] = useState(false);
  const [hiddenFilter, setHiddenFilter] = useState(false);

  const [enableDatepicker, setEnableDatePicker] = useState(false);

  const [btnDisable, setBtnDisable] = useState(false);
  // const [statusData,setStatus]  = useState({})

  let statusData = [{ pair_name: "cancelled" }, { pair_name: "completed" }];
  let sideData = [{ pair_name: "buy" }, { pair_name: "sell" }];

  const [startDate, endDate] = dateRange;
  useEffect(() => {
    if (pairList && pairList.length > 0) {
      openOrder();
    }

    if (resetFilter) {
      getOrderList(1);
    }
  }, [pairType, resetFilter]);

  //hide cancelled
  useEffect(() => {
    if (pairList && pairList.length > 0) {
      if (hiddenFilter) {
        getOrderList(1);
        setHiddenFilter(false);
      }
    }
  }, [hiddenFilter]);
  //trade pair list
  useEffect(() => {
    if (pairList && pairList.length > 0) {
      if (filterTrade) {
        getTradeHistory(1);
        setFilterTrade(false);
      }
    }
  }, [filterTrade]);

  //openOrder for pair
  const openOrder = () => {
    if (pairTypeName == "open_pair") {
      getOpenOrder(1);
    }
  };

  const handleChangeSelect = (e) => {
    const { name, value } = e.target;
    if (name == "trade_pair") {
      setTradePair(value);
      setFilterTrade(true);
    }

    if (name == "open_pair") {
      setPairTypeName(name);
      setPairType(value);
    }
    if (name == "pair") {
      setOrderPairType(value);
    }
    if (name == "side") {
      setOrderSide(value);
    }

    if (name == "status") {
      setOrderStatus(value);
    }
  };

  const handleChange = (date) => {
    setOrderDateRange(date);
  };

  const handleClick = () => {
    setResetFilter(false);
    getOrderList(1);
  };

  const resetFilterFields = () => {
    setOrderPairType("all");
    setOrderSide("all");
    setOrderStatus("all");
    setOrderDateRange([null, null]);
    setResetFilter(true);
    // getOrderList('order_pair');
  };

  const handleCheckBox = (e) => {
    const { checked, value } = e.target;
    if (checked) {
      setOrderStatus("3");
      setCheckedVal(true);
    } else {
      setOrderStatus("all");
      setCheckedVal(false);
    }
    setHiddenFilter(true);
  };

  const exportHistory = (e) => {
    let type = e.target.value;
    var d = new Date();
    d.setMonth(d.getMonth() - 1);
    //praveen code
    const now = new Date();
    const today = new Date(now);
    today.setDate(today.getDate() - 1);
    var curDay = now.toISOString().slice(0, 10);
    var curTime = today.toLocaleTimeString({ hour12: true });

    var startDate = "";
    var endDate = "";
    if (type == 1) {
      setBtnDisable(false);
      //last_24_hours=1
      var yesterday = today.toISOString().slice(0, 10);
      startDate = yesterday + " " + curTime;
      endDate = curDay + " " + curTime;
      setStartDateNew(new Date(yesterday));
      setEndDateNew(new Date(curDay));
      setEnableDatePicker(true);
    } else if (type == 2) {
      setBtnDisable(false);
      //   yesterday=2
      var yesterday = today.toISOString().slice(0, 10);
      setStartDateNew(new Date(yesterday));
      setEndDateNew(new Date());
      setEnableDatePicker(true);
    } else if (type == 3) {
      setBtnDisable(false);
      //   past_month=3
      today.setMonth(today.getMonth() - 1);
      today.toISOString().slice(0, 10);
      var past_month = today.toISOString().slice(0, 10);
      setStartDateNew(new Date(past_month));
      setEndDateNew(new Date());
      setEnableDatePicker(true);
    } else if (type == 4) {
      setBtnDisable(false);
      //   past_3_month
      today.setMonth(today.getMonth() - 3);
      today.toISOString().slice(0, 10);
      var past_3_month = today.toISOString().slice(0, 10);
      setStartDateNew(new Date(past_3_month));
      setEndDateNew(new Date());
      setEnableDatePicker(true);
    } else if (type == 5) {
      setBtnDisable(false);
      //   within_6_month=5
      today.setMonth(today.getMonth() - 6);
      today.toISOString().slice(0, 10);
      var past_6_month = today.toISOString().slice(0, 10);
      setStartDateNew(new Date(past_6_month));
      setEndDateNew(new Date());
      setEnableDatePicker(false);
    } else {
      //   beyond_6_month=5

      if (type != "") {
        today.setMonth(today.getMonth() - 6);
        today.toISOString().slice(0, 10);
        var past_6_month = today.toISOString().slice(0, 10);
        setStartDateNew(new Date(type));
        setEndDateNew(new Date(past_6_month));
        setEnableDatePicker(false);
      } else {
        setBtnDisable(true);
        setStartDateNew(null);
        setEndDateNew(null);
      }
    }
    setExportVal(e.target.value);
  };

  const setCustomDateRanage = (val) => {
    if (val[0] != null) {
      setStartDateNew(val[0]);
    } else {
      setStartDateNew(null);
    }

    if (val[1] != null) {
      setEndDateNew(val[1]);
    } else {
      setEndDateNew(null);
    }

    // setStartDateNew(new Date(val[0]))
    //   setEndDateNew(new Date(val[1]))
  };

  const exportSubmit = (e) => {
    e.preventDefault();
    let startExportDate =
      startDateNew !== null ? moment(startDateNew).format("YYYY-MM-DD") : "";
    let endExportDate =
      endDateNew !== null ? moment(endDateNew).format("YYYY-MM-DD") : "";
    let data = {
      fromDate: startExportDate,
      toDate: endExportDate,
      record: exportVal,
    };
    props
      .orderHistoryCsv(data)
      .then((res) => {
        if (res?.data?.data.length > 0) {
          toast.success("Order list fetched successfully.");
          setExportData(res.data.data);
        } else {
          toast.success("No records found.");
        }
        setBtnDisable(true);
      })
      .catch((err) => {});

    // props.orderHistoryCsv(typeVal,newPage)

    // setExportData
  };

  const handlePageClick = (event, val) => {
    const newPage = event.selected + 1;
    setPageVal(newPage);
    if (val == "open") {
      getOpenOrder(newPage);
    }
    if (val == "order") {
      getOrderList(newPage);
    }

    if (val == "trade") {
      getTradeHistory(newPage);
    }
  };

  const emptyData = () => {
    // setExportData([])
    setTimeout(function () {
      setBtnDisable(false);
      setModalShow(false);
      setExportData([]);
    }, 2000);
  };
  return (
    <>
      {/* start open Order */}
      {props.openorderTab && !!openorder && (
        <>
          <Row className="topFilter_Row m-0">
            <Col lg={3}>
              <FormLabel>Filter</FormLabel>
              <div className="selectpair_Div openOrder_All">
                <SelectPair
                  selectedVal={pairType}
                  name="open_pair"
                  handleChange={handleChangeSelect}
                  pairList={pairList}
                  placeholder="All"
                />
              </div>
            </Col>
          </Row>
          <div className="tableOuter_Div deposit_Table">
            <PerfectScrollbar
              onScrollY={(container) =>
                console.log(`scrolled to: ${container.scrollTop}.`)
              }
            >
              <Table className={`customTable ${props.className}`}>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Price</th>
                    <th>Type</th>
                    <th>Side</th>
                    <th>Excuted Price</th>
                    <th>Filled</th>
                    <th>Amount</th>
                    <th>Total</th>
                    <th>Status</th>
                  </tr>
                </thead>
                {/* NO RECORD FOUND */}
                <tbody>
                  {openorder && openorder?.data.length > 0 ? (
                    openorder?.data.map((item) => {
                      let totalAmount =
                        smallestunitFormat(item?.price) *
                        smallestunitFormat(item?.amount);
                      return (
                        <tr>
                          <td>
                          {moment(item?.created_at).format("MM/DD/YYYY")}
                          </td>
                          <td>${smallestunitFormat(item?.price)}</td>
                          <td>{item?.type == 1 ? "Market" : "Limit"}</td>
                          <td>{item?.side == 0 ? "Buy" : "Sell"}</td>
                          <td>${smallestunitFormat(item?.excuted_price, 8)}</td>
                          <td>${smallestunitFormat(item?.filled_amount, 8)}</td>
                          <td>${smallestunitFormat(item?.amount, 8)}</td>
                          <td>${totalAmount.toFixed(2)}</td>
                          <td>
                            {item?.status == 1
                              ? "Open"
                              : item?.status == 2
                              ? "Cancelled"
                              : item?.status == 1 &&
                                smallestunitFormat(item?.filled_amount) > 0
                              ? "Partial Open"
                              : item?.status == 2 &&
                                smallestunitFormat(item?.filled_amount) > 0
                              ? "Partial cancelled"
                              : item?.status == 3
                              ? "Completed"
                              : "-"}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="10"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
              {openorder && openorder?.data.length > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e, "open")}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(openorder?.total / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )}
            </PerfectScrollbar>
          </div>
          {/* end open Order */}
        </>
      )}

      {/* Order history start */}

      {exportData && exportData.length > 0 ? (
        <ImportCsv
          emptyData={emptyData}
          stateCsvData={exportData}
          file_name={"order-history-file"}
        />
      ) : (
        ""
      )}
      {props.orderHistoryTab && !!ordersHistory && (
        <>
          <Row className="topFilter_Row m-0">
            <Col className="fromTo_date">
              {/* <DatePickerCustom
                  name="orderDate"
                   handleChange={handleChange}
                  className="internalInput "
                  label="Date"
                  placeholderText="From-To"
                /> */}
              <Form.Group className={`customInput internalInput`}>
                <Form.Label>{`Date`}</Form.Label>
                <DatePicker
                  placeholderText="MM/DD/YYYY - MM/DD/YYYY"
                  className={`form-control internalInput`}
                  selectsRange={true}
                  startDate={startOrderDate}
                  endDate={endOrderDate}
                  onChange={(update) => {
                    handleChange(update);
                  }}
                  // isClearable={true}
                />
              </Form.Group>
            </Col>
            <Col className="pair_Col">
              <FormLabel>Pair</FormLabel>
              <div clavaluessName="selectpair_Div">
                <SelectPair
                  selectedVal={orderPairType}
                  name="pair"
                  handleChange={handleChangeSelect}
                  pairList={pairList}
                  placeholder="All"
                />
              </div>
            </Col>
            <Col className="pair_Col">
              <FormLabel>Status</FormLabel>
              <div className="selectpair_Div">
                <SelectPair
                  selectedVal={orderStatus}
                  name="status"
                  handleChange={handleChangeSelect}
                  pairList={statusData}
                  placeholder="All"
                />
              </div>
            </Col>
            <Col className="filterOptions">
              <FormLabel>Side</FormLabel>
              <div className="filterOption_div">
                <SelectPair
                  selectedVal={orderSide}
                  name="side"
                  pairList={sideData}
                  handleChange={handleChangeSelect}
                  placeholder="All"
                />
                <ButtonPrimary
                  onClick={resetFilterFields}
                  buttontext="Reset"
                  className="internalComn_btn my-0 mr-3"
                />
                <ButtonPrimary
                  onClick={handleClick}
                  buttontext="Search"
                  className="internalComn_btn cancel_btn my-0"
                />
              </div>
            </Col>
          </Row>
          <Row className="topFilter_Row m-0 pt-0">
            <div className="filterOption_div">
              <CustomCheckbox
                onClick={handleCheckBox}
                label="Hide All Cancelled"
                className="internalCheckbox"
                value="3"
              />
              <button
                className="exportBtn"
                onClick={() => {
                  setModalShow(true);
                  setStartDateNew(null);
                  setEndDateNew(null);
                }}
              >
                {" "}
                <img src={ExportIcon} />
                Export Order History
              </button>

              {/* {/ EXPORT TRADE HISTORY  /} */}

              <CommonModal
                show={modalShow}
                onHide={() => setModalShow(false)}
                header="Export Order History"
              >
                <div className="exportHistory">
                  <Form onSubmit={exportSubmit}>
                    <p className="titleText">Select Time Period</p>
                    <Row className="modalRow">
                      <Col className="modalCol" xs={6} sm={4}>
                        <div class="formDiv">
                          <input
                            type="radio"
                            value="1"
                            onClick={exportHistory}
                            name="exportVal"
                            id="flexRadioDefault1"
                            required
                          />
                          <label for="flexRadioDefault1"> Last 24 Hours</label>
                        </div>
                      </Col>
                      <Col className="modalCol" xs={6} sm={4}>
                        <div class="formDiv">
                          <input
                            type="radio"
                            value="2"
                            onClick={exportHistory}
                            name="exportVal"
                            id="flexRadioDefault1"
                            required
                          />
                          <label for="flexRadioDefault1">Yesterday </label>
                        </div>
                      </Col>
                      <Col className="modalCol" xs={6} sm={4}>
                        <div class="formDiv">
                          <input
                            type="radio"
                            value="3"
                            onClick={exportHistory}
                            name="exportVal"
                            id="flexRadioDefault1"
                            required
                          />
                          <label for="flexRadioDefault1"> Past Month </label>
                        </div>
                      </Col>
                      <Col className="modalCol" xs={6} sm={4}>
                        <div class="formDiv">
                          <input
                            type="radio"
                            value="4"
                            onClick={exportHistory}
                            name="exportVal"
                            id="flexRadioDefault1"
                            required
                          />
                          <label for="flexRadioDefault1"> Past 3 Months</label>
                        </div>
                      </Col>
                      <Col className="modalCol" xs={12} sm={6}>
                        <div class="formDiv">
                          <input
                            type="radio"
                            value="5"
                            onClick={exportHistory}
                            name="exportVal"
                            id="flexRadioDefault1"
                            required
                          />
                          <label for="flexRadioDefault1">
                            {" "}
                            Within 6 Months-Custom{" "}
                          </label>
                        </div>
                      </Col>
                      <Col className="modalCol" xs={12} sm={6}>
                        <div class="formDiv">
                          <input
                            type="radio"
                            value={ordersHistory?.start_date}
                            onClick={exportHistory}
                            name="exportVal"
                            id="flexRadioDefault1"
                            required
                          />
                          <label for="flexRadioDefault1">
                            Beyond 6 Months-Custom{" "}
                          </label>
                        </div>
                      </Col>
                    </Row>
                    <Row className="modalRow bottomRadioSec">
                      <Col xs={12} className="datepickerCol">
                        <DatePicker
                          placeholderText="MM/DD/YYYY - MM/DD/YYYY"
                          disabled={enableDatepicker}
                          required={true}
                          selectsRange={true}
                          startDate={startDateNew}
                          endDate={endDateNew}
                          onChange={(update) => {
                            setCustomDateRanage(update);
                          }}
                        />
                        {/* <div className="calanderDiv">
                            <img src={CalanderIcon} />
                          </div> */}
                      </Col>
                      <Col xs={12} className="InfoTextCol">
                        <div className="infoTextDiv">
                          <p className="infotext">
                            Up to 10,000 data can be generated each time
                          </p>
                        </div>
                      </Col>
                      <Col xs={12} sm={6} className="btnsCol">
                        <ButtonPrimary
                          onClick={() => setModalShow(false)}
                          buttontext="Cancel"
                          className="internalComn_btn mb-0 authenticationBtn"
                        />
                      </Col>
                      <Col xs={12} sm={6} className="btnsCol">
                        <button
                          //  disabled={btnDisable}
                          className="exportBtn"
                        >
                          Export
                        </button>
                      </Col>
                    </Row>
                  </Form>
                </div>
              </CommonModal>
            </div>
          </Row>
          {/* {/ ENDS /} */}
          {/* </div> */}
          {/* </Col> */}
          {/* </Row> */}

          <div className="tableOuter_Div deposit_Table">
            <PerfectScrollbar
            // onScrollY={(container) =>
            //   console.log(`scrolled to: ${container.scrollTop}.`)
            // }
            >
              <Table className={`customTable ${props.className}`}>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Price</th>
                    <th>Type</th>
                    <th>Side</th>
                    <th>Excuted Price</th>
                    <th>Filled</th>
                    <th>Amount</th>
                    <th>Total</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {ordersHistory && ordersHistory?.data.length > 0 ? (
                    ordersHistory.data.map((item) => {
                      let totalAmount =
                        smallestunitFormat(item?.price) *
                        smallestunitFormat(item?.amount);
                      return (
                        <tr>
                          <td>
                            {moment(item?.created_at).format("MM/DD/YYYY")}
                          </td>
                          <td>${smallestunitFormat(item?.price)}</td>
                          <td>{item?.type == 1 ? "Market" : "Limit"}</td>
                          <td>{item?.side == 0 ? "Buy" : "Sell"}</td>
                          <td>${smallestunitFormat(item?.excuted_price)}</td>
                          <td>${smallestunitFormat(item?.filled_amount)}</td>
                          <td>${smallestunitFormat(item?.amount)}</td>
                          <td>${totalAmount.toFixed(2)}</td>
                          <td>
                            {item?.status == 1
                              ? "Open"
                              : item?.status == 2
                              ? "Cancelled"
                              : item?.status == 1 &&
                                smallestunitFormat(item?.filled_amount) > 0
                              ? "Partial Open"
                              : item?.status == 2 &&
                                smallestunitFormat(item?.filled_amount) > 0
                              ? "Partial cancelled"
                              : item?.status == 3
                              ? "Completed"
                              : "-"}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="10"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
              {props.orderHistoryTab &&
                ordersHistory &&
                ordersHistory?.data.length > 0 && (
                  <ReactPaginate
                    className="paginationStyle"
                    breakLabel="..."
                    nextLabel=">"
                    onPageChange={(e) => handlePageClick(e, "order")}
                    pageRangeDisplayed={5}
                    // pageCount={100}
                    pageCount={Math.ceil(ordersHistory?.total / 5)}
                    previousLabel="<"
                    renderOnZeroPageCount={null}
                  />
                )}
            </PerfectScrollbar>
          </div>
        </>
      )}
      {/* order history end */}

      {/* Trade history start */}

      {!!tradeHistory && (
        <>
          <Row className="topFilter_Row m-0">
            <Col lg={3}>
              <FormLabel>Filter</FormLabel>
              <div className="selectpair_Div openOrder_All">
                <SelectPair
                  selectedVal={tradePair}
                  name="trade_pair"
                  handleChange={handleChangeSelect}
                  pairList={pairList}
                  placeholder="All"
                />
              </div>
            </Col>
          </Row>
          <div className="tableOuter_Div deposit_Table">
            <PerfectScrollbar
              onScrollY={(container) =>
                console.log(`scrolled to: ${container.scrollTop}.`)
              }
            >
              <Table className={`customTable`}>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Price</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {tradeHistory && tradeHistory?.data.length > 0 ? (
                    tradeHistory?.data.map((item) => {
                      return (
                        <tr>
                          <td>
                            {moment(item[2]).format("DD-MMM-YYYY HH:mm:ss")}
                            {/* {moment(item?.created_at).format("MM/DD/YYYY")} */}
                          </td>
                          <td>${smallestunitFormat(item[0])}</td>
                          <td>${smallestunitFormat(item[1])}</td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="10"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
              {tradeHistory && tradeHistory?.total_record > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e, "trade")}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(tradeHistory?.total_record / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )}
            </PerfectScrollbar>
          </div>
        </>
      )}
      {/* trade history end */}
    </>
  );
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    orderHistoryCsv: (data) => dispatch(orderHistoryCsv(data)),
    // getReferralHistory: (data) => dispatch(getReferralHistory(data)),
    // getCustomPlans: () => dispatch(getCustomPlans()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(OrderTable);
