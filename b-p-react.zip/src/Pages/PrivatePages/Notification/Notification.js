import React, { useEffect } from "react";
import MainCard from "../../../components/common/MainCard/MainCard";
import { Card, Accordion, Form } from "react-bootstrap";
import filter from "../../../theme/images/filter.svg";
import check from "../../../theme/images/checkWhite.svg";
import check2 from "../../../theme/images/check.png";
// import Button from "@restart/ui/esm/Button";
import NotificationAccordion from "./NotificationAccordion";
import CustomCheckbox from "../../../components/common/CustomCheckbox/CustomCheckbox";
import "./Notification.scss";
import { getNotification } from "../../../redux/actions/SecurityActions"
import { connect } from "react-redux";
import ReactPaginate from "react-paginate";
import moment from "moment";

const Notification = (props) => {
const {user_notification} = props;
  useEffect(() => {
   props.getNotification({offset:0})
  }, []);

  const handlePageClick = (event, val) => {
    const newPage = event.selected;
    props.getNotification({offset:newPage})
  };

  return (
    <>
      <div className="notificationCommon_Style">
        <MainCard>
          <div className="cardTitle_Padding cardtitle">
            <Card.Title className="Title">
              Notification
              <div className="checkBocCard">
                <div className="Buttonsec">
                  <Form.Group
                    className="mb-3 mt-3"
                    controlId="formBasicCheckbox"
                  >
                    {/* <CustomCheckbox
                      label="Hide read notifications"
                      className="internalCheckbox"
                    /> */}
                  </Form.Group>
                  {/* <Button className="filter">
                    <img src={filter} />
                    Filter
                  </Button>
                  <Button className="check">
                    <img src={check} className="lighticon" />
                    <img src={check2} className="darkicon" />
                  </Button>
                  <Button className="Clear">Clear all</Button>{" "} */}
                </div>
              </div>
            </Card.Title>
          </div>
          <div className="notificationWrap_style">
            <Accordion>
            {user_notification?.data && user_notification?.data.length > 0 && user_notification?.data.map((item,index)=>{

              return(
                <NotificationAccordion 
                loginData={`${item?.notification} ${moment(item?.last_login).format("YYYY-MM-DD | h:mm:ss")}`}
                notification={item}
                
                eventKey={index} />

              )
            })}
            </Accordion>
            {user_notification?.records && user_notification?.records > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e)}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(user_notification?.records / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )}
          </div>
        </MainCard>
      </div>
    </>
  );
};

const mapStateToProps = state => {
  return {
    
    user_notification: state?.security?.user_notification,

  };
};

const mapDispatchToProps = dispatch => {
  return {
    getNotification: (data) => dispatch(getNotification(data)),
    // updateUserProfile: (data) => dispatch(updateUserProfile(data))

  };
};
export default (connect(
  mapStateToProps,
  mapDispatchToProps
)(Notification));