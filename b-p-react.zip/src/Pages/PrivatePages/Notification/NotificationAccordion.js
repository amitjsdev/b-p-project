import React from "react";
import { Col, Accordion, Form } from "react-bootstrap";
import CustomCheckbox from "../../../components/common/CustomCheckbox/CustomCheckbox";
import moment from "moment";

function NotificationAccordion(props) {
  const { notification, loginData } = props;
  return (
    <>
      <Accordion.Item eventKey={props.eventKey}>
        <Col lg={12} className="customBit">
          <p>{notification?.title}</p>
          <span className="spanSEc">
            {notification?.type == 0
              ? moment(notification?.last_login).format("YYYY-MM-DD | h:mm:ss")
              : moment(notification?.created_at).format("YYYY-MM-DD | h:mm:ss")}
          </span>
        </Col>

        <Accordion.Header>
          {notification?.type == 0
            ? loginData.length > 40
              ? `${loginData.substring(0, 40)}...`
              : loginData
            : notification?.notification.length > 40
            ? `${notification?.notification.substring(0, 40)}...`
            : notification?.notification}
        </Accordion.Header>
        <Accordion.Body>
          {notification?.type == 0 ? loginData : notification?.notification}
        </Accordion.Body>
      </Accordion.Item>
    </>
  );
}

export default NotificationAccordion;
