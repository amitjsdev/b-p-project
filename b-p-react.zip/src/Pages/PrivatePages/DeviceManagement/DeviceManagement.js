import React from "react";
import { Row, Col } from "react-bootstrap";
import DeviceIcon from "../../../theme/images/device_icon.svg";
import Chrome from "../../../theme/images/chrome.svg";
import Sfari from "../../../theme/images/safari.svg";
import OtherIcon from "../../../theme/images/microsoft-edge.svg";

import MainCard from "../../../components/common/MainCard/MainCard";
import DotIcon from "../../../theme/images/dot_icon.svg";
import DotIconLite from "../../../theme/images/dot_icon_lite.svg";
import DeviceCard from "../../../components/common/DeviceCard/DeviceCard";
import "../Setting/Setting.scss";
import "./DeviceManagement.scss";
import { getUserTrustedDevice } from "../../../redux/actions/SecurityActions"
import { connect } from 'react-redux';
// import { browserName, browserVersion,deviceType,osName,deviceDetect } from "react-device-detect";

import { browserName, browserVersion, deviceType, osName, deviceDetect } from "react-device-detect";


function DeviceManagement(props) {
  React.useEffect(() => {
    getUserTrustedDevice();
  }, [])

  const [trustedDevice, setTrustedDevice] = React.useState([]);
  const getUserTrustedDevice = () => {
    props.getUserTrustedDevice().then((res) => {
      setTrustedDevice(res.data.data.agentInfo)
    }).catch((error) => {
    })
  }
  return (
    <>
      {/* <Row className="settingRow_style">
        <Col lg={10} md={10} className="deviceCol_style"> */}
      <MainCard title="Device Management" className="mainCard_padding deviceCol_style">
        <div className="deviceWrap_style">
          <Row className="m-0 deviceRow_style">

            {trustedDevice && trustedDevice.length > 0 && trustedDevice.map((item) => {
              return (
                <>
                  <DeviceCard
                    icon={DeviceIcon}
                    device={!!item.device ? item.device : 'Other'}
                    ip={item.ipAddress}
                    location=""
                    alt="kyc icon"
                    browser={!!item.user_browser ? item.user_browser : 'Other'}
                    status={item.login_status == 1 ? "Active Now" : "In-Active"}
                    activeStatus={item.login_status}
                    loginDate={item.updated_at}
                    iconsecond={DotIcon}
                    iconsecondLite={DotIconLite}
                  />
                </>
              )
            })
            }
          </Row>
        </div>
      </MainCard>
      {/* </Col>
      </Row> */}
    </>
  );
}


const mapStateToProps = state => {
  return {
    loading: state.loading.loading
  };
};

const mapDispatchToProps = dispatch => {
  return {
    // getUserInfo:()=>dispatch(getUserInfo()),
    getUserTrustedDevice: () => dispatch(getUserTrustedDevice()),



  };
};
export default (connect(
  mapStateToProps,
  mapDispatchToProps
)(DeviceManagement));
