import React, { useEffect, useState } from "react";
import { Row, Col, Card, Form, FormControl } from "react-bootstrap";
import CoinCard from "../../../components/common/CoinCard/CoinCard";
import MainCard from "../../../components/common/MainCard/MainCard";
import GraphIcon from "../../../theme/images/graph.svg";
import MenuIcon from "../../../theme/images/menu_icon.svg";
import MenuGrid from "../../../theme/images/grid_menu.svg";
import CustomTable from "../../../components/common/CustomTable/CustomTable";
// import Carousel from "react-multi-carousel";
// import "react-multi-carousel/lib/styles.css";
import Marquee from "react-fast-marquee";
// import "./MarqueeContainer.scss";
import "./Wallet.scss";
import CustomSearch from "../../../components/common/CustomSearch/CustomSearch";
import { Doughnut, Chart, Line } from "react-chartjs-2";
import {
  getUserBalance,
  getWalletHistory,
  getActiveCoins,
} from "../../../redux/actions/WalletActions";
import { connect } from "react-redux";
//stock chart
import ReactHighcharts from "react-highcharts/ReactHighstock.src";
import priceData from "../../../assets/btcdata.json";
import moment from "moment";
import socket from "../../../socket/index";
import { getToken } from "../../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY } from "../../../constant";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1280 },
    items: 4,
  },
  tablet: {
    breakpoint: { max: 1280, min: 464 },
    items: 3,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

function Wallet(props) {
  const { theme } = props;
  var currentDate = new Date();
  var settingsData = {
    dots: false,
    pauseOnHover: true,
    pauseOnFocus: true,
    autoplaySpeed: 0,
    speed: 50,
    slidesToScroll: 1,
    autoplay: true,
    arrows: false,
    centerMode: true,
    cssEase: "linear",
    swipeToSlide: "true",
    touchMove: "true",
    responsive: [
      {
        breakpoint: 1366,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          // infinite: announcement_count > 1,
        },
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 900,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          //   infinite: announcement_count > 1,
        },
      },
      {
        breakpoint: 700,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: false,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: false,
        },
      },
    ],
  };
  const [totalValue, setTotalValue] = useState(0.0);
  const [pieData, setPieData] = useState([]);
  const [pieLegend, setPieLegend] = useState([]);
  const [pieLabels, setPieLabels] = useState([]);
  const [bgColors, setBgColor] = useState([]);
  const [activeCoin, setActiveCoin] = useState([]);
  const [isActive, setActive] = useState(false);
  const [graphData, setGraphData] = useState([]);
  const [graphBalance, setGraphBalance] = useState(0);
  const [socketData, setSocketData] = useState([]);
  const [socketFilterData, setSocketFilterData] = useState([]);

  const handleToggle = () => {
    setActive(!isActive);
  };
  // const lineChartCurrency = props.user_info_status.currencyPreferences;
  const lineChartCurrency = "USD";

  useEffect(() => {
    // socket.connect();
    getActiveCoins();
    props.getUserBalance(lineChartCurrency);
    connectSocket();
    window.scrollTo({ top: 0, behavior: "smooth" });

  }, []);
  useEffect(() => {
    if (socketFilterData && socketFilterData.length > 0) {
      pairUserBalance();
    }
  }, [socketFilterData, props.theme]);

  useEffect(() => {
    if (
      graphData &&
      graphData.length == 0 &&
      socketFilterData &&
      socketFilterData.length > 0 &&
      totalValue > 0
    ) {
      getWalletHistory();
    }
  }, [totalValue, props.theme]);

  useEffect(() => {
    if (bgColors && bgColors.length >= 0) {
      getPieChart()
    }
  }, [bgColors, props.theme]);

  
  

  const connectSocket = () => {
    socket.emit("currentPair", {
      currency: !!lineChartCurrency ? lineChartCurrency : "USD",
      pair: "usdt_eth",
      member: getToken(AUTH_TOKEN_KEY),
      accessToken: getToken(AUTH_TOKEN_KEY),
    });
  };

  socket.on("walletBalances", (data) => {
    if (!!data && data != "undefined" && data.length > 0) {
      var valueArr =
        !!data &&
        data.length > 0 &&
        data.map(function (item) {
          return item.coin_symbol;
        });
      //find duplicate value

      var isDuplicate = valueArr.filter(function (item, idx) {
        return valueArr.indexOf(item) != idx;
      });

      //find duplicate value data

      let repeatedData = [];
      isDuplicate &&
        isDuplicate.length > 0 &&
        isDuplicate.forEach((val) => {
          repeatedData.push(data.filter((item) => item.coin_symbol == val));
        });

      let globalData = [];

      // sum balances of duplicates values
      repeatedData &&
        repeatedData.length > 0 &&
        repeatedData.forEach((item, index) => {
          let coin_Currencybalance = item.reduce(function (index, item) {
            return index + parseFloat(item.coin_Currencybalance);
          }, 0);

          let coin_balance = item.reduce(function (index, item) {
            return index + parseFloat(item.coin_balance);
          }, 0);

          let locked_balance = item.reduce(function (index, item) {
            return index + parseFloat(item.locked_balance);
          }, 0);

          let data = { ...item[index] };
          data["coin_Currencybalance"] = coin_Currencybalance;
          data["coin_balance"] = coin_balance;
          data["locked_balance"] = locked_balance;
          globalData.push(data);
        });

      //find unique values
      let uniqueChars = valueArr.filter((c, index) => {
        return valueArr.indexOf(c) === index;
      });

      let finalData = [];

      //find unique values data
      uniqueChars &&
        uniqueChars.length > 0 &&
        uniqueChars.forEach((val) => {
          let resFilter = data.filter((item) => item.coin_symbol === val);
          finalData.push(resFilter[0]);
        });

      //remove data of repeated values from uniqueChars

      globalData &&
        globalData.length > 0 &&
        globalData.map((e) => {
          const coinDataIndex = finalData.findIndex(
            (item) => item.coin_symbol == e.coin_symbol
          );
          if (coinDataIndex !== -1) {
            finalData.splice(coinDataIndex, 1);
          }
        });

      //combine unique values and duplicated values
      let combineData = [...finalData, ...globalData];

      function moveArrayItemToNewIndex(arr, old_index, new_index) {
        if (new_index >= arr.length) {
            var k = new_index - arr.length + 1;
            while (k--) {
                arr.push(undefined);
            }
        }
        arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
        return arr; 
    };

   let ethIndex =  combineData.findIndex((item)=> item.coin_symbol == 'eth')
   let btcINdex =  combineData.findIndex((item)=> item.coin_symbol == 'btc')
     let moveData =  moveArrayItemToNewIndex(combineData,0,btcINdex)
     let moveDataEth =  moveArrayItemToNewIndex(moveData,1,ethIndex)

      // combineData.sort(function (a, b) {
      //   var textA = a.coin_name.toUpperCase();
      //   var textB = b.coin_name.toUpperCase();
      //   return textA < textB ? -1 : textA > textB ? 1 : 0;
      // });
      setSocketFilterData(moveDataEth);
      setSocketData(moveDataEth);

    }
  });

  const getActiveCoins = () => {
    props
      .getActiveCoins()
      .then((res) => {
        setActiveCoin(res.data.coins);
      })
      .catch((error) => {});
  };

  const getWalletHistory = () => {
    // if (!!lineChartCurrency) {

    props.getWalletHistory(lineChartCurrency).then((res) => {
      let jsonData = [];
      let result = res?.data?.data;
      let historyBalance = [];
      // setGraphData

      var today = new Date();
      var date =
        today.getFullYear() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getDate();
      let currentDate = moment(today).format("YYYY-MM-DD") + "T00:00:00.000Z";

      let itemCount = 0;
      result &&
        result.length > 0 &&
        result.forEach((item) => {
          itemCount++;
          let resData = moment(item.date).format("YYYY-M-D");
          if (new Date(resData).getTime() != new Date(date).getTime()) {
            var datum = new Date(item.date).getTime();
            jsonData.push([datum, item.amount]);
            historyBalance.push(item.amount);
          }
        });

      // let totalBalance = historyBalance.reduce(function (index, item) {
      //   return index + parseFloat(item);
      // }, 0);
      if (result.length == itemCount) {
        var datum = new Date(currentDate).getTime();
        jsonData.push([datum, parseFloat(totalValue)]);
      }
      setGraphData(jsonData);
      setGraphBalance(parseFloat(totalValue));
    });
    //}
  };

  const pairUserBalance = () => {
    if (!!lineChartCurrency) {
      // props
      //   .getUserBalance(lineChartCurrency)
      //   .then((res) => {
      let resData = [];
      socketFilterData.forEach((item, i) => {
        let balance =
          item?.marketCoinData?.current_price["usd"] * (item?.coin_balance / 100000000)
          
        resData.push({
          full_name: item.coin_name.toUpperCase(),
          price: balance,
        });
      });
      if (resData && resData.length > 0) {
        // resData.sort((a,b) => b[1]-a[1])
        resData.sort(function (a, b) {
          return b.price - a.price;
        });
        let totalPrice = resData.reduce(function (accumulator, item) {
          return accumulator + item.price;
        }, 0);
        setTotalValue(totalPrice.toFixed(2));

        let chartPercent = [];
        let ChartVal = [];
        let chartLables = [];
        let pieColors = [
          "#ffca00",
          "#C52B2B",
          "#329BFF",
          "#FF5700",
          "#555470",
          "#00BE00",
        ];
        let bgColors = [];
        let fiveCoinPrice = [];
        resData &&
          resData.length > 0 &&
          resData.forEach((item, i) => {
            if (chartPercent.length < 5) {
              fiveCoinPrice.push(item.price);
              let priceVal = (item.price / totalPrice) * 100;
              chartPercent.push(priceVal.toFixed(4));
              ChartVal.push({
                name: item.full_name,
                percentVal: priceVal.toFixed(4),
              });
              chartLables.push(item.full_name);
              bgColors.push(pieColors[i]);
            }
          });

        //for other coins start
        if (resData && resData.length > 5) {
          let otherTotalPrice = fiveCoinPrice.reduce(function (index, item) {
            return index + parseFloat(item);
          }, 0);

          let otherPrice;
          if (totalPrice > otherTotalPrice) {
            otherPrice = totalPrice - otherTotalPrice;
          } else {
            otherPrice = otherTotalPrice - totalPrice;
          }
          let otherPriceVal = (otherPrice / totalPrice) * 100;
          chartPercent.push(otherPriceVal.toFixed(4));
          ChartVal.push({
            name: "Others",
            percentVal: otherPriceVal.toFixed(4),
          });
          chartLables.push("others");
          bgColors.push(pieColors[5]);
        }
        //for other coins end
        setPieData(chartPercent);
        setPieLegend(ChartVal);
        setPieLabels(chartLables);
        setBgColor(bgColors);
      }
      // })
      // .catch((error) => {});
    }
  };

  //pie chart start

  const chartData = pieData;
  const showData = `${totalValue} ${lineChartCurrency}`;
  const data1 = {
    labels: pieLabels,
    datasets: [
      {
        data: chartData,
        backgroundColor: bgColors,
        borderWidth: 0,
      },
    ],
    text: showData,
  };
const getPieChart =  () => {
  var originalDoughnutDraw = Chart.controllers.doughnut.prototype.draw;
  Chart.helpers.extend(Chart.controllers.doughnut.prototype, {
    draw: function () {
      originalDoughnutDraw.apply(this, arguments);
      let fillColor = props.theme;
      var chart = this.chart;
      var width = chart.chart.width,
        height = chart.chart.height,
        ctx = chart.chart.ctx;
      var fontSize = 2;
      ctx.font = fontSize + "em sans-serif";
      ctx.fillStyle = fillColor == "dark" ? "#131841" : "#fff";
      ctx.textBaseline = "middle";
      var text = chart.config.data.text,
        textX = Math.round((width - ctx.measureText(text).width) / 2),
        textY = height / 2;
      ctx.fillText(text, textX, textY);
    },
  });
}


  const options1 = {
    responsive: true,
    legend: {
      display: false,
      position: "bottom",
      border: "none",
      labels: {
        fontSize: 18,
        fontColor: "#6D7278",
        fontFamily: "kanit light",
      },
    },
    cutoutPercentage: 90,
  };
  //pie chart end
  //line stock start
  const options = {
    style: "currency",
    currency: lineChartCurrency ? lineChartCurrency : "USD",
  };
  const numberFormat = new Intl.NumberFormat("en-US", options);

  const configPrice = {
    yAxis: [
      {
        lineWidth: 0,
        gridLineColor: "#e8e8e8",
        offset: 15,
        opposite: false,

        labels: {
          formatter: function () {
            return numberFormat.format(this.value);
          },
          x: 0,
          style: {
            color: "#5f658a",
            position: "absolute",
          },
          align: "right",
        },
      },
    ],
    tooltip: {
      shared: true,
      formatter: function () {
        return `<p style="color:#fff">Balance: ${
          numberFormat.format(this.y, 0) +
          '</b><br/><span style="color:#fff">' +
          moment(this.x).format("MMM Do YYYY")
        }</span></p>`;
      },
      backgroundColor: "#3486ff",
      color: "#fff",
      fillText: "#fff",
    },
    plotOptions: {
      series: {
        showInNavigator: true,
        // gapSize: 15,
        color: "#00be00",
      },
    },
    rangeSelector: {
      selected: 1,
      // enabled: false
    },
    title: {
      text: `<span class="${
        theme == "dark---" ? "darkTheme" : ""
      } graphTile">Wallet Balance</span> <br><br>
    <span class="${
      theme == "dark" ? "darkTheme" : ""
    } balanceAmount">${graphBalance} ${lineChartCurrency}</span>`,
      color: theme == "dark" ? "#fff" : "#050823",
      align: "left",
    },

    credits: {
      enabled: false,
    },

    legend: {
      enabled: true,
    },
    chart: {
      backgroundColor: theme == "dark" ? "#fff" : "#050823",
      height: 470,
      inputPosition: {
        x: +13,
      },
    },
    // style: {
    //   "color": "#fff"

    // },
    xAxis: {
      offset: 15,
      type: "datetime",
      style: {
        color: "#5f658a",
      },
    },
    rangeSelector: {
      // inputPosition: {
      //   x: 0
      // },
      floating: true,
      x: 450,
      y: -50,
      buttons: [
        {
          type: "month",
          count: 1,
          text: "1m",
        },
        {
          type: "month",
          count: 3,
          text: "3m",
        },
        {
          type: "month",
          count: 6,
          text: "6m",
        },
        {
          type: "year",
          count: 1,
          text: "1yr",
        },
        {
          type: "all",
          text: "All",
        },
      ],
      selected: 4,
      // enabled : false
    },
    navigator: {
      enabled: false,
    },
    series: [
      {
        pointStart: graphData && graphData.length > 0 && graphData[0][0],
        name: "Price",
        data: graphData,
      },
    ],
  };
  //line stock end

  //socket
  let socketCurrency = !!lineChartCurrency
    ? lineChartCurrency.toLowerCase()
    : "usd";
  const handleSearch = (e) => {
    let val = e.target.value;

    if (val != "") {
      let newData = socketFilterData.filter((item) =>
        item.coin_name.toLowerCase().includes(val)
      );
      setSocketData(newData);
    } else {
      setSocketData(socketFilterData);
    }
  };

  return (
    <>
      <Row className="walletRow_Style">
        {/* {!!props.theme == 'dark' ? (
          <Col xs={12} md={12} lg={12} xl={7} className="chartCol">
            <div className="walletChart_Style">
              <ReactHighcharts config={configPrice}></ReactHighcharts>
            </div>
          </Col>
        ) : ( */}
          <Col xs={12} md={12} lg={12} xl={7} className="chartCol">
            <div className="walletChart_Style">
              <ReactHighcharts config={configPrice}></ReactHighcharts>
            </div>
          </Col>
        
        {!!lineChartCurrency && (
          <Col xs={12} md={12} lg={12} xl={5} className="fundAlloction_Col">
            <MainCard title="Funds Allocation">
              <Row className="fundsAllocation_Row m-0">
                <Col
                  xs={12}
                  sm={8}
                  md={8}
                  className="fundsAllocation_graph p-0"
                >
                  <Doughnut
                    data={data1}
                    options={options1}
                    height={560}
                    width={560}
                    styleMode={true}
                  />
                </Col>
                <Col xs={12} sm={4} md={4} className="fundsAllocation_List">
                  <ul>
                    {pieLegend &&
                      pieLegend.length > 0 &&
                      pieLegend.map((item) => {
                        return (
                          <li>
                            <h2>
                              {item.percentVal == "NaN" || item.percentVal <= 0 ? 0.00 : item.percentVal}
                              %
                            </h2>
                            <p>{item.name}</p>
                          </li>
                        );
                      })}
                  </ul>
                </Col>
              </Row>
            </MainCard>
          </Col>
        )}
      </Row>
      <Row className="m-0">
        <Col xs={12} className="p-0">
          <MainCard className="walletCoin_wrap">
            <Card.Title
              className={`maintitle ${isActive ? "" : "maintitle_bg"}`}
            >
              Active Assets
              <Form className="d-flex align-items-center">
                <CustomSearch
                  handleSearch={handleSearch}
                  className={isActive ? "" : "searchInput_bg"}
                  placeholder="Search Asset"
                />
                <a className="menuIcon" onClick={handleToggle}>
                  <img src={MenuIcon} className={isActive ? "show" : "hide"} />
                  <img src={MenuGrid} className={isActive ? "hide" : "show"} />
                </a>
              </Form>
            </Card.Title>
            <Row className={`walletCoin_row ${isActive ? "show" : "hide"}`}>
              {/* <Carousel
                responsive={responsive}
                swipeable={true}
                draggable={true}
                showDots={false}
                arrows={false}
                infinite={true}
                autoPlay={true}
                customTransition="all 10s linear"
              > */}
              <Marquee {...settingsData}>
                {socketData &&
                  socketData.length > 0 &&
                  socketData.map((item) => {
                    return (
                      <CoinCard
                        icon={
                          item?.marketCoinData?.images
                            ? item?.marketCoinData?.images["large"]
                            : ""
                        }
                        name={item?.coin_name.toUpperCase()}
                        coin={item?.coin_symbol}
                        price={
                          item?.marketCoinData?.current_price
                            ? numberFormat.format(
                                item?.marketCoinData?.current_price[
                                  socketCurrency
                                ],
                                0
                              )
                            : ""
                        }
                        symbol={item?.coin_symbol}
                        graph={GraphIcon}
                        date={moment(currentDate).format("h:mm, DD MMMM YYYY")}
                        lastchange={`${item?.marketCoinData?.price_change_24h.toFixed(
                          4
                        )} ${item?.coin_symbol.toUpperCase()}`}
                        graphData={item?.marketPrices30d}
                      />
                    );
                  })}
              </Marquee>
              {/* </Carousel> */}
            </Row>
            <div className={`tableOuter_Div ${isActive ? "hide" : "show"}`}>
              <CustomTable
                currency={socketCurrency}
                numberFormat={numberFormat}
                socketData={socketData}
              />
            </div>
          </MainCard>
        </Col>
      </Row>
    </>
  );
}

// export default Wallet;

const mapStateToProps = (state) => {
  return {
    theme: state.persist.theme ? "dark" : "light",
    user_info_status: state.security.userProfile,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    // updateUserKyc: (data) => dispatch(updateUserKyc(data)),
    getActiveCoins: () => dispatch(getActiveCoins()),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),
    getWalletHistory: () => dispatch(getWalletHistory()),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Wallet);
