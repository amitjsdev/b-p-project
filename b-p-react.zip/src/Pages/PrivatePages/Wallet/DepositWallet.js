import React, { useEffect, useState } from "react";
import { Row, Col, Tabs, Tab, Form, Table, Card } from "react-bootstrap";
import Select from "react-select";
import MainCard from "../../../components/common/MainCard/MainCard";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CopyIcon from "../../../theme/images/copy_icon.svg";
import InputQrIcon from "../../../theme/images/input_qr.svg";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "./Wallet.scss";
import TransactionTable from "../../../components/common/CustomTable/TransactionTable";
import {
  getUserBalance,
  getWalletHistory,
  getActiveCoins,
  getCoinDepositAddress,
  getUserBalanceParticularCoin,
  getDepositTxnHistory,
  getCurrencyDetails,
  getWithdrawDepositTxnHistory,
  getCoinNetworkList,
} from "../../../redux/actions/WalletActions";
import priceData from "../../../assets/btcdata.json";
import moment from "moment";
import { connect } from "react-redux";
import ReactHighcharts from "react-highcharts/ReactHighstock.src";
import { useHistory, useParams } from "react-router-dom";
import queryString from "query-string";
import QRCode from "react-qr-code";
import copy from "copy-to-clipboard";

import { smallestunitFormat, bn_operations } from "../../../Helpers/Normailize";
import { ENV_VAR, SMALLESTUNIT, KYC_APPROVED } from "../../../constant";
import * as WAValidator from "wallet-address-validator";
import {
  withdrawRequestValidation,
  withdrawRequest,
  getSingleCoinHistory,
} from "../../../redux/actions/WalletActions";
import {
  send2faEmailVerification,
  token_verification,
  token_verification_google,
} from "../../../redux/actions/SecurityActions";
import { getUserInfo } from "../../../redux/actions/SecurityActions";

import Modal2fa from "../../../components/common/Modal2fa/Modal2fa";


function DepositWallet(props) {
  const {theme} = props;
  let history = useHistory();
  const parsed = queryString.parse(props.location.search);
  const selectTab = parsed?.tab ? parsed?.tab : "Deposit";
  const [selectedCoinDeposit, setSelectedCoinDeposit] = useState(
    parsed.getCoin
  );
  const [selecteTab, setSelecteTab] = useState(selectTab);
  const [coinAddress, setCoinAddress] = useState({});
  const [userSelectedCoinBalance, setSelectedUserCoinBalance] = useState([]);
  const [tokenData, setTokenData] = useState([]);
  const [copyText, setCopyText] = useState("");
  const [copied, setCopied] = useState(false);
  const [graphData, setGraphData] = useState([]);
  const [graphBalance, setGraphBalance] = useState(0);
  const [pageVal, setPageVal] = useState(1);
  const [withdrawHistory, setWithdrawHistory] = useState([]);
  const [withdrawHistoryRecords, setWithdrawHistoryRecords] = useState(0);

  //withdraw
  const [minfeErr, setMinfeErr] = useState(false);
  const [withdrawNewtwork, setWithdrawNewtwork] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState(0);
  const [amount, setAmount] = useState("");

  const [finalAmount, setFinalAmount] = useState(0);
  const [curencyDetails, setCurencyDetails] = useState({});
  const [minWithdraw, setMinWithdraw] = useState(0);
  const [transactionFee, setTransactionFee] = useState(0);
  const [withdrawLimit, setWithdrawLimit] = useState(0);

  const [invalidAddress, setInvalidAddress] = useState(false);

  const [address, setAddress] = useState("");
  const [googleAuth, setGoogleAuth] = useState(false);
  const [securityToken2fa, setSecurityToken2fa] = useState("");

  const [networkName, setNetworkName] = useState("");

  const [networkApi, setNetworkApi] = useState(false);

  const [networkoptions, setNetworkoptions] = useState([]);
  const [userInfo, setUserInfo] = useState(props.user_info_status);

  const [currentToken, setCurrentToken] = useState([]);
  const [currentUrl, setCurrentUrl] = useState("");
  const [defaultTab, setDefaultTab] = useState("all");

  let currentIp = localStorage.getItem("currentIp");

  // check if entered amount  is   less than min withdraw limit
  const checkMinAmountError = (bal) => {
    if (bal < props.minWithdraw / SMALLESTUNIT) {
      setMinfeErr(true);
    } else {
      setMinfeErr(false);
    }
  };

  // calculating final amount after deduction of transaction fee
  const validate = (bal) => {
    if (bal == "." || bal[0] == ".") {
      setAmount("0" + bal);
      setWithdrawAmount("0" + bal);
      bal = "0" + bal;
      checkMinAmountError(bal);
    } else {
      setAmount(bal);
      checkMinAmountError(bal);
    }
    let enteredAmount = bal * SMALLESTUNIT;
    let famt = bn_operations(enteredAmount, transactionFee, "-");

    setFinalAmount(famt / SMALLESTUNIT);

    if (isNaN(famt / SMALLESTUNIT) || famt / SMALLESTUNIT < 0) {
      setFinalAmount("0");
    }
  };
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });

    //connectSocket()
    if (tokenData && tokenData.length == 0) {
      getActiveCoins();
    }
    if (Object.keys(userInfo).length == 0) {
      props.getUserInfo().then((res) => {
        setUserInfo(res.data.data);
      });
    }

    let data = {
      coin: selectedCoinDeposit,
      page: 1,
    };
    if (selectedCoinDeposit !== "" && networkName == "") {
      props
        .getCoinNetworkList(selectedCoinDeposit)
        .then((res) => {
          const networksList = [];
          let resData = res.data.data;
          resData &&
            resData.length > 0 &&
            resData.map((item) => {
              networksList.push({
                value: item.network_name,
                label: item.full_name,
              });
            });
          setNetworkoptions(networksList);
          setNetworkApi(true);
          setNetworkName(resData[0].network_name);
          setWithdrawNewtwork(resData[0].network_name);
        })
        .catch((error) => {});
    }
    if (networkApi) {
      getCoinDepositAddress(selectedCoinDeposit, networkName);
      getDepositTxnHistory(data);
      getCurrencyDetails(selectedCoinDeposit, networkName);
      getWithdrawDepositTxnHistory("all", 1);
      // getCoinNetworkList(selectedCoinDeposit)
      getSingleCoinHistory(selectedCoinDeposit, networkName);
    }
  }, [selectedCoinDeposit, networkName]);

  useEffect (()=>{

    if (networkApi) {
      getSingleCoinHistory(selectedCoinDeposit, networkName);
    }
  },[userSelectedCoinBalance])
  

  // get Graph data
  const getSingleCoinHistory = (coin) => {
    props
      .getSingleCoinHistory(coin, networkName)
      .then((res) => {
        let graphChart = res.data.data;
        let historyBalance = [];
        let graphVal = [];

        var today = new Date();
      var date =
        today.getFullYear() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getDate();
      let currentDate = moment(today).format("YYYY-MM-DD") + "T00:00:00.000Z";
      let itemCount = 0;

        graphChart &&
          graphChart.length > 0 &&
          graphChart.forEach((item) => {
            itemCount++;
          let resData = moment(item.date).format("YYYY-M-D");
          if (new Date(resData).getTime() != new Date(date).getTime()) {
            historyBalance.push(item.amount);
            var datum = new Date(item.date).getTime();
            graphVal.push([datum, item.amount]);
          }
          });
        // let totalBalance = historyBalance.reduce(function (index, item) {
        //   return index + parseFloat(item);
        // }, 0);

        let currentBalance = userSelectedCoinBalance[0]?.balance / SMALLESTUNIT;
         let totalBalance = currentBalance * userSelectedCoinBalance[0]?.currentPrice;
         let finalBalance;
          if(isNaN(totalBalance)){
            finalBalance = '00';
          }else{
            finalBalance = totalBalance
          }
        if (graphChart.length == itemCount) {
          var datum = new Date(currentDate).getTime();
          graphVal.push([datum, parseFloat(finalBalance.toFixed(2))]);
        }



        setGraphBalance(parseFloat(finalBalance.toFixed(2)));
        setGraphData(graphVal);
      })
      .catch((error) => {});
  };

  const getActiveCoins = () => {
    props.getActiveCoins().then((res) => {
      let tokenList = [];
      let data = res.data?.coinList
      const uniqueChars = data.filter((v, i, a) => a.findIndex((t) => t.full_name === v.full_name) === i);
      uniqueChars && uniqueChars.length > 0 && uniqueChars.forEach(item => {
        let historyBalance = [];
        // historyBalance.push(item.amount)
        tokenList.push({
          value: item.coin, label: (
            <div>
              {item?.coin_image ? 
                <img src={item?.coin_image} className="optionIcon" />
            : 
            ''
            }
              {item.full_name}
            </div>
          )
        })

      });
      tokenList.sort(function (a, b) {
        var textA = a.value.toUpperCase();
        var textB = b.value.toUpperCase();
        return textA < textB ? -1 : textA > textB ? 1 : 0;
      });
      setTokenData(tokenList);

    }).catch((error) => {

    })
  }

  const copyToClipboard = () => {
    copy(copyText);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 5000);
    //alert(`You have copied "${copyText}"`);
  };

  // const getCoinNetworkList = (coin) => {

  //   props.getCoinNetworkList(coin).then((res) => {
  //     // setCoinAddress(res.data.data)
  //     // //setAddress(res.data.data.address)
  //   }).catch((error) => {

  //   })
  // }

  const getCoinDepositAddress = (coin, network) => {
    props
      .getCoinDepositAddress(coin, network)
      .then((res) => {

        let coinAddessData = res.data.data
        if(coinAddessData){
          getParticularCoinBalance(selectedCoinDeposit, networkName);
        }
        setCoinAddress(res.data.data);
        //setAddress(res.data.data.address)
        setCopyText(res.data.data.address);

      })
      .catch((error) => {});
  };

  const getParticularCoinBalance = (coin, network) => {
    //   alert(coin)
    props
      .getUserBalanceParticularCoin(coin, network)
      .then((res) => {
        setSelectedUserCoinBalance(res.data.data);
      })
      .catch((error) => {});
  };

  const getDepositTxnHistory = (data) => {
    props
      .getDepositTxnHistory(data)
      .then((res) => {})
      .catch((error) => {});
  };

  const lineChartCurrency = "USD";

  //line stock start
  const options = { style: "currency", currency: lineChartCurrency };
  const numberFormat = new Intl.NumberFormat("en-US", options);

  const configPrice = {
    yAxis: [
      {
        lineWidth: 0,
        gridLineColor: "#e8e8e8",
        offset: 15,
        opposite: false,

        labels: {
          formatter: function () {
            return numberFormat.format(this.value);
          },
          x: 0,
          style: {
            color: "#5f658a",
            position: "absolute",
          },
          align: "right",
        },
      },
    ],
    tooltip: {
      shared: true,
      formatter: function () {
        return `<p style="color:#fff">Balance: ${
          numberFormat.format(this.y, 0) +
          '</b><br/><span style="color:#fff">' +
          moment(this.x).format("MMMM Do YYYY")
        }</span></p>`;
      },
      backgroundColor: "#3486ff",
      color: "#fff",
      fillText: "#fff",
    },
    plotOptions: {
      series: {
        showInNavigator: true,
        // gapSize: 15,
        color: "#00be00",
      },
    },

    title: {
      text: `<span class="${
        theme == "dark" ? "darkTheme" : ""
      } graphTile">Wallet Balance</span> <br>
   <span class="${
    theme == "dark" ? "darkTheme" : ""
   } balanceAmount">${graphBalance} ${lineChartCurrency}</span>`,
      color: theme == "dark" ? "#fff" : "#050823",
      align: "left",
    },

    credits: {
      enabled: false,
    },

    legend: {
      enabled: true,
    },
    chart: {
      backgroundColor: theme == "dark" ? "#fff" : "#050823",
      height: 575,
      inputPosition: {
        x: +13,
      },
    },
    // style: {
    //   "color": "#fff"

    // },
    xAxis: {
      offset: 15,
      type: "datetime",
      style: {
        color: "#5f658a",
      },
    },
    rangeSelector: {
      // inputPosition: {
      //   x: 0
      // },
      floating: true,
      x: 530,
      y: -50,
      buttons: [
        {
          type: "month",
          count: 1,
          text: "1m",
        },
        {
          type: "month",
          count: 3,
          text: "3m",
        },
        {
          type: "month",
          count: 6,
          text: "6m",
        },
        {
          type: "year",
          count: 1,
          text: "1yr",
        },
        {
          type: "all",
          text: "All",
        },
      ],
      selected: 4,
      enabled: true,
    },
    navigator: {
      enabled: false,
    },
    series: [
      {
        pointStart: graphData && graphData.length > 0 && graphData[0][0],
        name: "Price",
        data: graphData,
      },
    ],
  };
  //line stock end

  const handleChangeToken = (e) => {
    let currentData = tokenData.filter((item) => item.value == e.value);
    setCoinAddress({});
    setSelectedUserCoinBalance([]);
    setCurencyDetails({});
    setMinWithdraw(0);
    setTransactionFee(0);
    setWithdrawLimit(0);
    setWithdrawHistory([]);
    setWithdrawHistoryRecords(0);
    setGraphBalance(0);
    setGraphData([]);

    setNetworkApi(false);
    setNetworkName("");
    setSelectedCoinDeposit(currentData[0].value);
    setCurrentToken(currentData);
    setDefaultTab("all");
    setCurrentUrl(`/auth/deposit?getCoin=${e.value}&tab=${selecteTab}`);
  };

  const handleChange = (e) => {
    const { value, name } = e.target;
    if (name === "withdrawAddress") {
      setAddress(value);
    } else {
      if (/^\d*(\.\d{0,8})?$/.test(value)) {
        validate(value);
      }
    }
    // window.location.replace(`/auth/deposit?getCoin=${e.value}`)
  };

  const getWithdrawDepositTxnHistory = (value, pageVal) => {
    setDefaultTab(value);
    let data = {
      page: pageVal,
      type: value,
      coin: selectedCoinDeposit,
      network: networkName,
      offset: 1,
      limit: 5,
    };
    props.getWithdrawDepositTxnHistory(data).then((res) => {
      setWithdrawHistory(res.data.data);
      setWithdrawHistoryRecords(res.data.totalRecords);
    });
  };

  const withdrawAllInPercent = (percent) => {
    if (userSelectedCoinBalance.length > 0) {
      setMinfeErr(false);
      let totalBalance = userSelectedCoinBalance[0]?.balance / SMALLESTUNIT;
      let balanceInPercent = (totalBalance * percent) / 100;

      setWithdrawAmount(balanceInPercent);
      validate(balanceInPercent);
    }
  };
  let optionVal =
    tokenData &&
    tokenData.length > 0 &&
    tokenData.findIndex((item) => item.value == selectedCoinDeposit);
  const getCurrencyDetails = (coin, network) => {
    props
      .getCurrencyDetails(coin, network)
      .then((res) => {
        setCurencyDetails(res.data.data);
        setMinWithdraw(res.data.data.minimum_withdraw);
        setTransactionFee(res.data.data.withdraw_fee);
        if (props.user_info_status.kycStatus != KYC_APPROVED) {
          setWithdrawLimit(res.data.data.without_kyc_withdraw_limit);
        } else {
          setWithdrawLimit(res.data.data.with_kyc_withdraw_limit);
        }
      })
      .catch((error) => {});
  };

  // Check wheather the entred address is a valid address
  const addressValidator = () => {
    if (address != "" && selectedCoinDeposit != "bch") {
      //let valid = WAValidator.validate(address, selectedCoinDeposit.toUpperCase(), ENV_VAR);
      // if (valid) {
      //   setInvalidAddress(false);
      // } else {
      //   setInvalidAddress(true);
      // }
      setInvalidAddress(false);
    } else {
      setInvalidAddress(false);
    }
  };

  const withdrawRequestValidation = () => {
    let data = {};

    if (withdrawNewtwork != "") {
      data = {
        address: address,
        amount: amount,
        coin: selectedCoinDeposit,
        network: withdrawNewtwork,
      };
    } else {
      data = {
        address: address,
        amount: amount,
        coin: selectedCoinDeposit,
      };
    }

    props
      .withdrawRequestValidation(data, selectedCoinDeposit)
      .then((res) => {
        verifyRequest();
      })
      .catch((error) => {});
  };

  // calling API for withdraw txns(step1)
  // const withdrawRequestValidation = () => {
  //   // console.log('is_google_2fa_active',props.user_info_status?.is_google_2fa_active)
  //   // if (props.user_info_status?.is_google_2fa_active == 1) {
  //   //   setGoogleAuth(true)
  //   // }else{
  //   //  history.push('/auth/authentication')
  //   // }
  //   let data = {
  //     address: address,
  //     amount: amount,
  //     coin: selectedCoinDeposit
  //   }
  //   props.withdrawRequestValidation(data, selectedCoinDeposit).then((res) => {
  //   }).catch((error) => {

  //   })
  // }

  // withdraw step 2
  const verifyRequest = () => {
    if (props.user_info_status?.is_google_2fa_active == 1) {
      setGoogleAuth(true);
    } else {
      // history.push('/auth/authentication')
      history.push({
        pathname: "/auth/enable-authentication",
        state: {
          withdraw: props.location.pathname + "?getCoin=" + parsed.getCoin,
        },
      });
    }
  };

  const handleClose2Auth = () => {
    setGoogleAuth(false);
  };

  const verifyTokenReq = () => {
    let wData = {};
    if (withdrawNewtwork != "") {
      wData = {
        address: address,
        amount: amount,
        coin: selectedCoinDeposit,
        network: withdrawNewtwork,
        ip: currentIp,
      };
    } else {
      wData = {
        address: address,
        amount: amount,
        coin: selectedCoinDeposit,
        ip: currentIp,
      };
    }

    let data = {
      token: securityToken2fa,
    };
    props.token_verification_google(data).then((res) => {
      setGoogleAuth(false);
      withdrawRequestFinal(wData);
    });
  };

  // withdraw final step 5
  const withdrawRequestFinal = (data) => {
    props
      .withdrawRequest(data, selectedCoinDeposit)
      .then((res) => {
        setTimeout(() => {
          window.location.replace(currentUrl);
        }, 2000);
        getWithdrawDepositTxnHistory("all", 1);
        props.getUserBalance();
        props.getParticularCoinBalance(selectedCoinDeposit);
        setAmount("");
        setAddress("");
        setFinalAmount(0);
      })
      .catch((Err) => {});
  };

  const handleTab = (value) => {
    setSelecteTab(value);
  };
  return (
    <>
      <Row className="walletRow_Style m-0">
        <Col xs={12} md={12} lg={12} xl={5} className="tabSide_Col">
          <MainCard>
            <Tabs
              defaultActiveKey={selecteTab}
              id="uncontrolled-tab-example"
              className="customTab_style"
              onSelect={handleTab}
            >
              <Tab eventKey="Deposit" title="Deposit">
                <Row>
                  <Col xs={12} md={6} className="tokenSelect_col">
                    <Form.Label>Select Token</Form.Label>
                    <Select
                      options={tokenData}
                      defaultValue={
                        !!currentToken && currentToken.length > 0
                          ? currentToken[0]
                          : tokenData[0]
                      }
                      value={
                        currentToken.length > 0
                          ? currentToken[0]
                          : tokenData[optionVal]
                      }
                      classNamePrefix="react-select"
                      placeholder="Select Token"
                      label="deposit"
                      onChange={(e) => {
                        handleChangeToken(e);
                      }}
                    />
                    {networkoptions && networkoptions.length > 1 && (
                      <>
                        <Form.Label>Deposit Network</Form.Label>
                        <Select
                          options={networkoptions}
                          defaultValue={networkoptions[0]}
                          classNamePrefix="react-select"
                          placeholder="btc"
                          label="deposit"
                          onChange={(e) => {
                            //onChangeNetwork(e)
                            setNetworkName(e.value);
                          }}
                        />
                      </>
                    )}
                  </Col>
                  <Col xs={12} md={6} className="qrCode_col">
                  <Form.Label className=" depositbalance">
                        
                        {userSelectedCoinBalance.length > 0 && (
                          <span className="balanceTxt">
                            Balance:{" "}
                            <span>
                              {smallestunitFormat(
                                userSelectedCoinBalance[0].balance +
                                  userSelectedCoinBalance[0].locked_balance
                              )}{" "}
                              {selectedCoinDeposit.toUpperCase()}{" "}
                            </span>
                          </span>
                        )}
                      </Form.Label>
                    <Form.Label className="text-center d-block">
                      {selectedCoinDeposit && selectedCoinDeposit.toUpperCase()}{" "}
                      Address
                    </Form.Label>
                    {/* <img src={QrCode} className="qrImg_style qrLight" />
                    <img src={QrCodeBlack} className="qrImg_style qrBlack" /> */}
                    {Object.keys(coinAddress)?.length != 0 && (
                      <QRCode size={150} value={coinAddress.address} />
                    )}
                    <CustomInput
                      className="internalInput depositAddress_field"
                      value={
                        Object.keys(coinAddress).length === 0
                          ? "XXXXXXXXXXXX"
                          : coinAddress.address
                      }
                    >
                      <a
                        onClick={copyToClipboard}
                        className="showPassword copiedIcon"
                      >
                        <img src={CopyIcon} />
                      </a>
                    </CustomInput>
                    {Object.keys(coinAddress).length > 0 && copied && (
                      <p
                        className={`copiedText`}
                        style={{ color: "#329bff", marginBottom: "0px" }}
                      >
                        Copied
                      </p>
                    )}
                  </Col>
                  <ul className="detailMessage">
                    <li>
                      Please send only BTC tokens to this address. Sending other
                      tokens will result in their permanent loss.
                    </li>
                    <li>Minimum Deposit: 1$ worth of BTC</li>
                    <li>
                      Minimum Network Confirmations: 2 (Usually takes ~30 mins)
                    </li>
                  </ul>
                </Row>
              </Tab>
              <Tab eventKey="Withdraw" title="Withdraw">
                <div className="withdrawAmount_Col">
                  <Row>
                    <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                      <Form.Label>Select Token*</Form.Label>
                      <Select
                        options={tokenData}
                        defaultValue={
                          !!currentToken && currentToken.length > 0
                            ? currentToken[0]
                            : tokenData[0]
                        }
                        value={
                          currentToken.length > 0
                            ? currentToken[0]
                            : tokenData[optionVal]
                        }
                        classNamePrefix="react-select"
                        placeholder="Select Token"
                        label="deposit"
                        onChange={(e) => {
                          handleChangeToken(e);
                        }}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                      <Form.Label className="d-flex justify-content-between align-items-end">
                        Amount*
                        {userSelectedCoinBalance.length > 0 && (
                          <span className="balanceTxt">
                            Balance:{" "}
                            <span>
                              {smallestunitFormat(
                                userSelectedCoinBalance[0].balance +
                                  userSelectedCoinBalance[0].locked_balance
                              )}{" "}
                              {selectedCoinDeposit.toUpperCase()}{" "}
                            </span>
                          </span>
                        )}
                      </Form.Label>
                      <CustomInput
                        className="internalInput"
                        placeholder="Enter Amount*"
                        value={amount}
                        name="amount"
                        handleChange={handleChange}
                      ></CustomInput>
                      <div className="amount_range">
                        <button onClick={() => withdrawAllInPercent(25)}>
                          25%
                        </button>
                        <button onClick={() => withdrawAllInPercent(50)}>
                          50%
                        </button>
                        <button onClick={() => withdrawAllInPercent(75)}>
                          75%
                        </button>
                        <button onClick={() => withdrawAllInPercent(100)}>
                          100%
                        </button>
                      </div>
                    </Col>

                    {networkoptions && networkoptions.length > 1 && (
                      <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                        <Form.Label>Deposit Network*</Form.Label>
                        <Select
                          options={networkoptions}
                          defaultValue={networkoptions[0]}
                          classNamePrefix="react-select"
                          placeholder="btc"
                          label="deposit"
                          onChange={(e) => {
                            setNetworkName(e.value);
                            setWithdrawNewtwork(e.value);
                          }}
                        />
                      </Col>
                    )}

                    <Col xs={12} lg={12}>
                      <Form.Label>Withdraw Address*</Form.Label>
                      <CustomInput
                        // disabled={true}
                        name="withdrawAddress"
                        className="internalInput"
                        handleChange={handleChange}
                        value={address}
                        onBlur={() => addressValidator()}
                      >
                        {/* <a
                          onClick={copyToClipboard}
                          className="showPassword currencySelected_style qrIcon_small"
                        >
                          <img src={InputQrIcon} />
                        </a> */}
                      </CustomInput>
                      {invalidAddress && (
                        <p style={{ color: "red" }}>
                          Invalid Address for selected currency.
                        </p>
                      )}
                    </Col>

                    <Col xs={12} lg={12}>
                      <ButtonPrimary
                        onClick={() => withdrawRequestValidation()}
                        disabled={
                          invalidAddress ||
                          minfeErr ||
                          address == "" ||
                          amount <= 0
                        }
                        buttontext="Withdraw"
                        className="internalComn_btn withdrawBtn_Style"
                      />
                    </Col>
                  </Row>
                </div>
              </Tab>
            </Tabs>
          </MainCard>
        </Col>
        <Col
          xs={12}
          md={12}
          lg={12}
          xl={7}
          className="chartCol depositChart_Col"
        >
          <div className="walletChart_Style">
            <ReactHighcharts config={configPrice}></ReactHighcharts>
          </div>
        </Col>
        <Col xs={12} className="tableCol_Style">
          <MainCard>
            <Card.Title className="table_maintitle d-flex">
              <p>Transactions</p>
            </Card.Title>
            <Tabs
              activeKey={defaultTab}
              defaultActiveKey={defaultTab}
              transition={true}
              className="tableTab_style"
              onSelect={(e) => {
                getWithdrawDepositTxnHistory(e, 1);
              }}
            >
              <Tab eventKey="all" title="All">
                <div className="tableOuter_Div deposit_Table">
                  <TransactionTable
                    getWithdrawDepositTxnHistory={getWithdrawDepositTxnHistory}
                    typeVal={`all`}
                    setPageVal={setPageVal}
                    withdrawHistoryRecords={withdrawHistoryRecords}
                    assetName={selectedCoinDeposit}
                    withdrawHistory={withdrawHistory}
                    eventKey="profile"
                    title="All"
                  />
                </div>
              </Tab>
              <Tab eventKey="deposit" title="Deposit">
                <TransactionTable
                  getWithdrawDepositTxnHistory={getWithdrawDepositTxnHistory}
                  typeVal={`deposit`}
                  setPageVal={setPageVal}
                  withdrawHistoryRecords={withdrawHistoryRecords}
                  assetName={selectedCoinDeposit}
                  withdrawHistory={withdrawHistory}
                />
              </Tab>
              <Tab eventKey="withdraw" title="Withdraw">
                <TransactionTable
                  getWithdrawDepositTxnHistory={getWithdrawDepositTxnHistory}
                  typeVal={`withdraw`}
                  setPageVal={setPageVal}
                  withdrawHistoryRecords={withdrawHistoryRecords}
                  assetName={selectedCoinDeposit}
                  withdrawHistory={withdrawHistory}
                />
              </Tab>
            </Tabs>
          </MainCard>
        </Col>
      </Row>

      <Modal2fa
        className="modal_gemailauth"
        show={googleAuth}
        handleClose={handleClose2Auth}
        Title={`Google Authentication`}
        size="md"
      >
        <Form.Group className="customInput">
          <Form.Control
            placeholder="Enter token"
            type="text"
            onChange={(e) => {
              setSecurityToken2fa(e.target.value);
            }}
          />
        </Form.Group>
        <ButtonPrimary onClick={() => verifyTokenReq()} buttontext={"Submit"} />
      </Modal2fa>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    theme: state.persist.theme ? "dark" : "light",
    user_info_status: state.security.userProfile,
    user_info_status: state.security.user_info_status,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getUserInfo: () => dispatch(getUserInfo()),
    getActiveCoins: () => dispatch(getActiveCoins()),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),
    getWalletHistory: () => dispatch(getWalletHistory()),
    getCoinDepositAddress: (coin, network) =>
      dispatch(getCoinDepositAddress(coin, network)),
    getDepositTxnHistory: (coin, network) =>
      dispatch(getDepositTxnHistory(coin, network)),
    getUserBalanceParticularCoin: (coin, network) =>
      dispatch(getUserBalanceParticularCoin(coin, network)),
    getCurrencyDetails: (coin, network) =>
      dispatch(getCurrencyDetails(coin, network)),
    getWithdrawDepositTxnHistory: (data) =>
      dispatch(getWithdrawDepositTxnHistory(data)),

    getCoinNetworkList: (coin, network) =>
      dispatch(getCoinNetworkList(coin, network)),

    withdrawRequestValidation: (data, coin) =>
      dispatch(withdrawRequestValidation(data, coin)),
    withdrawRequest: (data, coin) => dispatch(withdrawRequest(data, coin)),
    token_verification_google: (data) =>
      dispatch(token_verification_google(data)),
    getUserInfo: () => dispatch(getUserInfo()),
    getSingleCoinHistory: (coin, networkName) =>
      dispatch(getSingleCoinHistory(coin, networkName)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(DepositWallet);
