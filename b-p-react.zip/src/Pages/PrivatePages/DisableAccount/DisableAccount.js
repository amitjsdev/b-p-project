import React from "react";
import MainCard from "../../../components/common/MainCard/MainCard";
import { Row, Col, Card, Modal } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import disableicon from "../../../theme/images/disabledAcc.svg";
import "./DisableAccount.scss";
import CommonModal from '../../../components/common/CommonModal/CommonModal'
const DisableAccount = () => {
  const [modalShowAccount, setModalShowAccount] = React.useState(false);
  return (
    <>
      <div className="disable_Style">
        <MainCard>
          <Card.Title className="cardTitle_Padding">Disable account</Card.Title>
          <Row>
            <Col lg={12} className="text-center">
              <img src={disableicon} className="disIcon" />
              <h2>Disable Your Account</h2>
              <ul>
                <li>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium.
                </li>
                <li>Totam rem aperiam, eaque ipsa quae ab illo inven</li>
                <li>
                  Veritatis et quasi architecto beatae vitae dicta explicabo.
                </li>
                <li>
                  Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut
                  odit aut fugit.
                </li>
              </ul>
              <h3>
                If you disable this account, you will be unable to reactivate
                your account until 2 hours have passed
              </h3>
              <ButtonPrimary
                onClick={() => setModalShowAccount(true)}
                buttontext="Disable this account"
                className="internalComn_btn mb-0 Disable_Btn"
              />
              <DisableAccountModal
                show={modalShowAccount}
                onHide={() => setModalShowAccount(false)}
              />
            </Col>
          </Row>
        </MainCard>
      </div>
    </>
  );
};

export default DisableAccount;

// Disable Account Modal

function DisableAccountModal(props) {
  return (
    <div>
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        className="DisableAccountModal"
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter"></Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="textDiv">
            <h4 className="modalHeading">
              Are you sure you want to disable your account?
            </h4>
            <p className="modalText">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer
              eget nunc tempus, eleifend tellus ve.
            </p>
          </div>

          <div className="bottomSecOuter">
            <Row className="btnsRow">
              <Col xs={12} sm={6} className="btnsCol">
                <ButtonPrimary
                  buttontext="Disable"
                  className="internalComn_btn mb-0 authenticationBtn"
                />
              </Col>
              <Col xs={12} sm={6} className="btnsCol">
                <button className="exportBtn">Don't Disable</button>
              </Col>
            </Row>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}
