import React, { useState } from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "../../../components/common/CustomTable/CustomTable.scss";
import InviteModal from "./InviteModal";

function ReferralLinksTable(props) {
  // for invite link
  const [referralId, setReferralId] = useState(false);
  const [inviteshow, invitesetShow] = useState(false);
  const invitehandleClose = () => invitesetShow(false);
  const invitehandleShow = (value) => {
    invitesetShow(true);
    setReferralId(value);
  }
  return (
    <div className="tableOuter_Div deposit_Table">
      <PerfectScrollbar>
        <Table className={`customTable ${props.className}`}>
          <thead>
            <tr>
              <th></th>
              <th>Referral ID</th>
              <th>You Receive</th>
              <th>Friends Receive</th>
              <th>Friends</th>
              <th>Affiliated</th>
              <th>Action</th>
            </tr>
          </thead>
          {props.linksData?.tokens_list && props.linksData?.tokens_list.length > 0 ?
            <tbody>
              {props.linksData?.tokens_list.map((item) => {

                return (
                  <tr>
                    <td>{item?.is_default_token == 1 ? 'Default' : ''}</td>
                    <td>{item?.referral_token}</td>
                    <td> {item?.is_default_token == 1 ? '20' : item?.plan1_user_rate}</td>
                    <td>{item?.is_default_token == 1 ? '0' : item?.plan2_reffered_rate}</td>
                    <td>{item?.referred_count}</td>
                    <td>{item?.is_affiliate == 1 ? "Yes" : "No"}</td>
                    <td>
                      <button className="inviteLink" onClick={()=>{invitehandleShow(item?.referral_token)}}>
                        Invite
                      </button>
                    </td>
                  </tr>
                )
              })
              }
            </tbody>
            : 
            <tbody>
                  <tr>
                    <td colSpan="7" className="text-center noTransaction_found">
                      No Records Found
                    </td>
                  </tr>
                </tbody>
          }
        </Table>
      </PerfectScrollbar>
      <InviteModal webUrl={`${props.webUrl}/signup?referral=${referralId}`} referralId={referralId} show={inviteshow} onHide={invitehandleClose} />
    </div>
  );
}

export default ReferralLinksTable;
