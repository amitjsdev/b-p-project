import React, { useState } from "react";
import { Modal } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";

const ViewRuleModal = ({ show, onHide }) => {
  return (
    <Modal show={show} onHide={onHide} centered className="gentrateLink_Modal">
      <Modal.Header closeButton>
        <Modal.Title>Rules</Modal.Title>
      </Modal.Header>
      <div className="viewRule_Content">
        <ul>
          <li>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </li>
          <li>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </li>
          <li>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </li>
          <li>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </li>
        </ul>
        <ButtonPrimary
        onClick={onHide}
          closeButton
          buttontext="Close"
          className="internalComn_btn"
        />
      </div>
    </Modal>
  );
};

export default ViewRuleModal;
