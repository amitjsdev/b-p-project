import React,{useState} from "react";
import { Modal } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import copy from "copy-to-clipboard";

const InviteModal = ({ show, onHide,webUrl, referralId }) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = (val) => {
    copy(val);
    setCopied(true);
    setTimeout(() => {
      onHide()
      setCopied(false);
    }, 1000);
  }

  return (
    <Modal show={show} onHide={onHide} centered className="gentrateLink_Modal">
      <Modal.Header closeButton>
        <Modal.Title>Invite Your Friend</Modal.Title>
      </Modal.Header>
      <div className="gentrateLink_Content">
        <p>{webUrl}</p>
        <ButtonPrimary onClick={()=>{copyToClipboard(webUrl)}} buttontext={copied ? 'COPIED' : `COPY`} className="internalComn_btn" />
      </div>
    </Modal>
  );
};

export default InviteModal;
