import React from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import moment from "moment";
import {SMALLESTUNIT} from '../../../constant';
import ReactPaginate from "react-paginate";

function ReferralTable(props) {
  const { handlePagination,friendlistData, commissionData, earnedData,commission_count,friends_count,earn_count } = props;

  const handlePageClick = (event, val) => {
    const newPage = event.selected;
    handlePagination(newPage)
  };

  return (
    <>
      {props.friendlist ? (
        <>
          <div className="tableOuter_Div deposit_Table">
            <PerfectScrollbar
            // onScrollY={(container) =>
            //   console.log(`scrolled to: ${container.scrollTop}.`)
            // }
            >
              <Table className={`customTable ${props.className}`}>
                <thead>
                  <tr>
                    <th>Friend's Email</th>
                    <th>Friend's User ID</th>
                    <th>Referral Bonus Earned</th>
                    <th>Registration Time</th>
                  </tr>
                </thead>
                {/* NO RECORD FOUND */}
                <tbody>
                 
                    {friendlistData && friendlistData.length > 0 ? (
                      friendlistData.map((item) => {
                        return (
                          <tr>
                            <td>{item.email}</td>
                            <td>{item.user_id}</td>
                            <td>{(item.amount/SMALLESTUNIT).toFixed(8)}</td>
                            <td>
                              {moment(item.created_at).format(
                                "MMM DD YY, h:mm:ss a"
                              )}
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                      <td
                        colSpan="4"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                      </tr>
                    )}
                </tbody>
              </Table>
              {friends_count && friends_count > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e, "trade")}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(friends_count / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )}
            </PerfectScrollbar>
          </div>
        </>
      ) : null}

      {props.commission_history ? (
        <>
          <div className="tableOuter_Div deposit_Table">
            <PerfectScrollbar
            // onScrollY={(container) =>
            //   console.log(`scrolled to: ${container.scrollTop}.`)
            // }
            >
              <Table className={`customTable ${props.className}`}>
                <thead>
                  <tr>
                    <th>Friend Email</th>
                    <th>Friend's User ID</th>
                    <th>Commission Earned</th>
                    <th>Commission Date Time</th>
                  </tr>
                </thead>
                <tbody>
                  {commissionData && commissionData.length > 0 ? (
                    commissionData.map((item) => {
                      return (
                        <tr>
                           <td>{item.email}</td>
                            <td>{item.user_id}</td>
                            <td>{(item.amount/SMALLESTUNIT).toFixed(8)}</td>
                            <td>
                              {moment(item.created_at).format(
                                "MMM DD YY, h:mm:ss a"
                              )}
                            </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="4"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                    </tr>
                  )}
                </tbody>
                {/* NO RECORD FOUND */}
              </Table>
              { commission_count > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e, "trade")}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(commission_count / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )}
              
            </PerfectScrollbar>
          </div>
        </>
      ) : null}

      {props.earned ? (
        <>
          <div className="tableOuter_Div deposit_Table">
            <PerfectScrollbar
            // onScrollY={(container) =>
            //   console.log(`scrolled to: ${container.scrollTop}.`)
            // }
            >
              <Table className={`customTable ${props.className}`}>
                <thead>
                  <tr>
                    <th>Email</th>
                    <th>Commission Earned</th>
                    <th>Commission Date Time</th>
                  </tr>
                </thead>
                <tbody>
                  {earnedData && earnedData.length > 0 ? (
                    earnedData.map((item) => {
                      return (
                        <tr>
                            <td>{item.email}</td>
                          <td>{(item.amount/SMALLESTUNIT).toFixed(8)}</td>
                          <td>
                              {moment(item.created_at).format(
                                "MMM DD YY, h:mm:ss a"
                              )}
                            </td>      
                         </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td
                        colSpan="4"
                        className="text-center noTransaction_found"
                      >
                        No Transactions Found
                      </td>
                    </tr>
                  )}
                </tbody>
                {/* NO RECORD FOUND */}
              </Table>
              {earn_count > 0 && (
                <ReactPaginate
                  className="paginationStyle"
                  breakLabel="..."
                  nextLabel=">"
                  onPageChange={(e) => handlePageClick(e, "trade")}
                  pageRangeDisplayed={5}
                  // pageCount={100}
                  pageCount={Math.ceil(earn_count / 5)}
                  previousLabel="<"
                  renderOnZeroPageCount={null}
                />
              )}
            </PerfectScrollbar>
          </div>
        </>
      ) : null}
    </>
  );
}

export default ReferralTable;
