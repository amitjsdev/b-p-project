import React,{useState} from "react";
import { Modal } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";

const GenrateLinkModal = (props) => {
const { show, onHide,customPlans,setGenerateLink,getReferralToken } = props;
  const [youReceive, setYouReceive] = useState(15);
  const [friendReceive, setFriendReceive] = useState(5);


  const generateLink = (val) => {
    let percentVal = 20 - val
    setYouReceive(percentVal)
    setFriendReceive(val)
  }
 
const sendRequest = () =>{
  let generateId = [];
  if(customPlans && customPlans.length > 0){
     generateId = customPlans.filter(item=> item.plan_rate == friendReceive);
  }
 onHide()
  getReferralToken(generateId)
}

  return (
    <Modal show={show} onHide={onHide} centered className="gentrateLink_Modal">
      <Modal.Header closeButton>
        <Modal.Title>Generate your link</Modal.Title>
      </Modal.Header>
      <div className="gentrateLink_Content">
        <p>
          Your Base Commission Rate: <span>{youReceive}%</span>
        </p>
        <p>
          Set Friends' Commission Kickback Rate: <span>{friendReceive}%</span>
        </p>
        <div className="recieveSec">
          <h4>
            <span>{youReceive}%</span>
            <span>You Receive</span>
          </h4>
          <h4>
            <span>{friendReceive}%</span>
            <span>Friends Receive</span>
          </h4>
        </div>
        <div className="amount_percentage_btns">
          <ul>
            <li className={friendReceive == 5 ? `active_plan` : ''}>
              <a type="button" onClick={()=>{generateLink(5)}} className={friendReceive == 5 ? `active` : ''}>
                5%
              </a>
            </li>
            <li className={friendReceive == 10 ? `active_plan` : ''}>
              <a className={friendReceive == 10 ? `active` : ''} type="button" onClick={()=>{generateLink(10)}}>10%</a>
            </li>
            <li className={friendReceive == 15 ? `active_plan` : ''}>
              <a className={friendReceive == 15 ? `active` : ''} type="button" onClick={()=>{generateLink(15)}}>15%</a>
            </li>
            <li className={friendReceive == 20 ? `active_plan` : ''}>
              <a className={friendReceive == 20 ? `active` : ''} type="button" onClick={()=>{generateLink(20)}}>20%</a>
            </li>
          </ul>
        </div>
        <ButtonPrimary
        onClick={sendRequest}
          buttontext="Generate your link"
          className="internalComn_btn"
        />
      </div>
    </Modal>
  );
};

export default GenrateLinkModal;
