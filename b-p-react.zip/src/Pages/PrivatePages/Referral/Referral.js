import React, { useEffect, useState } from "react";
import { Row, Col, Tabs, Tab, Container, Modal } from "react-bootstrap";
import { connect } from "react-redux";
import MainCard from "../../../components/common/MainCard/MainCard";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CopyIcon from "../../../theme/images/copy_icon.svg";
import AddIcon from "../../../theme/images/addIcon.svg";
import Traders from "../../../theme/images/traders.svg";
import Earn from "../../../theme/images/earn.svg";
import Friends from "../../../theme/images/friends.svg";
import Announcement from "../../../theme/images/announcement.svg";
import "./Referral.scss";
import ReferralTable from "./ReferralTable";
import ReferralLinksTable from "./ReferralLinksTable";
import InviteModal from "./InviteModal";
import GenrateLinkModal from "./GenrateLinkModal";

import copy from "copy-to-clipboard";

import {
  getReferralLinks,
  getReferralToken,
  getReferralHistory,
  getCustomPlans,
} from "../../../redux/actions/ReferralActions";
import referral from "../../../redux/reducers/referral";
import ViewRuleModal from "./ViewRuleModal";

function Referral(props) {
  let webUrl = window.location.origin;
  // for genrate link
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // for view rule
  const [ruleshow, rulesetShow] = useState(false);
  const rulehandleClose = () => rulesetShow(false);
  const rulehandleShow = () => rulesetShow(true);

  // for invite link
  const [inviteshow, invitesetShow] = useState(false);
  const invitehandleClose = () => invitesetShow(false);
  const invitehandleShow = () => invitesetShow(true);
  const [copied, setCopied] = useState(false);
  const [generateLink, setGenerateLink] = useState([]);

  const [defaultReferral, setDefaultReferral] = useState([]);

  const copyToClipboard = (val) => {
    copy(val);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 5000);
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });

    getReferralToken(null);
    //props.getReferralHistory({ offset: 0 });
    props.getCustomPlans();
  }, []);

  const getReferralToken = (generateId) => {
    let data = {};
    if (generateId != null && generateId.length > 0) {
      setGenerateLink(generateId);
      data = { isDefault: 0, isAffiliate: 0, planId: generateId[0]?.plan_id };
    } else {
      data = { isDefault: 1, planId: "" };
    }
    props.getReferralToken(data).then((res) => {
      setDefaultReferral(res.data.data);
      props.getReferralHistory({ offset: 0 });
    });
  };

  const handlePagination = (val) =>{
    // let pageVal;
    // if(val == 1){
    //   pageVal = 0
    // }else{
    //   pageVal = val;
    // }
    props.getReferralHistory({ offset: val });
  }

  return (
    <>
      <Container className="referralCard_style">
        <MainCard title="Referral">
          <Row className="rewardRow_style">
            <Col xs={12} md={12} lg={6} className="rewardCol_left">
              <h2>
                Invite your family and friends & earn referral upto 20% bonus
              </h2>
              <div className="d-flex align-items-center mt-4">
                <ButtonPrimary
                  buttontext="Invite"
                  className="m-0 internalComn_btn"
                  onClick={invitehandleShow}
                />
                <ButtonPrimary
                  buttontext="View Rule"
                  className="mx-2 cancel_btn"
                  onClick={rulehandleShow}
                />
              </div>
            </Col>
            <Col xs={12} md={12} lg={6} className="commnCol_bg rewardCol_Right">
              <button onClick={handleShow} className="generateLink_btn">
                <img src={AddIcon} alt="add_icon" />
                Generate custom link
              </button>
              <div className="rewardRatio_div">
                <h4>{defaultReferral?.referral_token}</h4>
                <h6>Default Referral ID</h6>
              </div>
              {!!defaultReferral?.referral_token && (
                <div className="rewardRatio_div">
                  <span className="referralLink">
                    <h4>
                      {`${webUrl}/signup?referral=${defaultReferral?.referral_token}`}
                    </h4>
                    <h6>Default Link</h6>
                  </span>

                  <div className="d-flex align-items-center">
                    <img
                      onClick={() => {
                        copyToClipboard(
                          `${webUrl}/signup?referral=${defaultReferral?.referral_token}`
                        );
                      }}
                      src={CopyIcon}
                      alt="copy icon"
                    />
                    {copied && <span className="copiedText">Copied</span>}
                  </div>
                </div>
              )}
              <div className="recieveSec">
                <h4>
                  <span>
                    {generateLink.length > 0
                      ? generateLink[0]?.plan1_user_rate
                      : 15}{" "}
                  </span>
                  <span>You Receive</span>
                </h4>
                <h4>
                  <span>
                    {generateLink.length > 0
                      ? generateLink[0]?.plan2_reffered_rate
                      : 5}{" "}
                  </span>
                  <span>Friends Receive</span>
                </h4>
              </div>
            </Col>
          </Row>
        </MainCard>
        <MainCard title="Referral Dashboard">
          <div className="referralDashboard">
            {/* <a href="#" className="viewAll_Links">
              All
            </a> */}
            <Row className="dashboardInner">
              <Col xs={12} sm={12} lg={4} className="dashboardInner_Col">
                <img alt="alt" src={Earn} alt="earn icon" />
                <h2>
                  {props.referralLinks?.earned_total_balance == null ? 0 : props.referralLinks?.earned_total_balance } <span>You Earn</span>
                </h2>
              </Col>
              <Col xs={12} sm={12} lg={4} className="dashboardInner_Col">
                <img alt="alt" src={Traders} alt="traders icon" />
                <h2>
                  {props.referralLinks?.commission_count}{" "}
                  <span>Number of Traded Friends</span>
                </h2>
              </Col>
              <Col xs={12} sm={12} lg={4} className="dashboardInner_Col">
                <img alt="alt" src={Friends} alt="friends icon" />
                <h2>
                  {props.referralLinks?.friends_count}{" "}
                  <span>Total Numbers of Friends</span>
                </h2>
              </Col>
            </Row>
            <p>
              *Data update time refers to UTC + 0 time zone. The data
              maintenance time is 3am - 5am (UTC+0) every day. During this
              period, the calculation of today's data is based on the assets of
              previous day. After maintenance, all data will be displayed
              properly
            </p>
            <p>
              *Statement: due to the complexity of financial data, there might
              be nuances and delay. Data displayed above is for reference only.
              We sincerely apologize for any inconvenience.
            </p>
          </div>
        </MainCard>
        <p className="announcement">
          <img alt="icon" src={Announcement} />
          Your referral commission will be credited to your wallet balance
          within the next 24 hours. If you do not receive your commission within
          24 hours, please contact our online support center for further
          assistance.
        </p>
        <div className="tableCol_Style mb-4">
          <MainCard title="&nbsp;" className="referralTable_Style">
            <Tabs
              defaultActiveKey="home"
              transition={true}
              className="tableTab_style"
              onSelect={(e) => {
                handlePagination(0);
              }}
            >
              <Tab eventKey="home" title="Friends List">
                <ReferralTable
                handlePagination={handlePagination}
                friends_count={props.referralLinks?.friends_count}
                  friendlist
                  friendlistData={props.referralLinks?.friends_list}
                />
              </Tab>
              <Tab eventKey="profile" title="Commission History">
                <ReferralTable
                 handlePagination={handlePagination}
                 commission_count={props.referralLinks?.commission_count}
                  commission_history
                  commissionData={props.referralLinks?.commission_list}
                />
              </Tab>
              <Tab eventKey="contact" title="Earned">
                <ReferralTable
                 handlePagination={handlePagination}
                 earn_count={props.referralLinks?.earnedList_count}
                  earned
                  earnedData={props.referralLinks?.earnedList}
                />
              </Tab>
            </Tabs>
          </MainCard>
        </div>
        <div className="showAll_records">
          <button
            onClick={handleShow}
            className="generateLink_btn ml-auto mb-0"
          >
            <img src={AddIcon} alt="add_icon" />
            Generate custom link
          </button>
        </div>
        <MainCard
          title="Your Referral Links List"
          className="referralTable_Style mb-0"
        >
          <ReferralLinksTable webUrl={webUrl} linksData={props.referralLinks} />
        </MainCard>
      </Container>

      {/* genrate link modal */}
      <GenrateLinkModal
        getReferralToken={getReferralToken}
        customPlans={props.customPlans}
        show={show}
        onHide={handleClose}
      />
      {/* invite link modal */}
      <InviteModal
        webUrl={`${webUrl}/signup?referral=${defaultReferral?.referral_token}`}
        show={inviteshow}
        onHide={invitehandleClose}
      />
      {/* View rule modal */}
      <ViewRuleModal show={ruleshow} onHide={rulehandleClose} />
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    user_info_status: state.security.userProfile,
    user_info_status: state.security.user_info_status,
    referralLinks: state.referral.referral_links,
    customPlans: state.referral.customPlans,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getReferralToken: (data) => dispatch(getReferralToken(data)),
    getReferralHistory: (data) => dispatch(getReferralHistory(data)),
    getCustomPlans: () => dispatch(getCustomPlans()),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Referral);
