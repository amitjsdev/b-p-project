import React, { useEffect, useState } from "react";
import { Row, Col, Card } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import CountryPicker from "../../../components/common/CountryPicker/CountryPicker";
import UploadDocumentInput from "../../../components/common/UploadDocumentInput/UploadDocumentInput";
import { connect } from "react-redux";
import {
  saveKycFormData,
  uploadRawFile,
  updateUserKyc,
} from "../../../redux/actions/SecurityActions";
import DocFront from "../../../theme/images/doc_front.svg";
import DocBack from "../../../theme/images/doc_back.svg";
import DocFrontLite from "../../../theme/images/doc_front_lite.svg";
import DocBackLite from "../../../theme/images/doc_back_lite.svg";

import { withRouter } from "react-router";
import "./Kyc.scss";
import TakeSelfie from "../../../components/common/UploadDocumentInput/TakeSelfie";
import Selfie from "../../../theme/images/selfie.svg";
import SelfieLite from "../../../theme/images/selfie_lite.svg";
import { S3_BASE_PATH } from "../../../constant";

function KycdocUpload(props) {
  const [formData, setFormData] = useState(props?.location?.state);
  const documentType = [
    { key: 1, value: "", label: "Select Document" },
    { key: 2, value: 0, label: "Passport" },
    { key: 3, value: 3, label: "License" },
  ];

  const [checkDocument, setCheckDocument] = useState(false);

  const [checkSelfiImg, setCheckSelfiImg] = useState(false);

  let currentIp = localStorage.getItem("currentIp");

  let history = useHistory();

  let selfiTaken = props.selfie
    ? props.kyc_selfie_path
    : formData?.data?.selfiePath;
  const kycDataFront =
    formData?.data?.documents && formData?.data?.documents.length > 0
      ? formData?.data?.documents[0]
      : "";
  let firstId = "";
  let firstImgPath = "";
  let secondId = "";
  let secondImgPath = "";

  if (kycDataFront?.type == 0 || kycDataFront?.type == 3) {
    firstId = kycDataFront?.file_id ? kycDataFront?.file_id : "";
    firstImgPath = kycDataFront?.s3_path;
  } else {
    secondId = kycDataFront?.file_id ? kycDataFront?.file_id : "";
    secondImgPath = kycDataFront?.s3_path;
  }
  const kycDataBack =
    formData?.data?.documents && formData?.data?.documents.length > 0
      ? formData?.data?.documents[1]
      : "";
  if (kycDataBack) {
    secondId = kycDataBack?.file_id ? kycDataBack?.file_id : "";
    secondImgPath = kycDataBack?.s3_path;
  }

  const handleClick = () => {
    history.push("/auth/kycsubmited");
  };
  const backTodetail = () => {
    // history.push("/auth/kycdetail");

    history.push({
      pathname: "/auth/kycdetail",
      state: formData,
    });
  };

  useEffect(() => {
    if (!props?.location?.state?.data) {
      history.push("/auth/kycdetail");
    }
  }, [props]);

  useEffect(() => {
    if (
      !formData?.data?.firstname ||
      !formData?.data?.lastname ||
      !formData?.data?.mobileNumber ||
      !formData?.data?.country_id
    ) {
      history.push("/auth/kycdetail");
    }
  }, [formData]);

  const saveDocFile = (e, type, temp) => {
    //props.showProcessing(true);
    let file = e.target.files[0];
    // let fileSize = file.size / 1024 / 1024;
    const formDataVal = new FormData();
    formDataVal.append("upload_file", file);
    // props.showProcessing(true);
    props
      .uploadRawFile(formDataVal)
      .then((res) => {
        //props.showProcessing(false);

        let fileId = res.data.data.fileId;
        let path = res.data.data.fullS3FilePath;
        props.saveKycFormData({ prop: type, value: fileId });
        props.saveKycFormData({ prop: temp, value: path });
      })
      .catch((error) => {
        //history.push("/auth/kycdetail");
      });
  };

  const handleChange = (e, type) => {
    let data = {};
    if (formData && formData?.data) {
      data = { ...formData?.data };
    }
    data[type] = e.target.value;
    setFormData({ ...formData, data: data });
  };

  const onSubmitForm = (e) => {
    e.preventDefault();
    let selfieId = props.selfie ? props.selfie : formData?.data?.selfie_id;

    if (!formData?.data?.doc_type) {
      window.scrollTo({ top: 0, behavior: "smooth" });
      setCheckDocument(true);
      return;
    }

    if (!selfieId) {
      setCheckSelfiImg(true);
      return;
    }
    setCheckSelfiImg(false);
    setCheckDocument(false);

    let data = {
      ip: currentIp,
      firstname: formData?.data?.firstname,
      lastname: formData?.data?.lastname,
      phone_code: formData?.data?.phone_code,
      country_code: formData?.data?.country_code, //eg. +91 (optional in api)
      mobile_no: formData?.data?.mobileNumber.toString(), //eg. India (optional in api)
      countryid: formData?.data?.country_id,
      selfieid: props.selfie ? props.selfie : formData?.data?.selfie_id,
      documents: [
        {
          document_id_temp: props.kyc_doc_path_front
            ? props.kyc_doc_path_front
            : firstImgPath,
          document_id: props.doc_front ? props.doc_front : firstId,
          document_no: formData?.data?.document_number
            ? formData?.data?.document_number
            : formData?.data?.documents[0]?.document_number,
          document_type: formData?.data?.doc_type
            ? +formData?.data?.doc_type
            : formData?.data?.documents[0]?.type,
        },
        {
          document_id_temp: props.kyc_doc_path_back
            ? props.kyc_doc_path_back
            : secondImgPath,
          document_id: props.doc_back ? props.doc_back : secondId,
          document_no: formData?.data?.document_number
            ? formData?.data?.document_number
            : formData?.data?.documents[0]?.document_number,
          document_type:
            formData?.data?.doc_type == "0"
              ? 2
              : formData?.data?.doc_type == "3"
              ? 4
              : formData?.data?.documents[1]?.type,
        },
      ],
    };
    props.updateUserKyc(data).then((res) => {
      // window.location.reload();
      // history.push("/auth/kycsubmited");
      history.push("/auth/kycdetail");
    });
  };

  return (
    <>
      <MainCard className="kycCard_Style mainCard_padding">
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
        <form onSubmit={onSubmitForm}>
          <Col className="kycDetail_Row">
            <Row>
              <Col xs={12} lg={4}>
                <CountryPicker
                  defaultValue={
                    formData?.data?.doc_type
                      ? formData?.data?.doc_type
                      : formData?.data?.documents[0]?.type
                  }
                  // selectedDoc={formData?.data?.documents[0]}
                  label="Document Type*"
                  placeholder="Passport"
                  className="internalInput"
                  countryName={documentType}
                  handleChange={handleChange}
                  name={"doc_type"}
                >
                  {checkDocument && (
                    <p style={{ marginTop: "10px", color: "red" }}>
                      This is required field.
                    </p>
                  )}
                </CountryPicker>
              </Col>
              <Col xs={12} lg={4}>
                <CustomInput
                  handleChange={handleChange}
                  label="Document Number*"
                  placeholder=""
                  className="internalInput"
                  value={
                    formData?.data?.document_number
                      ? formData?.data?.document_number
                      : formData?.data?.documents[0]?.document_number
                  }
                  name={"document_number"}
                ></CustomInput>
              </Col>
            </Row>
            <Row className="uploadDoc_wrap">
              <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
                <UploadDocumentInput
                  icon={DocFront}
                  iconLight={DocFrontLite}
                  label={`${props.doc_type} Front*`}
                  onChange={(e) =>
                    saveDocFile(e, "doc_front", "kyc_doc_path_front")
                  }
                  isDoc={props.doc_front ? props.doc_front : firstId}
                  type="doc_front"
                  docPath={
                    props.kyc_doc_path_front
                      ? props.kyc_doc_path_front
                      : firstImgPath
                  }
                />
              </Col>
              <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
                <UploadDocumentInput
                  icon={DocBack}
                  iconLight={DocBackLite}
                  label={`${props.doc_type} Back*`}
                  onChange={(e) =>
                    saveDocFile(e, "doc_back", "kyc_doc_path_back")
                  }
                  isDoc={props.doc_back ? props.doc_back : secondId}
                  type="doc_back"
                  docPath={
                    props.kyc_doc_path_back
                      ? props.kyc_doc_path_back
                      : secondImgPath
                  }
                />
              </Col>
              <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
                <TakeSelfie
                  setCheckSelfiImg={setCheckSelfiImg}
                  label="Selfie with ID*"
                  icon={Selfie}
                  iconLight={SelfieLite}
                  imgUrl={
                    props.kyc_selfie_path
                      ? props.kyc_selfie_path
                      : formData?.data?.selfiePath
                  }
                  isDoc={
                    props.selfie
                      ? props.kyc_selfie_path
                      : formData?.data?.selfie_id
                  }
                  type="national_id"
                />
                {checkSelfiImg && (
                  <p style={{ marginTop: "10px", color: "red" }}>
                    This is required field.
                  </p>
                )}
              </Col>
              {/* <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
              <TakeSelfie
                label="Selfie with ID"
                icon={Selfie}
                iconLight={SelfieLite}
              />
            </Col> */}
            </Row>
            <Row>
              <Col xs={12} md={6} lg={6} xl={4} className="kycBtn_col">
                <ButtonPrimary
                  buttontext="BACK"
                  className="cancel_btn mb-0"
                  onClick={backTodetail}
                />
                {}
                <ButtonPrimary
                  // disabled={!selfiTaken}
                  buttontext="COMPLETE KYC"
                  className="internalComn_btn mb-0"
                  // onClick={handleClick}
                />
              </Col>
            </Row>
          </Col>
        </form>
      </MainCard>
    </>
  );
}

// export default KycdocUpload;
const mapStateToProps = (state) => {
  return {
    doc_type: state.security.doc_type,
    doc_front: state.security.doc_front,
    doc_back: state.security.doc_back,
    national_id: state.security.national_id,

    selfie: state.security.selfie,

    kyc_selfie_path: state.security.kyc_selfie_path,
    kyc_doc_path_front: state.security.kyc_doc_path_front,
    kyc_doc_path_back: state.security.kyc_doc_path_back,
    kyc_national_doc_path: state.security.kyc_national_doc_path,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveKycFormData: (data) => dispatch(saveKycFormData(data)),
    uploadRawFile: (data) => dispatch(uploadRawFile(data)),
    updateUserKyc: (data) => dispatch(updateUserKyc(data)),
  };
};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(KycdocUpload)
);
