import React, { useState, useEffect } from "react";
import { Row, Col, Card, Form } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import CountryPicker from "../../../components/common/CountryPicker/CountryPicker";
import PhoneInput from "../../../components/common/PhoneInput/PhoneInput";
import DobCustom from "../../../components/common/DobCustom/DobCustom";
import { getFormatedCountries } from "../../../Helpers/Normailize";
import { getData } from "country-list";
import {
  getCountries,
  getCountryCallingCode,
} from "react-phone-number-input/input";
import axios from "axios";
import {
  getUserKycDetails,
  clearKycFormData,
  saveKycFormData,
  uploadRawFile,
  updateUserKyc,
} from "../../../redux/actions/SecurityActions";
import { connect } from "react-redux";

import DatePicker from "react-datepicker";

import "./Kyc.scss";
import {
  PASSPORT_BACK,
  PASSPORT_FRONT,
  LICENSE_BACK,
  LICENSE_FRONT,
  NATIONAL_ID,
  KYC_APPROVED,
  KYC_DECLINED,
  KYC_RE_SUBMITTED,
  KYC_SUBMITTED,
} from "../../../constant";

function KycDetail(props) {
  const {userProfile}  = props;
  const [phone_code, setPhoneCode] = React.useState("");
  const [phoneNumberMin, setPhoneNumberMin] = React.useState(false);
  const [phoneNumberMax, setPhoneNumberMax] = React.useState(false);
  const [formData, setFormData] = useState(props?.location?.state);
  const [kycGetDetails, setKycGetDetails] = useState({});
  const [isKycRes, setIsKycRes] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);
  const [phoneCodeError, setPhoneCodeError] = useState(false);

  const [checkData, setCheckData] = useState(false);

  // const [startDate, setStartDate] = useState(
  //   props?.kycGetDetails?.dob ? new Date(props?.kycGetDetails?.dob) : ""
  // );
  let history = useHistory();

  const options = () => {
    const optionsList = [];
    getCountries().forEach((country, index) => {
      const value = `${getCountryCallingCode(country)}`;
      optionsList.push({
        // key: `${index}_${value}`,
        value: `+${value}`,
        label: `+${value}`,
      });
    });
    return optionsList;
  };

  const getCountryCode = () => {
    axios.get("https://ipapi.co/json/").then((response) => {
      let data = {};

      let resultData = response.data;
      let c_code = resultData.country_calling_code;
      data = { ...formData?.data };

      setPhoneCode(c_code);
      // data['phone_code'] = c_code;
      // setFormData({ ...formData, data })
    });
  };
  const CountryName = getFormatedCountries(getData());
  const handleClick = () => {
    history.push("/auth/kycnotsubmit");
  };
  const saveDetail = (e) => {
    e.preventDefault();
    if (
      (formData?.data?.firstname &&
        formData?.data?.firstname.indexOf(" ") == 0) ||
      (formData?.data?.lastname &&
        formData?.data?.lastname.indexOf(" ") == 0) ||
      formData?.data?.phone_code == null ||
      formData?.data?.phone_code == "null" ||
      formData?.data?.phone_code == ""
    ) {
      if (
        formData?.data?.phone_code == null ||
        formData?.data?.phone_code == "null" ||
        formData?.data?.phone_code == ""
      ) {
        setPhoneCodeError(true);
      }
    } else {
      setPhoneCodeError(false);

      history.push({
        pathname: "/auth/kyc-upload",
        state: formData,
      });
    }
  };
  const handleChange = (e, type) => {
    let data = {};
    if (formData && formData?.data) {
      data = { ...formData?.data };
    }
    let value;
    if (type === "dob") {
      value = e;
    } else if (type === "mobileNumber") {
      // data['phone_code'] = formData?.data?.phone_code != null ? formData?.data?.phone_code : userProfile?.mobileCode;
      setPhoneCodeError(false);
      value = Math.abs(e.target.value);
    } else if (type === "phone_code") {
      setPhoneCodeError(false);
      value = e.value;
    } else {
      value = e.target.value;
    }
    // if (formData && formData?.data) {
    //   data = { ...formData?.data };
    // }
    data[type] = value;
    data[type] = value;
    setFormData({ ...formData, data });
  };

  useEffect(() => {
    getCountryCode();
    getUserKycDetails();
    // return () => {
    //   props.clearKycFormData();
    // };
  }, []);

  useEffect(() => {
if(checkData){
  var dataLength = Object.keys(formData?.data).length;
  if(dataLength > 0){
    let data = {};
    if (formData && formData?.data) {
      data = { ...formData?.data };
    }
  data['firstname'] = formData?.data?.firstname ? formData?.data?.firstname : userProfile?.first_name;
    data['lastname'] = formData?.data?.lastname ? formData?.data?.lastname : userProfile?.last_name;
    data['country_id'] =formData?.data?.country_code ? formData?.data?.country_code :  formData?.data?.country_id ? formData?.data?.country_id : userProfile?.country
    data['mobileNumber'] =formData?.data?.mobileNumber ? formData?.data?.mobileNumber : userProfile?.mobileNumber
    data['phone_code'] =formData?.data?.phone_code != null? formData?.data?.phone_code : userProfile?.mobileCode
    setFormData({ ...formData, data });
  }
}
  }, [checkData,userProfile]);

  const getUserKycDetails = () => {
    props
      .getUserKycDetails()
      .then(async (res) => {
        await setKycGetDetails(res.data.data);
        
        if(!formData?.data?.firstname && !formData?.data?.lastname &&
          !formData?.data?.mobileNumber && !formData?.data?.country_id){
            await setFormData({ ...formData, data: res.data.data });
          }

        if (res.data.data.status == KYC_APPROVED) {
          //setVerificationApproved(true);
        }
        if (res.data.data.status == KYC_DECLINED) {
          // setVerificationFailed(true);
        }
        await setCheckData(true)
      })
      .catch((error) => {
        setIsKycRes(true);
      });
  };

  const checkMobileNo = (e) => {
    if (e.target.value.toString().length < 6) {
      setPhoneNumberMin(true);
    } else {
      setPhoneNumberMin(false);
    }
    if (e.target.value.toString().length > 15) {
      setPhoneNumberMax(true);
    } else {
      setPhoneNumberMax(false);
    }
  };
  const checkEmailValidity = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const checkEmailExist = () => {
    if (checkEmailValidity(formData?.data?.email)) {
      setCheckEmail(false);
    } else {
      setCheckEmail(true);
    }
  };
  return (
    <>
      <MainCard className="kycCard_Style mainCard_padding">
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
        <Form onSubmit={saveDetail}>
          <Col className="kycDetail_Row">
            <Row>
              <Col xs={12} lg={4}>
                <CustomInput
                defaultValue={
                  formData?.data?.firstname ? formData?.data?.firstname : userProfile?.first_name
                }
                  value={
                    formData?.data?.firstname ? formData?.data?.firstname : userProfile?.first_name
                  }
                  handleChange={handleChange}
                  name="firstname"
                  label="First Name*"
                  className="internalInput"
                  placeholder="First Name"
                >
                  {formData?.data?.firstname &&
                    formData?.data?.firstname.indexOf(" ") == 0 && (
                      <p style={{ marginTop: "10px", color: "red" }}>
                        First name should be vaild
                      </p>
                    )}
                </CustomInput>
              </Col>

              <Col xs={12} lg={4}>
                <CustomInput
                defaultValue={
                  formData?.data?.lastname ? formData?.data?.lastname : userProfile?.last_name
                }
                  value={
                    formData?.data?.lastname ? formData?.data?.lastname : userProfile?.last_name
                  }
                  name="lastname"
                  handleChange={handleChange}
                  label="Last Name*"
                  className="internalInput"
                  placeholder="Last Name"
                >
                  {formData?.data?.lastname &&
                    formData?.data?.lastname.indexOf(" ") == 0 && (
                      <p style={{ marginTop: "10px", color: "red" }}>
                        Last name should be vaild
                      </p>
                    )}
                </CustomInput>
              </Col>
              <Col xs={12} lg={4}>
                <CustomInput
                  disabled={true}
                  value={formData?.data?.email ? formData?.data?.email : userProfile?.email}
                  handleChange={handleChange}
                  checkEmailExist={checkEmailExist}
                  label="Email ID*"
                  name="email"
                  placeholder="Email ID"
                  className="internalInput"
                >
                  {checkEmail && (
                    <p style={{ marginTop: "10px", color: "red" }}>
                      Email is not valid
                    </p>
                  )}
                </CustomInput>
              </Col>
              <Col xs={12} lg={4}>
                <CountryPicker
                  value={
                    formData?.data?.country_code
                      ? formData?.data?.country_code
                      : userProfile?.country
                  }
                  countryName={CountryName}
                  defaultValue={
                    formData?.data?.country_id ? formData?.data?.country_id : userProfile?.country
                  }
                  handleChange={handleChange}
                  label="Country*"
                  placeholder="Select Country"
                  className="internalInput"
                  name="country_id"
                ></CountryPicker>
              </Col>
              <Col xs={12} lg={4}>
             <PhoneInput
                  name="mobileNumber"
                  optionName={`phone_code`}
                  checkMobileNo={checkMobileNo}
                  value={
                    formData?.data?.mobileNumber
                      ? formData?.data?.mobileNumber
                      : userProfile?.mobileNumber
                  }
                  defaultValue={
                    formData?.data?.phone_code != null
                      ? formData?.data?.phone_code
                      : userProfile?.mobileCode
                  }
                  options={options()}
                  handleChange={handleChange}
                  className="internalInput"
                  label="Phone Number*"
                >
                  {phoneNumberMin && (
                    <p style={{ color: "red" }}>Phone no. is not valid.</p>
                  )}
                  {phoneNumberMax && (
                    <p style={{ color: "red" }}>Phone no. is not valid.</p>
                  )}
                  {phoneCodeError && (
                    <p style={{ color: "red" }}>
                      Phone country code is required.
                    </p>
                  )}
                </PhoneInput>
              </Col>
            </Row>
            <Row>
              <Col xs={12} lg={4} className="kycBtn_col">
                <ButtonPrimary
                  buttontext="CANCEL"
                  className="cancel_btn mb-0"
                  onClick={handleClick}
                />
                <ButtonPrimary
                  disabled={phoneNumberMin || phoneNumberMax || checkEmail}
                  buttontext="PROCEED"
                  className="internalComn_btn mb-0"
                  // onClick={saveDetail}
                />
              </Col>
            </Row>
          </Col>
        </Form>
      </MainCard>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    userProfile : state.security.userProfile,
    doc_type: state.security.doc_type,
    doc_front: state.security.doc_front,
    doc_back: state.security.doc_back,
    national_id: state.security.national_id,
    selfie: state.security.selfie,
    kyc_selfie_path: state.security.kyc_selfie_path,
    kyc_doc_path_front: state.security.kyc_doc_path_front,
    kyc_doc_path_back: state.security.kyc_doc_path_back,
    kyc_national_doc_path: state.security.kyc_national_doc_path,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    updateUserKyc: (data) => dispatch(updateUserKyc(data)),
    getUserKycDetails: () => dispatch(getUserKycDetails()),
    clearKycFormData: () => dispatch(clearKycFormData()),
    saveKycFormData: (data) => dispatch(saveKycFormData(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(KycDetail);
