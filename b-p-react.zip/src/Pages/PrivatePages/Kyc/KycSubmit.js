import React,{useState,useEffect} from "react";
import { Row, Col, Card } from "react-bootstrap";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import MainCard from "../../../components/common/MainCard/MainCard";
import "./Kyc.scss";
import {
  getUserKycDetails
} from "../../../redux/actions/SecurityActions";
import {connect} from "react-redux";
import {PASSPORT_FRONT,PASSPORT_BACK,LICENSE_FRONT,LICENSE_BACK} from '../../../constant';

function KycSubmit(props) {
  const [formData, setFormData] = useState([]);


 useEffect(()=>{
  // getCountryCode();
  getUserKycDetails();
  return () => {
 //props.clearKycFormData()
  };
},[]);

const getUserKycDetails = ()=>{
props.getUserKycDetails().then(async(res)=>{
  //  await setKycGetDetails(res.data.data);
  await setFormData({ ...formData, data: res.data.data })
}).catch((error)=>{
  //  setIsKycRes(true);

})
}

let documentType = formData?.data?.documents && formData?.data?.documents.length > 0  ? formData?.data?.documents[0] : '';
  return (
    <>
      <MainCard className="kycCard_Style mainCard_padding">
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
        <Col className="kycDetail_Row">
          <Row>
            <Col xs={12} lg={4}>
              <CustomInput
                label="First Name"
                className="internalInput"
                disabled
                value={formData?.data?.firstname ? formData?.data?.firstname : ''}
              ></CustomInput>
            </Col>

            <Col xs={12} lg={4}>
              <CustomInput
               value={formData?.data?.lastname ? formData?.data?.lastname : ''}
                label="Last Name"
                className="internalInput"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
              value={formData?.data?.email ? formData?.data?.email : ''}
                label="Email ID"
                className="internalInput"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
              value={formData?.data?.country_id ? formData?.data?.country_id : ''}
                label="Country"
                className="internalInput"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                value={formData?.data?.mobile_no ? formData?.data?.mobile_no : ''}
                label="Phone Number"
                className="internalInput"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
              value={documentType?.type == PASSPORT_FRONT || documentType?.type == PASSPORT_BACK ? 'Passport' : 'License'}

                label="Document Type Submitted"
                className="internalInput"
                disabled
              ></CustomInput>
            </Col>
          </Row>
        </Col>
      </MainCard>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    // updateUserKyc: (data) => dispatch(updateUserKyc(data)),
    getUserKycDetails:()=>dispatch(getUserKycDetails()),
    // clearKycFormData: () => dispatch(clearKycFormData()),
    // saveKycFormData: (data) => dispatch(saveKycFormData(data)),
  };
};
export default (connect(
  mapStateToProps,
  mapDispatchToProps
)(KycSubmit));
