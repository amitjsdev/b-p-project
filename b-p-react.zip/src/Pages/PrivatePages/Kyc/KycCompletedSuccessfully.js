import React from "react";
import MainCard from "../../../components/common/MainCard/MainCard";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import "./Kyc.scss";

function KycnotSubmit() {
    let history = useHistory();
    const handleClick = () => {
        history.push("/auth/kycdetail");
    };
    return (
        <>
            <MainCard className="mainCard_padding">
                <Card.Title className="cardTitle_Padding">KYC</Card.Title>
                <Col md={6} sm={12} xs={12} className="mx-auto kycnot_submit">
                    <h3>KYC Completed</h3>
                    <p>
                        Your KYC details have been successfully verified,
                        and we have created your personal virtual INR account!
                    </p>
                </Col>
                {/* <Row>
                    <Col>
                        <p className="kycverify_messageTextStyle">You can now instantly deposit and withdraw INR via IMPS, RTGS, NEFT, UPI, credit and debit cards and wallets</p>
                    </Col>
                </Row> */}
            </MainCard>
        </>
    );
}

export default KycnotSubmit;
