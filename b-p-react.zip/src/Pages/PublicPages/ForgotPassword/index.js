import React, { useState, useEffect } from "react";
import { Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CommonCont from "../../../components/CommonCont/CommonCont";
import { connect } from "react-redux";
import {forgotUserPassword} from "../../../redux/actions/AuthActions";
import "./index.scss";


function ForgotPassword(props) {

    const [checkEmail, setCheckEmail] = useState(false);
    const [formData, setFormData] = useState([]);


    const checkEmailValidity = (email) => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      }
    
      const handleChange = (e, type) => {
        let value = e.target.value;
        let data = {}
        if (formData && formData?.data) {
          data = { ...formData.data }
        }
        data[type] = value;
        setFormData({ ...formData, data })
      }

      const checkEmailExist = () => {
        if (checkEmailValidity(formData?.data?.email)) {
          setCheckEmail(false)
        } else {
          setCheckEmail(true)
        }
    
      }

      const onFormSubmit = e => {
        e.preventDefault()
        props.forgotUserPassword(formData?.data).then((res) => {
            props.history.push(`/login`)
        }).catch((error) => {
        })
    
      }
  return (
    <>
      <CommonCont
        heading="Forgot Your Password?"
        subheading="Enter your Email ID to reset your password"
        className="loginCont_Style"
      >
        <Form onSubmit={onFormSubmit} className="commonForm_style">
          <CustomInput name="email" handleChange={handleChange} placeholder="Email"
            checkEmailExist={checkEmailExist}
          >            {checkEmail && <p style={{ marginTop: '10px', color: 'red' }}>Email has to be valid</p>}
          </CustomInput>
        
          <ButtonPrimary
            style={{ marginTop: '10px' }}
            buttontext="Reset Password" />
        </Form>


        <p>
         <Link to="/login">Back to Sign In</Link>
        </p>
      </CommonCont>
    </>
  );
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    forgotUserPassword: (data) => dispatch(forgotUserPassword(data))

  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);
