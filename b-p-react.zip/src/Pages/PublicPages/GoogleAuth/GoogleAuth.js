import React from "react";
import { Form, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";
import ButtonOutline from "../../../components/common/ButtonOutline/ButtonOutline";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CommonCont from "../../../components/CommonCont/CommonCont";
import QrCode from "../../../theme/images/qr_code.svg";
import AppleIcon from "../../../theme/images/apple_icon.svg";
import PlaystoreIcon from "../../../theme/images/playstore_icon.svg";
import "./GoogleAuth.scss";

function GoogleAuth() {
  return (
    <>
      <CommonCont
        heading="Using the Google Authenticator app, Scan the QR code below"
        className="googleAuth_Style"
      >
        <Row className="googleAuth_Row">
          <Col className="qr_col" md={6} xs={12}>
            <img src={QrCode} />
          </Col>
          <Col className="appstore_col" md={6} xs={12}>
            <p>Don’t have an Authenticator app? </p>
            <ButtonOutline
              icon={AppleIcon}
              store="App Store"
              className="mb-2 mt-5"
            />
            <ButtonOutline icon={PlaystoreIcon} store="Google Play" />
          </Col>
        </Row>
        <ButtonPrimary buttontext="Continue" />
        <Link to="/auth/wallet" className="skipLink">
          Skip Now
        </Link>
      </CommonCont>
    </>
  );
}

export default GoogleAuth;
