import React, { useEffect, useState } from "react";
import { Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CommonCont from "../../../components/CommonCont/CommonCont";
import PassworHide from "../../../theme/images/eye_slash.svg";
import PassworShow from "../../../theme/images/eye_open.svg";
import { saveRegisterData } from "../../../redux/actions/RegisterActions";
import {
  userRegistration,
  getUserIpAddress,
} from "../../../redux/actions/AuthActions";
import ReCAPTCHA from "react-google-recaptcha";
import { CAPTCHA_KEY } from "../../../constant";
import queryString from "query-string";

// import { checkEmailAlreadyExist } from "../../../redux/actions/AuthActions"
import "./SignUp.scss";

function SignUp(props) {
  const parsed = queryString.parse(props.location.search);

  const [checkEmail, setCheckEmail] = useState(false);
  const [showPassConfirm, setShowPassConfirm] = useState(false);
  const [formData, setFormData] = useState([]);
  const [setCaptchaValue, setMyCaptchaValue] = useState("");
  const [ip, setIp] = useState("");
  const [matchPass, setMatchPass] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showPassMin, setShowPassMin] = useState(false);
  const [showPassSpecial, setShowPassSpecial] = useState(false);
  const [showPassUpperCase, setShowPassUpperCase] = useState(false);
  const [showPassLowerCase, setShowPassLowerCase] = useState(false);
  const [showPassNumber, setShowPassNumber] = useState(false);
  const [checkCaptcha, setCheckCaptcha] = useState(false);

  const capthaKey = CAPTCHA_KEY;

  const getUserIpAddress = () => {
    props.getUserIpAddress().then((res) => {
      setIp(res.data.ip);
    });
  };

  const showHide = (e, value) => {
    e.preventDefault();
    if (value === "confirm") {
      setShowPassConfirm(!showPassConfirm);
    } else {
      setShowPass(!showPass);
    }
  };

  const handleChange = (e, type) => {
    let value = e.target.value;

    if (type === "confirmPassword") {
      if (formData?.data?.password) {
        if (formData?.data?.password === value) {
          setMatchPass(false);
          // setShowPass(false)
        } else {
          setMatchPass(true);
          //setShowPass(true)
        }
      }
    }

    if (type === "password") {
      if (formData?.data?.confirmPassword) {
        if (formData?.data?.confirmPassword === value) {
          setMatchPass(false);
          //setShowPass(false)
        } else {
          // setShowPass(false)
          setMatchPass(true);
        }
      }
    }
    let data = {
      capReq: "1",
      registered_by: "3",
      device_token: "",
      hash: "",
      device_type: "3",
      ip: ip,
    };

    if (!formData?.data?.referred_token) {
      data["referred_token"] = parsed?.referral;
    }

    if (formData && formData?.data) {
      data = { ...formData?.data };
    }
    data[type] = value;
    setFormData({ ...formData, data });
  };

  const checkEmailValidity = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const checkEmailExist = () => {
    if (checkEmailValidity(formData?.data?.email)) {
      setCheckEmail(false);
    } else {
      setCheckEmail(true);
    }
  };

  const handleChangeRecaptcha = (value) => {
    setCheckCaptcha(false);
    setMyCaptchaValue(value);
    let data = {};
    if (formData && formData?.data) {
      data = { ...formData?.data };
    }
    data["captchatext"] = value;
    setFormData({ ...formData, data });
  };

  const resetCaptcha = () => {
    window["grecaptcha"].reset();
    setMyCaptchaValue("");
  };

  const onFormSubmit = (e) => {
    e.preventDefault();
    if (setCaptchaValue == "") {
      setCheckCaptcha(true);
      return;
    }
    if (matchPass) {
      return;
    }

    delete formData.data["confirmPassword"];
    delete formData.data["referralId"];

    props.userRegistration(formData.data).then(
      (res) => {
        props.history.push(`/login`);
      },
      (error) => {
        resetCaptcha();
      }
    );
  };

  useEffect(() => {
    getUserIpAddress();
  }, []);

  const checkPassword = (e) => {
    if (!/[A-Z]/.test(e.target.value)) {
      // setShowPass(true)
      setShowPassUpperCase(true);
      setShowPassMin(false);
      setShowPassLowerCase(false);
      setShowPassNumber(false);
      setShowPassSpecial(false);
    } else if (!/[a-z]/.test(e.target.value)) {
      // setShowPass(true)
      setShowPassLowerCase(true);
      setShowPassMin(false);
      setShowPassUpperCase(false);
      setShowPassNumber(false);
      setShowPassSpecial(false);
    } else if (!/[0-9]/.test(e.target.value)) {
      //setShowPass(true)
      setShowPassNumber(true);
      setShowPassMin(false);
      setShowPassUpperCase(false);
      setShowPassLowerCase(false);
      setShowPassSpecial(false);
    } else if (!/[^a-zA-Z0-9]/.test(e.target.value)) {
      // setShowPass(true)
      setShowPassSpecial(true);
      setShowPassNumber(false);
      setShowPassMin(false);
      setShowPassUpperCase(false);
      setShowPassLowerCase(false);
    } else if (
      e.target.value.toString().length < 9 ||
      e.target.value.toString().length > 18
    ) {
      //setShowPass(true)
      setShowPassMin(true);
      setShowPassNumber(false);
      setShowPassUpperCase(false);
      setShowPassLowerCase(false);
      setShowPassSpecial(false);
    } else if (e.target.value === formData?.data?.old_password) {
      // setShowPass(true)
      setShowPassMin(false);
      setShowPassNumber(false);
      setShowPassUpperCase(false);
      setShowPassLowerCase(false);
      setShowPassSpecial(false);
    } else {
      setShowPass(false);
      setShowPassMin(false);
      setShowPassUpperCase(false);
      setShowPassLowerCase(false);
      setShowPassNumber(false);
      setShowPassSpecial(false);
    }
  };
  let errorMsg =
    "Password should have one uppercase, one lowercase, one number, one special character, minimum 9 and maximum 18 characters.";
  return (
    <>
      <CommonCont
        heading="Create BitBubble Account"
        subheading="Register with your email or mobile"
        className="signupCont_Style"
      >
        <Form onSubmit={onFormSubmit} className="commonForm_style">
          <CustomInput
            checkEmailExist={checkEmailExist}
            name="email"
            handleChange={handleChange}
            placeholder="Email*"
          >
            {!!formData?.data?.email && checkEmail && (
              <p style={{ marginTop: "10px", color: "red" }}>
                Email is not valid
              </p>
            )}
          </CustomInput>
          <CustomInput
            checkPassword={checkPassword}
            name="password"
            handleChange={handleChange}
            type={showPass ? `text` : `password`}
            placeholder="Password*"
          >
            <a
              onClick={(e) => {
                showHide(e, "password");
              }}
              className="showPassword"
            >
              {showPass ? <img src={PassworShow} /> : <img src={PassworHide} />}
            </a>
            {!!formData?.data?.password && showPassUpperCase && (
              <p style={{ color: "red", fontSize: "14px" }}>{errorMsg}</p>
            )}
            {!!formData?.data?.password && showPassLowerCase && (
              <p style={{ color: "red", fontSize: "14px" }}>{errorMsg}</p>
            )}
            {!!formData?.data?.password && showPassNumber && (
              <p style={{ color: "red", fontSize: "14px" }}>{errorMsg}</p>
            )}
            {!!formData?.data?.password && showPassSpecial && (
              <p style={{ color: "red", fontSize: "14px" }}>{errorMsg}</p>
            )}
            {!!formData?.data?.password && showPassMin && (
              <p style={{ color: "red", fontSize: "14px" }}>{errorMsg}</p>
            )}
          </CustomInput>
          <CustomInput
            name="confirmPassword"
            handleChange={handleChange}
            type={showPassConfirm ? `text` : `password`}
            placeholder="Confirm Password*"
          >
            <a
              onClick={(e) => {
                showHide(e, "confirm");
              }}
              className="showPassword"
            >
              {showPassConfirm ? (
                <img src={PassworShow} />
              ) : (
                <img src={PassworHide} />
              )}
            </a>
            {formData?.data?.password &&
              formData?.data?.confirmPassword &&
              formData?.data?.password !== formData?.data?.confirmPassword && (
                <p style={{ marginTop: "10px", color: "red" }}>
                  Confirm password doesn't match
                </p>
              )}
          </CustomInput>
          <CustomInput
            value={
              formData.data?.referred_token
                ? formData.data?.referred_token
                : parsed?.referral
            }
            name="referred_token"
            handleChange={handleChange}
            referralId={true}
            placeholder="Referral ID (Optional)"
          />
          <Form.Check type="checkbox" name="checkbox" className="form-check">
            <Form.Check.Input type="checkbox" name="checkbox" required={true} />
            <Form.Check.Label>
              I have read and agree to BitBubble’s
            </Form.Check.Label>
            <Link to="#"> Terms of Service</Link>
          </Form.Check>
          <div className="reCaptcha_div">
            <ReCAPTCHA
              required={true}
              theme="light"
              sitekey={capthaKey}
              onExpired={() => resetCaptcha()}
              onChange={handleChangeRecaptcha}
            />
            {checkCaptcha && (
              <p style={{ marginTop: "10px", color: "red" }}>
                This is required field
              </p>
            )}
          </div>
          <ButtonPrimary
            style={{ marginTop: "10px" }}
            // disabled={matchPass || setCaptchaValue == ""}
            buttontext="Sign Up"
          />
        </Form>
        <p>
          Already registered? <Link to="login">Sign In</Link>
        </p>
      </CommonCont>
    </>
  );
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveRegisterData: (data) => dispatch(saveRegisterData(data)),
    userRegistration: (data) => dispatch(userRegistration(data)),
    getUserIpAddress: () => dispatch(getUserIpAddress()),

    // checkEmailAlreadyExist: (data) => dispatch(checkEmailAlreadyExist(data))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(SignUp);
