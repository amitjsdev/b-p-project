import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useFormik } from "formik";
import { InputGroup, FormControl, Badge, Button, Form } from "react-bootstrap";
import { AUTH_TOKEN_KEY, SMALLESTUNIT } from "../../../constant";
import { getToken } from "../../../Helpers/storageHelper";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import {
  smallestunitFormat,
  digitFormat,
  eightDigit,
  convertExponentialToDecimalTotal,
} from "./Helpers/Normalize";
import { BigNumber } from "bignumber.js";
import * as Yup from "yup";
import ModalBuyConfirmation from "./Components/ModalBuyConfirmation/ModalBuyConfirmation";
import ModalSellConfirmation from "./Components/ModalSellConfirmation/ModalSellConfirmation";

import { toast } from "./Components/Toast/Toast";

const buyLimitSchema = Yup.object().shape({
  buyPrice: Yup.number().required("Price is required").moreThan(0),
  buyAmount: Yup.number().required("Amount is required").moreThan(0),
  buyTotal: Yup.number().required("Amount is required").moreThan(0),
});

const sellLimitSchema = Yup.object().shape({
  sellPrice: Yup.number().required("Price is required").moreThan(0),
  sellAmount: Yup.number().required("Amount is required").moreThan(0),
  sellTotal: Yup.number().required("Amount is required").moreThan(0),
});
function Limit(props) {
 const {getUserBalance} = props;
  const [openConfirmModalBuy, setOpenConfirmModalBuy] = useState(false);
  const [openConfirmModalSell, setOpenConfirmModalSell] = useState(false);

  const [buyFormData, setBuyFormData] = useState({});
  const [sellFormData, setSellFormData] = useState({});
  const params = useParams();

  useEffect(() => {
    // reset buy form value on pair change
    formik.setFieldValue("buyPrice", smallestunitFormat(props.lastPrice));
    formik.setFieldValue("buyAmount", 0);
    formik.setFieldValue("buyTotal", 0);

    // reset sell form value on pair change
    formikSell.setFieldValue("sellPrice", smallestunitFormat(props.lastPrice));
    formikSell.setFieldValue("sellAmount", 0);
    formikSell.setFieldValue("sellTotal", 0);
  }, [params.pair]);

  const formik = useFormik({
    enableReinitialize: true,
    validationSchema: buyLimitSchema,
    initialValues: {
      buyPrice: smallestunitFormat(props.lastPriceSingle),
      buyAmount: "",
      buyTotal: "",
    },

    onSubmit: (values) => {
      let buyAmount = formik.values.buyAmount;
      let buyPrice = formik.values.buyPrice;
      let buyTotal = formik.values.buyTotal;
      let tradebuyfee = props.tradebuyfee / SMALLESTUNIT;

      if (props.pair1 == "zfl" || props.pair2 == "zfl") {
        let percentage = (props.lastPrice * 5) / 100;
        percentage = convertExponentialToDecimalTotal(percentage);
        percentage = eightDigit(percentage);
        let range = props.lastPrice - percentage;
        if (buyPrice < range) {
          range = convertExponentialToDecimalTotal(range);
          range = eightDigit(range);
          toast.error("Please enter price greater or equal to " + range);
          formik.setFieldValue("buyAmount", "");
          formik.setFieldValue("buyTotal", "");
        } else {
          let data = {
            price: buyPrice,
            units: buyAmount,
            total: buyTotal,
            orderType: "BUY",
            tradeType: "LIMIT",
            pairKey: props.pair,
            tradebuyfee: tradebuyfee,
          };
          setBuyFormData(data);
          // open dialog here

          setOpenConfirmModalBuy(true);
        }
      } else {
        let data = {
          price: buyPrice,
          units: buyAmount,
          total: buyTotal,
          orderType: "BUY",
          tradeType: "LIMIT",
          pairKey: props.pair,
          tradebuyfee: tradebuyfee,
        };
        setBuyFormData(data);

        setOpenConfirmModalBuy(true);
      }
    },
  });

  const handleClose = () => {
    setOpenConfirmModalBuy(false);
    setOpenConfirmModalSell(false);
  };

  const formikSell = useFormik({
    enableReinitialize: true,
    validationSchema: sellLimitSchema,

    initialValues: {
      sellPrice: smallestunitFormat(props.lastPriceSingle),
      sellAmount: "",
      sellTotal: "",
    },

    onSubmit: (values) => {
      let sellAmount = formikSell.values.sellAmount;
      let sellPrice = formikSell.values.sellPrice;
      let sellTotal = formikSell.values.sellTotal;

      let tradeSellfee = props.tradesellfee / SMALLESTUNIT;

      if (props.pair1 == "zfl" || props.pair2 == "zfl") {
        let percentage = (props.lastPrice * 5) / 100;
        percentage = convertExponentialToDecimalTotal(percentage);
        percentage = eightDigit(percentage);
        let range = props.lastPrice - percentage;
        if (sellPrice < range) {
          range = convertExponentialToDecimalTotal(range);
          range = eightDigit(range);
          toast.error("Please enter price greater or equal to " + range);
          formikSell.setFieldValue("sellAmount", "");
          formikSell.setFieldValue("sellTotal", "");
        } else {
          let data = {
            price: sellPrice,
            units: sellAmount,
            total: sellTotal,
            orderType: "SELL",
            tradeType: "LIMIT",
            pairKey: props.pair,
            tradeSellfee: tradeSellfee,
          };

          setSellFormData(data);
          // open dialog here

          setOpenConfirmModalSell(true);
        }
      } else {
        let data = {
          price: sellPrice,
          units: sellAmount,
          total: sellTotal,
          orderType: "SELL",
          tradeType: "LIMIT",
          pairKey: props.pair,
          tradeSellfee: tradeSellfee,
        };
        setSellFormData(data);
        setOpenConfirmModalSell(true);
      }
    },
  });

  const calcSell = async () => {
    let sellAmount = formikSell.values.sellAmount;
    let sellPrice = formikSell.values.sellPrice;
    if (sellPrice == "" && sellAmount == "") {
      formikSell.setFieldValue("sellPrice", "");
      formikSell.setFieldValue("sellAmount", "");
      formikSell.setFieldValue("sellTotal", "");
    } else {
      if (String(formikSell.values.sellPrice).indexOf("-") >= 0) {
        formikSell.setFieldValue(
          "sellPrice",
          String(formikSell.values.sellPrice).replace("-", "")
        );
      }
      if (String(formikSell.values.sellPrice).indexOf("+") >= 0) {
        formikSell.setFieldValue(
          "sellPrice",
          String(formikSell.values.sellPrice).replace("+", "")
        );
      }
      if (String(formikSell.values.sellAmount).indexOf("+") >= 0) {
        formikSell.setFieldValue(
          "sellAmount",
          String(formikSell.values.sellAmount).replace("+", "")
        );
      }
      if (String(formikSell.values.sellAmount).indexOf("-") >= 0) {
        formikSell.setFieldValue(
          "sellAmount",
          String(formikSell.values.sellAmount).replace("-", "")
        );
      }

      if (isNaN(formikSell.values.sellPrice)) {
        if (
          formikSell.values.sellPrice == "." ||
          formikSell.values.sellPrice[0] == "."
        ) {
          formikSell.setFieldValue(
            "sellPrice",
            "0" + formikSell.values.sellPrice
          );
        } else {
          formikSell.setFieldValue("sellPrice", "");
        }
        formikSell.setFieldValue("sellTotal", "");
      } else if (isNaN(Number(formikSell.values.sellAmount))) {
        if (
          formikSell.values.sellAmount == "." ||
          formikSell.values.sellAmount[0] == "."
        ) {
          formikSell.setFieldValue(
            "sellAmount",
            "0" + formikSell.values.sellAmount
          );
        } else {
          formikSell.setFieldValue("sellAmount", "");
        }
        formikSell.setFieldValue("sellTotal", "");
      } else if (
        // formikSell.values.sellAmount == "" ||
        formikSell.values.sellPrice == ""
      ) {
        // formikSell.setFieldValue("sellAmount", "");
        formikSell.setFieldValue("sellTotal", "");
      } else if (
        props.pair2 == "zfl" &&
        String(formikSell.values.sellAmount).indexOf(".") != -1
      ) {
        formikSell.setFieldValue("sellAmount", "");
        formikSell.setFieldValue("sellTotal", "");
      } else {
        if (sellPrice != "" && sellAmount != "") {
          let totalPrice = eightDigit(
            new BigNumber(formikSell.values.sellPrice).multipliedBy(
              formikSell.values.sellAmount
            )
          );
          totalPrice = String(totalPrice).replace("+", "");
          totalPrice = String(totalPrice).replace("-", "");

          formikSell.setFieldValue("sellTotal", totalPrice);
          let totalPrices = await convertExponentialToDecimalTotal(totalPrice);

          if (totalPrices == false) {
            formikSell.setFieldValue("sellTotal", "");
          } else {
            formikSell.setFieldValue("sellTotal", totalPrices);
          }
        } else {
          formikSell.setFieldValue("sellTotal", 0);
        }
      }

      if (formikSell.values.sellAmount != 0) {
        if (
          formikSell.values.sellAmount.toString().indexOf(".") == -1 &&
          String(formikSell.values.sellAmount).indexOf("0") === 0
        ) {
          formikSell.setFieldValue(
            "sellAmount",
            formikSell.values.sellAmount.toString().replace(/^(0+)/g, "")
          );
        }
      }
    }
  };

  const calcBuy = async () => {
    let buyAmount = formik.values.buyAmount;

    let buyPrice = formik.values.buyPrice;
    if (buyPrice == "" && buyAmount == "") {
      formik.setFieldValue("buyPrice", "");
      formik.setFieldValue("buyAmount", "");
      formik.setFieldValue("buyTotal", "");
    } else {
      if (String(buyAmount).indexOf("+") >= 0) {
        formik.setFieldValue("buyAmount", String(buyAmount).replace("+", ""));
      }
      if (String(buyAmount).indexOf("-") >= 0) {
        formik.setFieldValue("buyAmount", String(buyAmount).replace("-", ""));
      }
      if (String(buyPrice).indexOf("+") >= 0) {
        formik.setFieldValue("buyPrice", String(buyPrice).replace("+", ""));
      }
      if (String(buyPrice).indexOf("-") >= 0) {
        formik.setFieldValue("buyPrice", String(buyPrice).replace("-", ""));
      }
      // ...
      if (buyPrice == "." || buyPrice[0] == ".") {
        formik.setFieldValue("buyPrice", "0" + buyPrice);
      }

      if (buyAmount == "." || buyAmount[0] == ".") {
        formik.setFieldValue("buyAmount", "0" + buyAmount);
      }

      if (isNaN(buyPrice)) {
        if (buyPrice == "." || buyPrice[0] == ".") {
          formik.setFieldValue("buyPrice", "0" + buyPrice);
        } else {
          formik.setFieldValue("buyPrice", "");
        }
        formik.setFieldValue("buyTotal", "");
      } else if (isNaN(Number(buyAmount))) {
        //new

        if (buyAmount == "." || buyAmount[0] == ".") {
          formik.setFieldValue("buyAmount", "0" + buyAmount);
        } else {
          formik.setFieldValue("buyAmount", "");
        }
        formik.setFieldValue("buyTotal", "");
      } else if (buyPrice == "" || buyPrice <= 0) {
        // formik.setFieldValue("buyAmount", "");
        formik.setFieldValue("buyTotal", "");
      } else if (props.pair2 == "zfl" && String(buyAmount).indexOf(".") != -1) {
        formik.setFieldValue("buyAmount", "");
        formik.setFieldValue("buyTotal", "");
      } else {
        if (buyPrice != "" && buyAmount != "") {
          let totalPrice = eightDigit(
            new BigNumber(buyPrice).multipliedBy(buyAmount)
          );

          totalPrice = String(totalPrice).replace("+", "");
          totalPrice = String(totalPrice).replace("-", "");
          formik.setFieldValue("buyTotal", totalPrice);

          let totalPrices = await convertExponentialToDecimalTotal(totalPrice);

          if (totalPrices == false) {
            formik.setFieldValue("buyTotal", "");
          } else {
            totalPrices = String(totalPrice).replace("+", "");
            totalPrices = String(totalPrice).replace("-", "");
            formik.setFieldValue("buyTotal", totalPrices);
          }
        } else {
          formik.setFieldValue("buyTotal", 0);
        }
      }

      if (buyAmount != 0) {
        if (
          buyAmount.toString().indexOf(".") == -1 &&
          String(buyAmount).indexOf("0") === 0
        ) {
          formik.setFieldValue(
            "buyAmount",
            buyAmount.toString().replace(/^(0+)/g, "")
          );
        }
      }
    }
  };

  const calSellReverse = () => {
    let amount1 = 0;
    let total = 0;

    let sellPrice = formikSell.values.sellPrice;
    let sellTotal = formikSell.values.sellTotal;
    if (String(sellTotal).indexOf("-") >= 0) {
      formikSell.setFieldValue("sellTotal", String(sellTotal).replace("-", ""));
    }
    if (String(sellTotal).indexOf("+") >= 0) {
      formikSell.setFieldValue("sellTotal", String(sellTotal).replace("+", ""));
    }
    if (isNaN(sellPrice) || sellPrice == "") {
      formikSell.setFieldValue("sellPrice", "");
    }

    if (sellTotal == "." || sellTotal[0] == ".") {
      total = 0 + formikSell.values.sellTotal;

      formikSell.setFieldValue("sellTotal", total);
    }

    if (isNaN(sellPrice) || isNaN(total)) {
      formikSell.setFieldValue("sellPrice", "");
      formikSell.setFieldValue("sellAmount", "");
      formikSell.setFieldValue("sellTotal", "");
    } else if (sellTotal == "") {
      formikSell.setFieldValue("sellAmount", "");
      formikSell.setFieldValue("sellTotal", "");
    } else {
      if (sellTotal == "." || sellTotal[0] == ".") {
        formikSell.setFieldValue("sellTotal", "0" + sellTotal);
      }

      amount1 = new BigNumber(sellTotal).dividedBy(sellPrice);

      if (!isFinite(amount1)) {
        amount1 = 0;
      }
      if (formikSell.values.sellPrice > 0) {
        amount1 = sellTotal / sellPrice;

        amount1 = roundDown(amount1, 3);
      }
      if (isNaN(amount1)) {
        formikSell.setFieldValue("sellAmount", 0);
      } else {
        formikSell.setFieldValue(
          "sellAmount",
          amount1.toFixed(props.amount_decimal)
        );
      }
    }
  };

  const calBuyReverse = () => {
    let amount1 = 0;
    let total = 0;
    if (String(formik.values.buyTotal).indexOf("-") >= 0) {
      formik.setFieldValue(
        "buyTotal",
        String(formik.values.buyTotal).replace("-", "")
      );
    }
    if (String(formik.values.buyTotal).indexOf("+") >= 0) {
      formik.setFieldValue(
        "buyTotal",
        String(formik.values.buyTotal).replace("+", "")
      );
    }
    if (isNaN(formik.values.buyPrice) || formik.values.buyPrice == "") {
      formik.setFieldValue("buyPrice", "");
    }

    if (formik.values.buyTotal == "." || formik.values.buyTotal[0] == ".") {
      total = 0 + formik.values.buyTotal;

      formik.setFieldValue("buyTotal", total.toString());
    }

    if (isNaN(formik.values.buyPrice) || isNaN(total)) {
      formik.setFieldValue("buyPrice", "");
      formik.setFieldValue("buyAmount", "");
      formik.setFieldValue("buyTotal", "");
    } else if (formik.values.buyTotal == "") {
      formik.setFieldValue("buyAmount", "");
      formik.setFieldValue("buyTotal", "");
    } else {
      if (formik.values.buyTotal == "." || formik.values.buyTotal[0] == ".") {
        formik.setFieldValue("buyTotal", "0" + formik.values.buyTotal);
      }

      amount1 = new BigNumber(formik.values.buyTotal).dividedBy(
        formik.values.buyPrice
      );

      if (!isFinite(amount1)) {
        amount1 = 0;
      }
      if (formik.values.buyPrice > 0) {
        //infinity check
        amount1 = formik.values.buyTotal / formik.values.buyPrice;

        amount1 = roundDown(amount1, 3);
      }

      if (isNaN(amount1)) {
        formik.setFieldValue("buyAmount", 0);
      } else {
        formik.setFieldValue("buyAmount", amount1);
      }
    }
  };

  const roundDown = (number, decimals) => {
    decimals = decimals || 0;
    return Math.floor(number * Math.pow(10, decimals)) / Math.pow(10, decimals);
  };

  const validate = (e, limit, type) => {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), limit + 1)
        : t;
    if (type == 0) {
      formik.setFieldValue("buyPrice", e.target.value);
    } else {
      formikSell.setFieldValue("sellPrice", e.target.value);
    }
  };

  const validateAmount = (e, limit, type) => {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), limit + 1)
        : t;

    if (type == 0) {
      formik.setFieldValue("buyAmount", e.target.value);
    } else if (type == 1) {
      formikSell.setFieldValue("sellAmount", e.target.value);
    }
  };

  const validateTotal = (e, limit, type) => {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), limit + 1)
        : t;

    if (type == 0) {
      formik.setFieldValue("buyTotal", e.target.value);
    } else if (type == 1) {
      formik.setFieldValue("sellTotal", e.target.value);
    }
  };

  const getAmountPercentBuySell = (percentage, type) => {
    let buyAmount = formik.values.buyAmount;
    let buyPrice = formik.values.buyPrice;
    if (buyPrice == "" || buyPrice == 0) {
      formik.setFieldValue("buyPrice", 0);
      // formik.setFieldValue("buyAmount", 0);
      formik.setFieldValue("buyTotal", 0);
    } else {
      let getPercent = 0;

      let walletbuybalance = props.walletbuybalance;
      let walletsellbalance = props.walletsellbalance;

      if (type == 0) {
        // BUY case

        if (walletbuybalance <= 0) {
          formik.setFieldValue("buyPrice", formik.values.buyPrice);
          formik.setFieldValue("buyAmount", "");
          formik.setFieldValue("buyTotal", 0);
          return false;
        }

        getPercent = (
          (walletbuybalance * Number(percentage)) /
          100 /
          SMALLESTUNIT
        ).toFixed(8);
        // now check if amount have any decimal value
        let price = formik.values.buyPrice;

        if (formik.values.buyPrice == 0) {
          price = props.lastPrice;
        }

        if (price.toString().indexOf(".") != -1) {
          let decimalVal = getPercent / price;
          if (decimalVal.toFixed(8).indexOf(".") != -1) {
            formik.setFieldValue("buyPrice", price);

            let amount = parseFloat(decimalVal - (decimalVal % 1)).toFixed(
              props.amount_decimal
            );
            formik.setFieldValue(
              "buyAmount",
              parseFloat(decimalVal - (decimalVal % 1)).toFixed(
                props.amount_decimal
              )
            );
            formik.setFieldValue(
              "buyTotal",
              ((decimalVal - (decimalVal % 1)) * price).toFixed(8)
            );
          } else {
            formik.setFieldValue(
              "buyAmount",
              roundDown(
                getPercent / formik.values.buyPrice,
                props.amount_decimal
              )
            );
            formik.setFieldValue("buyTotal", getPercent);
          }
        } else {
          if (formik.values.buyPrice !== "" && formik.values.buyPrice != 0) {
            formik.setFieldValue(
              "buyAmount",
              roundDown(
                getPercent / formik.values.buyPrice,
                props.amount_decimal
              )
            );
          }
          formik.setFieldValue("buyTotal", getPercent);
        }
      } else {
        //sell case
        if (walletsellbalance <= 0) {
          formikSell.setFieldValue("sellPrice", formikSell.values.sellPrice);
          formikSell.setFieldValue("sellAmount", "");
          formikSell.setFieldValue("sellTotal", 0);
          return false;
        }

        getPercent = (
          (walletsellbalance * Number(percentage)) /
          100 /
          SMALLESTUNIT
        ).toFixed(8);

        // now check if amount have any decimal value
        let price = formikSell.values.sellPrice;
        if (formikSell.values.sellPrice == 0) {
          price = props.lastPrice;
        }

        if (price.toString().indexOf(".") != -1) {
          let decimalVal = getPercent / price;
          if (decimalVal.toFixed(8).indexOf(".") != -1) {
            formikSell.setFieldValue("sellPrice", price);
            formikSell.setFieldValue(
              "sellAmount",
              roundDown(
                (decimalVal - (decimalVal % 1)) * price,
                props.amount_decimal
              )
            );
            formikSell.setFieldValue(
              "sellTotal",
              ((decimalVal - (decimalVal % 1)) * price * price).toFixed(8)
            );
          } else {
            formikSell.setFieldValue(
              "sellAmount",
              roundDown(
                getPercent / formikSell.values.sellPrice,
                props.amount_decimal
              )
            );
            formikSell.setFieldValue("sellTotal", getPercent);
          }
        } else {
          formikSell.setFieldValue("sellAmount", getPercent);
          formikSell.setFieldValue(
            "sellTotal",
            getPercent * formikSell.values.sellPrice
          );
        }
      }
    }
  };

  return (
    <>
      {/* //BUY FORM HERE */}

      {props.type == "Buy" && (
        <Form onSubmit={formik.handleSubmit} className="limit-form">
          <div>
            {/* <label>Price</label> */}

            <InputGroup>
              <FormControl
                placeholder="Price"
                aria-label="5496.63"
                aria-describedby="basic-addon2"
                className="price-box"
                id="buyPrice"
                onBlur={() => calcBuy()}
                onKeyUp={() => calcBuy()}
                onChange={(event) => {
                  if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                    formik.handleChange(event);
                    validate(event, props.price_decimal, 0);
                  }
                }}
                maxLength={15}
                value={formik.values.buyPrice}
              />

              <InputGroup.Text>
                {/* <img src={usdticon} />  */}
                {props.base}
              </InputGroup.Text>
            </InputGroup>
            {/* <label>Amount</label> */}
            <InputGroup>
              <FormControl
                placeholder="Amount"
                aria-label="Enter Amount"
                aria-describedby="basic-addon2"
                id="buyAmount"
                onBlur={() => calcBuy()}
                onKeyUp={() => calcBuy()}
                onChange={(event) => {
                  if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                    formik.handleChange(event);
                    validateAmount(event, props.amount_decimal, 0);
                  }
                }}
                maxLength={15}
                value={formik.values.buyAmount}
              />

              <InputGroup.Text>
                {/* <img src={ethicon} />  */}
                {props.other}
              </InputGroup.Text>
            </InputGroup>
            <div className="min-trade">
              <p>{smallestunitFormat(props.tradebuyfee)}% fees</p>
            </div>
            {/* <label>Total</label> */}

            <InputGroup>
              <FormControl
                placeholder="Total"
                aria-label="Enter Amount"
                aria-describedby="basic-addon2"
                id="buyTotal"
                onChange={formik.handleChange}
                value={formik.values.buyTotal}
                onKeyUp={() => calBuyReverse()}
                onChange={(event) => {
                  if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                    formik.handleChange(event);
                    validateTotal(event, 8, 0);
                  }
                }}
              />

              <InputGroup.Text>
                {/* <img src={usdticon} />  */}
                {props.base}
              </InputGroup.Text>
            </InputGroup>
            <div className="min-trade">
            <p>Minimum trade : {props?.mintradefee/ 100000000}</p>
            </div>
            {/* <div className="range-box">
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(25, 0)}
            >
              25%
            </Badge>
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(50, 0)}
            >
              50%
            </Badge>
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(75, 0)}
            >
              75%
            </Badge>
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(100, 0)}
            >
              100%
            </Badge>
          </div> */}
            {/* <div className="balance_new">
            {props.isLoggedIn && props.pair1 != "" && props.type == "Buy" && (
              <p>
                Balance:{" "}
                <span>
                  {digitFormat(smallestunitFormat(props.walletbuybalance), 5)}{" "}
                  {props.pair1.toUpperCase()}
                </span>
              </p>
            )}
            {props.isLoggedIn && props.pair2 != "" && props.type == "Sell" && (
              <p>
                Balance:{" "}
                <span>
                  {digitFormat(smallestunitFormat(props.walletsellbalance))}{" "}
                  {props.pair2.toUpperCase()}
                </span>
              </p>
            )}
          </div> */}
          </div>

          {getToken(AUTH_TOKEN_KEY) === null ||
          getToken(AUTH_TOKEN_KEY) == undefined ? (
            <Button className="buy-btn">
              <NavLink to="/" activeClassName="isactive">
                Login
              </NavLink>{" "}
              or{" "}
              <NavLink to="/signup" activeClassName="isactive">
                Register now to trade
              </NavLink>
            </Button>
          ) : (
            <Button className="buy-btn" type="submit">
              Buy {props.other}
            </Button>
          )}

          {/* <div className="min-trade">
            <p>
              Minimum Trade: {smallestunitFormat(props.mintradefee)}{" "}
              {props.pair1.toUpperCase()}{" "}
            </p>
          </div> */}
        </Form>
      )}
      {/* SELL FORM HERE  */}
      {props.type == "Sell" && (
        <Form onSubmit={formikSell.handleSubmit} className="limit-form">
          <div>
          {/* <label>Price</label> */}

          <InputGroup>
            <FormControl
              placeholder="Price"
              aria-label="5496.63"
              aria-describedby="basic-addon2"
              className="price-box"
              id="sellPrice"
              onBlur={() => calcSell()}
              onKeyUp={() => calcSell()}
              onChange={(event) => {
                if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                  formikSell.handleChange(event);
                  validate(event, props.price_decimal, 1);
                }
              }}
              maxLength={15}
              value={formikSell.values.sellPrice}
            />

            <InputGroup.Text>
              {/* <img src={usdticon} /> */}
              {props.base}
            </InputGroup.Text>
          </InputGroup>
          {/* <label>Amount</label> */}
          <InputGroup>
            <FormControl
              placeholder="Amount"
              aria-label="Enter Amount"
              aria-describedby="basic-addon2"
              id="sellAmount"
              // onBlur={()=>calcSell()}
              onKeyUp={() => calcSell()}
              onChange={(event) => {
                if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                  formikSell.handleChange(event);
                  validateAmount(event, props.amount_decimal, 1);
                }
              }}
              maxLength={15}
              value={formikSell.values.sellAmount}
            />

            <InputGroup.Text>
              {/* <img src={ethicon} />  */}
              {props.other}
            </InputGroup.Text>
          </InputGroup>
          <div className="min-trade">
            <p> {smallestunitFormat(props.tradesellfee)}% fees</p>
          </div>

          {/* <label>Total</label> */}

          <InputGroup>
            <FormControl
              placeholder="Total"
              aria-label="Enter Amount"
              aria-describedby="basic-addon2"
              id="sellTotal"
              onChange={formikSell.handleChange}
              value={formikSell.values.sellTotal}
              onKeyUp={() => calSellReverse()}
              onChange={(event) => {
                if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                  formikSell.handleChange(event);
                  validateTotal(event, 8, 1);
                }
              }}
            />

            <InputGroup.Text>
              {/* <img src={usdticon} />  */}
              {props.base}
            </InputGroup.Text>
          </InputGroup>
          <div className="min-trade">
            <p>Minimum trade : {props?.mintradefee/ 100000000}</p>
            </div>
          {/* <div className="range-box">
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(25, 1)}
            >
              25%
            </Badge>
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(50, 1)}
            >
              50%
            </Badge>
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(75, 1)}
            >
              75%
            </Badge>
            <Badge
              variant="secondary"
              style={{ cursor: "pointer" }}
              onClick={() => getAmountPercentBuySell(100, 1)}
            >
              100%
            </Badge>
          </div> */}
          {/* <div className="balance_new">
            {props.isLoggedIn && props.pair1 != "" && props.type == "Buy" && (
              <p>
                Balance:{" "}
                <span>
                  {digitFormat(smallestunitFormat(props.walletbuybalance))}{" "}
                  {props.pair1.toUpperCase()}
                </span>
              </p>
            )}
            {props.isLoggedIn && props.pair2 != "" && props.type == "Sell" && (
              <p>
                Balance:{" "}
                <span>
                  {digitFormat(smallestunitFormat(props.walletsellbalance), 5)}{" "}
                  {props.pair2.toUpperCase()}
                </span>
              </p>
            )}
          </div> */}
          </div>
          {getToken(AUTH_TOKEN_KEY) === null ||
          getToken(AUTH_TOKEN_KEY) == undefined ? (
            <Button className="sell_btn">
              <NavLink to="/" activeClassName="isactive">
                Login
              </NavLink>{" "}
              or{" "}
              <NavLink to="/signup" activeClassName="isactive">
                Register now to trade
              </NavLink>
            </Button>
          ) : (
            <Button className="sell_btn" type="submit">
              Sell {props.other}
            </Button>
          )}

          {/* <div className="min-trade">
            <p>
              Minimum Trade: {smallestunitFormat(props.mintradefee)}{" "}
              {props.pair1.toUpperCase()}{" "}
            </p>
          </div> */}
        </Form>
      )}

      {/* ConfirmationModal Buy  */}
      {props.pair1 && props.pair2 && openConfirmModalBuy && (
        <ModalBuyConfirmation
          getUserBalance={getUserBalance}
          formik={formik}
          tradebuyfee={props.tradebuyfee}
          show={openConfirmModalBuy}
          buyFormData={buyFormData}
          pair1={props.pair1}
          pair2={props.pair2}
          handleClose={handleClose}
          Title="Confirm your limit buy order"
          size="md"
        ></ModalBuyConfirmation>
      )}
      {/* ConfirmationModal  Sell*/}
      {props.pair1 && props.pair2 && openConfirmModalSell && (
        <ModalSellConfirmation
          getUserBalance={getUserBalance}
          formik={formikSell}
          tradeSellfee={props.tradesellfee}
          show={openConfirmModalSell}
          sellFormData={sellFormData}
          pair1={props.pair1}
          pair2={props.pair2}
          handleClose={handleClose}
          Title="Confirm your limit sell order"
          size="md"
        ></ModalSellConfirmation>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    lastPriceSingle: state.exchange.lastPriceSingle,
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    pair2: state.exchange.pair2, //eg USDT

    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList, //pairs list
    tradebuyfee: state.exchange.tradebuyfee,
    tradesellfee: state.exchange.tradesellfee,
    mintradefee: state.exchange.mintradefee,
    walletbuybalance: state.exchange.walletbuybalance,
    walletsellbalance: state.exchange.walletsellbalance,

    amount_decimal: state.exchange.amount_decimal,
    price_decimal: state.exchange.price_decimal,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(Limit);
