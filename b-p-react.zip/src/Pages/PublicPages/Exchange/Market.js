import React, { useState } from "react";
import { useFormik, ErrorMessage } from "formik";
import { InputGroup, FormControl, Form, Button } from "react-bootstrap";
import { AUTH_TOKEN_KEY } from "../../../constant";
import { getToken } from "../../../Helpers/storageHelper";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import { digitFormat, smallestunitFormat } from "./Helpers/Normalize";
import * as Yup from "yup";
import ModalBuyMarket from "./Components/ModalBuyMarket/ModalBuyMarket";
import ModalSellMarket from "./Components/ModalSellMarket/ModalSellMarket";
const marketBuySchema = Yup.object().shape({
  units: Yup.number()
    .required("Amount is required")
    .moreThan(0, "Amount should be greater than 0"),
});
const marketSellSchema = Yup.object().shape({
  units: Yup.number()
    .required("Amount is required")
    .moreThan(0, "Amount should be greater than 0"),
});

function Market(props) {
  const {getUserBalance} = props

  const [openConfirmModalBuy, setOpenConfirmModalBuy] = useState(false);
  const [openConfirmModalSell, setOpenConfirmModalSell] = useState(false);

  const [buyFormData, setBuyFormData] = useState({});
  const [sellFormData, setSellFormData] = useState({});

  const formikBuyMarket = useFormik({
    validationSchema: marketBuySchema,
    enableReinitialize: true,
    initialValues: {
      units: "",
    },

    onSubmit: (values) => {
      // values["tradeType"] = "MARKET";
      // props.setBuySellData(values);
      // formikBuyMarket.resetForm();
      let data = {
        price: 0,
        total: 0,
        units: formikBuyMarket.values.units,
        orderType: "BUY",
        tradeType: "1",
        pairKey: props.pair,
      };

      //open dialog here
      setBuyFormData(data);
      setOpenConfirmModalBuy(true);
    },
  });

  const formikSellMarket = useFormik({
    validationSchema: marketSellSchema,
    enableReinitialize: true,
    initialValues: {
      units: "",
    },

    onSubmit: (values) => {
      // props.setBuySellData(values);
      // formikSellMarket.resetForm();
      let data = {
        price: 0,
        total: 0,
        units: formikSellMarket.values.units,
        orderType: "SELL",
        tradeType: "1",
        pairKey: props.pair,
      };
      setSellFormData(data);
      setOpenConfirmModalSell(true);
    },
  });

  const validateAmount = (e, limit, type) => {
    var t = e.target.value;
    e.target.value =
      t.indexOf(".") >= 0
        ? t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), limit + 1)
        : t;

    if (type == 0) {
      formikBuyMarket.setFieldValue("units", e.target.value);
    } else if (type == 1) {
      formikSellMarket.setFieldValue("units", e.target.value);
    }
  };
  const handleClose = () => {
    setOpenConfirmModalBuy(false);
    setOpenConfirmModalSell(false);
  };

  return (
    <>
      {/* MARKET BUY FORM  */}
      {props.type == "Buy" && (
        <Form onSubmit={formikBuyMarket.handleSubmit} className="limit-form">
          <div>
            {/* <label>Amount</label> */}

            <InputGroup>
              <FormControl
                aria-describedby="basic-addon2"
                className="price-box"
                id="units"
                onChange={(event) => {
                  if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                    formikBuyMarket.handleChange(event);
                    validateAmount(event, props.amount_decimal, 0);
                  }
                }}
                maxLength={15}
                value={formikBuyMarket.values.units}
              />

              <InputGroup.Text>
                {/* <img src={usdticon} /> */}
                {props.other}
              </InputGroup.Text>
            </InputGroup>
            <p style={{ color: "red", fontSize: "10px", margin: "auto" }}>
              {formikBuyMarket.errors.units}
            </p>
            {/* <div className="balance_new">
            {props.isLoggedIn && props.pair1 != "" && props.type == "Buy" && (
              <p>
                Balance:{" "}
                <span>
                  {digitFormat(smallestunitFormat(props.walletbuybalance), 5)}{" "}
                  {props.pair1.toUpperCase()}
                </span>
              </p>
            )}{" "}
          </div> */}
            {props.isLoggedIn && (
              <>
                <div className="min-trade">
                  <p>Fees: {smallestunitFormat(props.tradebuyfee)} %</p>
                </div>
                <div className="min-trade">
                  <p>Minimum trade : {props?.mintradefee / 100000000}</p>
                </div>
                {/* {props.pair1 != "" && (
                <div className="min-trade">
                  <p>
                    Minimum Trade: {smallestunitFormat(props.mintradefee)}{" "}
                    {props.pair1.toUpperCase()}
                  </p>
                </div>
              )} */}
              </>
            )}
          </div>

          {getToken(AUTH_TOKEN_KEY) === null ||
          getToken(AUTH_TOKEN_KEY) == undefined ? (
            <Button className="buy-btn">
              <NavLink to="/" activeClassName="isactive">
                Login
              </NavLink>{" "}
              or{" "}
              <NavLink to="/signup" activeClassName="isactive">
                Register now to trade
              </NavLink>
            </Button>
          ) : (
            <Button className="buy-btn" type="submit">
              Buy {props.other}
            </Button>
          )}
        </Form>
      )}
      {props.type == "Sell" && (
        <Form onSubmit={formikSellMarket.handleSubmit} className="limit-form">
          {/* <label>Amount</label> */}
          <div>
            <InputGroup>
              <FormControl
                aria-describedby="basic-addon2"
                className="price-box"
                id="units"
                onChange={(event) => {
                  if (/^\d*(\.\d{0,8})?$/.test(event.target.value)) {
                    formikSellMarket.handleChange(event);
                    validateAmount(event, props.amount_decimal, 1);
                  }
                }}
                maxLength={15}
                value={formikSellMarket.values.units}
              />

              <InputGroup.Text>
                {/* <img src={usdticon} /> */}
                {props.other}
              </InputGroup.Text>
            </InputGroup>
            <p style={{ color: "red", fontSize: "10px", margin: "auto" }}>
              {formikSellMarket.errors.units}
            </p>

            {/* <div className="balance_new">
            {props.isLoggedIn && props.pair2 != "" && props.type == "Sell" && (
              <p>
                Balance:{" "}
                <span>
                  {digitFormat(smallestunitFormat(props.walletsellbalance), 5)}{" "}
                  {props.pair2.toUpperCase()}
                </span>
              </p>
            )}
          </div> */}
            {props.isLoggedIn && (
              <>
                <div className="min-trade">
                  <p>Fees: {smallestunitFormat(props.tradebuyfee)} %</p>
                </div>
                <div className="min-trade">
                  <p>Minimum trade : {props?.mintradefee / 100000000}</p>
                </div>
                {/* {props.pair1 != "" && (
                <div className="min-trade">
                  <p>
                    Minimum Trade: {smallestunitFormat(props.mintradefee)}{" "}
                    {props.pair1.toUpperCase()}
                  </p>
                </div>
              )} */}
              </>
            )}
          </div>
          {getToken(AUTH_TOKEN_KEY) === null ||
          getToken(AUTH_TOKEN_KEY) == undefined ? (
            <Button className="buy-btn">
              <NavLink to="/" activeClassName="isactive">
                Login
              </NavLink>{" "}
              or{" "}
              <NavLink to="/signup" activeClassName="isactive">
                Register now to trade
              </NavLink>
            </Button>
          ) : (
            <Button className="buy-btn sell_btn" type="submit">
              {props.type} {props.other}
            </Button>
          )}
        </Form>
      )}

      {/* ConfirmationModal Buy  */}
      {props.pair1 && props.pair2 && openConfirmModalBuy && (
        <ModalBuyMarket
          getUserBalance={getUserBalance}
          formik={formikBuyMarket}
          tradebuyfee={props.tradebuyfee}
          show={openConfirmModalBuy}
          buyFormData={buyFormData}
          pair1={props.pair1}
          pair2={props.pair2}
          handleClose={handleClose}
          Title={
            props.pair2.toUpperCase() +
            "/" +
            props.pair1.toUpperCase() +
            " " +
            "Confirm your market buy order"
          }
          size="md"
        ></ModalBuyMarket>
      )}

      {/* ConfirmationModal Sell  */}
      {props.pair1 && props.pair2 && openConfirmModalSell && (
        <ModalSellMarket
        getUserBalance={getUserBalance}
          formik={formikSellMarket}
          tradebuyfee={props.tradebuyfee}
          show={openConfirmModalSell}
          sellFormData={sellFormData}
          pair1={props.pair1}
          pair2={props.pair2}
          handleClose={handleClose}
          Title={
            props.pair2.toUpperCase() +
            "/" +
            props.pair1.toUpperCase() +
            " " +
            "Confirm your market sell order"
          }
          size="md"
        ></ModalSellMarket>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    pair2: state.exchange.pair2, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList, //pairs list
    tradebuyfee: state.exchange.tradebuyfee,
    mintradefee: state.exchange.mintradefee,
    walletbuybalance: state.exchange.walletbuybalance,
    walletsellbalance: state.exchange.walletsellbalance,
    amount_decimal: state.exchange.amount_decimal,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(Market);
