import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import BuySell from "./BuySell";
import HeaderExchange from "./Components/HeaderExchange/HeaderExchange";
import Leftside from "./Leftside";
import Trades from "./Trades";
import History from "./History";
import Order from "./Order";
import Assets from "./Assets";
import DepthChart from "./Depth_Chart";
import Tradebar from "./Components/Tradebar/Tradebar";
import Footer from "../../../components/common/Footer/Footer";
import socket from "../../../socket/index";
import { getToken, removeToken } from "../../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY, SMALLESTUNIT } from "../../../constant";
import { TradingChart } from "./TradingChart";
import {
  saveGraphData,
  saveStatData,
  saveSidePairData,
  saveSellWalletBalance,
  saveBuyWalletBalance,
  getPairList,
  savePairList,
  saveLastPriceSingle,
  saveLastPrice,
  saveTradeOrder,
  tradeOrderList,
  saveBuyOrders,
  saveOpenOrders,
  saveStatVolume,
  saveCompletedOrders,
  saveStatLow,
  saveStatHigh,
  saveStatChange,
  saveStatChangePercentage,
  saveSellOrder,
} from "../../../redux/actions/ExchangeActions";
import * as moment from "moment";
import { convertExponentialToDecimal } from "./Helpers/Normalize";
import { connect } from "react-redux";
import { UserService } from "../../../services/UserService";
import { useDispatch } from "react-redux";
import "./ExchangeStyle.scss";
import CommonCard from "./Components/CommonCard/CommonCard";
import { Container, Row, Col } from "react-bootstrap";
import Sidebar from "../../../components/common/sidebar/Sidebar";
import { getUserBalance } from "../../../redux/actions/WalletActions";
import { toast } from "../../../components/Toast/Toast";


var statPairsArray = [];
var ELEMENT_DATA = [];
var OPENORDER_DATA = [];
var NEWELEMENT_DATA = [];
var completeList = [];
var tradeOrders = [];
var lastvolumestat = [];
var lastHighstat = "";
var lastLowstat = "";
var lastopenstat = "";
var sellOrderSource = [];
var SELLORDER_DATA = [];

var TRADE_DATA = [
  { price: 0, amount: "", date: "", fUser: "", tUser: "", side: "" },
];

var TRADE_DATA_SINGLE = [
  { price: 0, amount: "", date: "", fUser: "", tUser: "", side: "" },
];

var tradeOrderSource = [
  // { price: 0, amount: "", date: "", fUser: "", tUser: "", side: "" },
];
var completeOrder = [];

var dataSource = [];
var sellOrders = [];

var statVolumes = "";
var stat24High = "";
var stat24Low = "";
var statOpen = "";

const Exchange = (props) => {
  // const [propsState, setPropsState] = useState(props)
  const params = useParams();
  const [base, setBase] = useState("");
  const [other, setOther] = useState("");
  const [headerData, setHeaderData] = useState({});
  const [pairlist, setPairlist] = useState([]);

  const [allPairsArray, setallPairsArray] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const [selectedPair, setSelectedPair] = useState("");
  const [marketTab, setMarketTab] = useState("");
  const [socketData, setSocketData] = useState([]);
  // const [socketFilterData, setSocketFilterData] = useState([]);
  const [totalValue, setTotalValue] = useState(0.0);

  const dispatch = useDispatch();

  //REPLACE IT WITH GLOBAL VARIABLE
  // const [TRADE_DATA, setTRADE_DATA] = useState([{ price: 0, amount: "", date: "", fUser: "", tUser: "", side: "" }]);

  useEffect(() => {
    statVolumes = props.statVolume;
    stat24High = props.statHigh;
    stat24Low = props.statLow;
    statOpen = props.statOpen;
  }, [props.statVolume, props.statHigh, props.statLow, props.statOpen]);

  const getUserBalance = () => {
    props
      .getUserBalance('USD')
      .then((res) => {
        let record = res.data.data;
        let resData = [];
        record.forEach((item, i) => {
          let balance = (item?.price * item?.balance) / 100000000;
          resData.push({ price: balance });
        });

        let totalPrice = resData.reduce(function (accumulator, item) {
          return accumulator + item.price;
        }, 0);
        setTotalValue(totalPrice.toFixed(2));
      })
      .catch((error) => {});
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
   // localStorage.setItem("theme","light")
    checkIpToken();
    //socket listner function for stat data
    socket.connect();

    let selectedPair = params.pair;

    setSelectedPair(selectedPair);

    return () => {
      socket.removeAllListeners();
    };
  }, [params.pair]);
  useEffect(() => {
    setDecimalForAmount(pairlist);
  }, [pairlist]);

  const checkIpToken = () => {
    const token = getToken(AUTH_TOKEN_KEY);
    if (!!token) {
      UserService.checkIpToken(token)
        .then((res) => {
          if (res.data.data == false) {
            logout();
          }
        })
        .catch((e) => console.log(e));
    }
  };
  const logout = () => {
    dispatch({
      type: "LOGOUT_USERS_PERSIST",
    });
    localStorage.clear();
    setTimeout(() => {
      removeToken(AUTH_TOKEN_KEY, "", 1);
      props.history.push(`/login`);
    }, 400);
  };

  var isAuthenticated = false;
  var tokens = getToken(AUTH_TOKEN_KEY);
  if (tokens !== null && tokens !== undefined) {
    isAuthenticated = true;
  }

  useEffect(() => {
    //socket listner function for stat data
    if (selectedPair != "") {
      getStatData();
      getPairList();
      setUserLoggedInOrNot();
      return () => {};
    }
    if (isAuthenticated) {
    getUserBalance()
    }
  }, [selectedPair]);

  const setUserLoggedInOrNot = () => {
    // var tokens = getToken(AUTH_TOKEN_KEY);

    if (isAuthenticated) {
      setIsLoggedIn(true);
    }
  };

  useEffect(() => {
    // socket.removeAllListeners();
    setTimeout(() => {
      connectSocketOnPageLoad();
      setCurrency();
    }, 500);

    // getPairList(); // lastPrice issue commented
  }, [params.pair]);

  const connectSocketOnPageLoad = () => {
    localStorage.setItem("lastPriceStatus", "0");

    let selectedPair = params.pair;

    setSelectedPair(selectedPair);

    let pairs = selectedPair.split("_"); // pair (i.e btc_eth)
    props.saveStatData({ prop: "seletedPair", value: selectedPair }); // pair  (i.e usdt_eth)
    props.saveStatData({ prop: "pair1", value: pairs[0] }); // pair 1  (i.e btc)
    props.saveStatData({ prop: "pair2", value: pairs[1] }); // pair 2 (i.e eth)
    if (!marketTab) {
      setMarketTab(pairs[0]);
    }

    socket.emit("currentPair", {
      currency: "USD",
      pair: selectedPair,
      member: getToken(AUTH_TOKEN_KEY),
      accessToken: getToken(AUTH_TOKEN_KEY),
    });

    socket.on("connect", () => {
      // socket connect
      //new code starts
      socket.emit(
        "currentPair",
        {
          currency: "USD",
          pair: selectedPair,
          member: getToken(AUTH_TOKEN_KEY),
          accessToken: getToken(AUTH_TOKEN_KEY),
        },
        (res) => {}
      );
    });
    socket.on("disconnect", () => {});
    //new code end
    var tokens = getToken(AUTH_TOKEN_KEY);

    if (tokens !== null && tokens !== undefined) {
      completeOrderListFromSocket();
      getOpenOrderFromStat();
    }
  };

  const setDecimalForAmount = (data) => {
    let pairs = data;
    let selectedPair = params.pair;
    pairs.forEach((element) => {
      if (element.pair_key == selectedPair) {
        props.saveStatData({
          prop: "amount_decimal",
          value: element.amount_decimal,
        });
        props.saveStatData({
          prop: "price_decimal",
          value: element.price_decimal,
        });
      }
    });
  };

  const getPairList = () => {
    let PAIRELEMENT_DATA = [{ pairs: "", price: 0, change: "", pair_key: "" }];

    props
      .getPairList()
      .then((res) => {
        setDecimalForAmount(res.data.data); // setting decimal value for pairs
        setPairlist(res.data.data);

        let pairsListings = res.data.data;
        if (PAIRELEMENT_DATA.length > 0) {
          PAIRELEMENT_DATA = [];
        }

        pairsListings.forEach((element) => {
          let allArrayPair = [...allPairsArray];
          allArrayPair.push(element.pair_key);
          setallPairsArray(allArrayPair);

          if (element.pair_key == selectedPair) {
            props.saveStatData({
              prop: "mintradefee",
              value: element.minimum_trade,
            });

            // min trade
            props.saveStatData({
              prop: "tradebuyfee",
              value: element.trade_fee_buy,
            });

            // trade buy fee

            props.saveStatData({
              prop: "tradesellfee",
              value: element.trade_fee_sell,
            });

            // trade sell fee

            // props.saveStatData({
            //   prop: "lastPrice",
            //   value: element.last_price,
            // });

            // last price
            props.saveStatData({
              prop: "lastPriceSingle",
              value: element.last_price,
            });

            // last price
          }

          if (element.is_active == 1) {
            let pairCombined = element.pair_name.split("_");
            let data = {
              pairs: element.pair_name,
              price: 0, //for temperary only
              change: element.last_price + "%",
              pair_key: element.pair_key,
              pairsCombined:
                pairCombined[1].toLowerCase() + pairCombined[0].toLowerCase(),
              pairsRevOrder:
                pairCombined[1].toLowerCase() +
                "_" +
                pairCombined[0].toLowerCase(),
            };

            let orginalData = [...PAIRELEMENT_DATA];
            orginalData.push(data);
            PAIRELEMENT_DATA = orginalData;
          }
        });

        let pairdataSource = [];

        for (var i = 0; i < PAIRELEMENT_DATA.length; i++) {
          pairdataSource = [...pairdataSource, PAIRELEMENT_DATA[i]];
        }

        props.savePairList(pairdataSource);
      })
      .catch((error) => {
        PAIRELEMENT_DATA = [];
      });
  };

  // socket for error message
  socket.on("order_response", (data) => {
    if(data.message){
      toast(data.message);

    }

  })

  const getStatData = () => {
    //1st socket

    let currentStat = "stat_" + selectedPair;
    socket.on(currentStat, (statData) => {
      let stat_Data = JSON.parse(statData);
      if (stat_Data != false) {
        if (params.pair == stat_Data.pair) {
          //SAVING 24H Volume in redux
          props.saveStatData({
            prop: "statVolume",
            value: stat_Data["v"] != null ? stat_Data["v"] : 0,
          });
          //SAVING 24H High
          props.saveStatData({
            prop: "statHigh",
            value: stat_Data["h"] != null ? stat_Data["h"] : 0,
          });
          //SAVING 24H Low
          props.saveStatData({
            prop: "statLow",
            value: stat_Data["l"] != null ? stat_Data["l"] : 0,
          });
          //SAVING stat open
          props.saveStatData({
            prop: "statOpen",
            value: stat_Data["o"] != null ? stat_Data["o"] : 0,
          });

          // Calculating percentage change
          let percentage_chage =
            ((stat_Data["l"] - stat_Data["h"]) / stat_Data["l"]) * 100;

          if (!isFinite(percentage_chage)) {
            percentage_chage = 0;
          }
          // SAVING 24H Change
          props.saveStatData({ prop: "statChange", value: percentage_chage });
          //SAVING 24H Change percetage
          props.saveStatData({
            prop: "statChangeprcent",
            value: stat_Data["h"] - stat_Data["l"],
          });
          // SAVING Last Price
          props.saveStatData({ prop: "lastPrice", value: stat_Data["p"] });
        }
      }
    });

    //2nd socket
    //Looks unused data
    socket.on("order_response", (data) => {
      props.saveStatData({ prop: "orderresponse", value: data });
      props.saveStatData({ prop: "orderresponse", value: "" });
    });

    // 3rd socket
    //---------------------ALL PAIRS--------------------------------
    socket.on("allStat", (data) => {
      let stat_Data1 = data.length == 0 ? data : JSON.parse(data);
      if (stat_Data1 != false) {
        let pair = stat_Data1["pair"];
        let percentage_change =
          ((stat_Data1["h"] - stat_Data1["l"]) / stat_Data1["l"]) * 100;
        if (isNaN(percentage_change)) {
          percentage_change = 0;
        }

        statPairsArray[pair] = [];
        statPairsArray[pair]["volume"] =
          stat_Data1["v"] != null ? stat_Data1["v"] : 0;
        statPairsArray[pair]["change"] = percentage_change;

        if (stat_Data1["p"]) {
          statPairsArray[pair]["price"] = stat_Data1["p"];
        } else {
          statPairsArray[pair]["price"] = 0;
        }
        props.saveSidePairData(statPairsArray);
        // props.saveStatData({ prop: "sidePairStat", value: statPairsArray });
      }
    });

    // .....................buyOrders socket................................//

    socket.on("buyOrders", (tradeMsg) => {
      if (ELEMENT_DATA.length > 0) {
        ELEMENT_DATA = [];
      }

      if (tradeMsg.length > 0) {
        let buyOrders = [];
        buyOrders = JSON.parse(tradeMsg);

        buyOrders.forEach((element) => {
          ELEMENT_DATA.push({
            price: element[0],
            amount: element[1],
            total: element[2],
          });
        });

        dataSource = [];
        for (var i = 0; i < ELEMENT_DATA.length; i++) {
          dataSource = [...dataSource, ELEMENT_DATA[i]];
        }

        props.saveBuyOrders(dataSource);
      }
    });

    // .....................sellOrders socket................................//

    socket.on("sellOrders", (tradeMsg) => {
      if (SELLORDER_DATA.length > 0) {
        SELLORDER_DATA = [];
      }
      if (tradeMsg.length > 0) {
        sellOrders = [];
        sellOrders = JSON.parse(tradeMsg);

        sellOrders.forEach((element) => {
          SELLORDER_DATA.push({
            price: element[0],
            amount: element[1],
            total: element[2],
          });
        });

        sellOrderSource = [];
        for (var i = 0; i < SELLORDER_DATA.length; i++) {
          sellOrderSource = [...sellOrderSource, SELLORDER_DATA[i]];
        }
        props.saveSellOrder(sellOrderSource);
      }
    });

    // .....................Order operations  socket................................//

    socket.on("order", (tradeMsg) => {
      let ordertype = tradeMsg[1];
      let action = tradeMsg[0];
      if (ordertype == 0) {
        let index = dataSource.findIndex(
          (elems) => elems.price == tradeMsg[2][0]
        );
        if (index == -1) {
          if (action == "add") {
            ELEMENT_DATA.push({
              price: tradeMsg[2][0],
              amount: tradeMsg[2][1],
              total: tradeMsg[2][2],
            });
            dataSource = [];
            for (var i = 0; i < ELEMENT_DATA.length; i++) {
              dataSource = [...dataSource, ELEMENT_DATA[i]];
            }
          }
        } else {
          if (action == "add") {
            dataSource[index].amount =
              dataSource[index].amount + tradeMsg[2][1];
            dataSource[index].total =
              parseFloat(dataSource[index].total) + parseFloat(tradeMsg[2][2]);
          } else {
            dataSource[index].amount =
              dataSource[index].amount - tradeMsg[2][1];
            dataSource[index].total = dataSource[index].total - tradeMsg[2][2];

            if (dataSource[index].amount <= 0) {
              dataSource.splice(index, 1);
              ELEMENT_DATA.splice(index, 1);

              dataSource = [];
              for (var i = 0; i < ELEMENT_DATA.length; i++) {
                dataSource = [...dataSource, ELEMENT_DATA[i]];
              }
            }
          }
        }

        props.saveBuyOrders(dataSource);

        dataSource = dataSource;
      }

      if (ordertype == 1) {
        let index = sellOrderSource.findIndex(
          (elems) => elems.price == tradeMsg[2][0]
        );

        if (index == -1) {
          if (action == "add") {
            SELLORDER_DATA.push({
              price: tradeMsg[2][0],
              amount: tradeMsg[2][1],
              total: tradeMsg[2][2],
            });

            sellOrderSource = [];
            for (var i = 0; i < SELLORDER_DATA.length; i++) {
              sellOrderSource = [...sellOrderSource, SELLORDER_DATA[i]];
            }
          }
        } else {
          if (action == "add") {
            sellOrderSource[index].amount =
              parseFloat(sellOrderSource[index].amount) +
              parseFloat(tradeMsg[2][1]);
            sellOrderSource[index].total =
              parseFloat(sellOrderSource[index].total) +
              parseFloat(tradeMsg[2][2]);
          } else {
            sellOrderSource[index].amount =
              sellOrderSource[index].amount - tradeMsg[2][1];
            sellOrderSource[index].total =
              sellOrderSource[index].total - tradeMsg[2][2];

            if (sellOrderSource[index].amount <= 0) {
              sellOrderSource.splice(index, 1);

              SELLORDER_DATA.splice(index, 1);

              sellOrderSource = [];

              for (var i = 0; i < SELLORDER_DATA.length; i++) {
                sellOrderSource = [...sellOrderSource, SELLORDER_DATA[i]];
              }
            }
          }
        }

        props.saveSellOrder(sellOrderSource);
        // getOrders();
        // completeOrderList();
      }
    });

    // .....................Wallet deatils  socket................................//

    socket.on("wallet", (tradeMsg) => {
      let selectedPair = params.pair;

      let pairs = selectedPair.split("_");
      if (tradeMsg) {
        tradeMsg.data.forEach((element) => {
          if (tradeMsg.pair == pairs[0]) {
            props.saveBuyWalletBalance(element.balance);
          }

          if (tradeMsg.pair == pairs[1]) {
            props.saveSellWalletBalance(element.balance);
          }
        });
      }
    });

    // ................................. trade list................................//

    socket.on("trades", (tradeMsg) => {
      if (TRADE_DATA.length > 0) {
        TRADE_DATA = [];
      }

      if (tradeMsg.length > 0) {
        tradeOrders = [];
        tradeOrders = JSON.parse(tradeMsg);

        tradeOrders.forEach((element) => {
          TRADE_DATA.push({
            price: element[0],
            amount: element[1],
            date: element[2],
            fUser: element[3],
            tUser: element[4],
            side: element[5],
          });
        });

        tradeOrderSource = [];
        for (var i = 0; i < TRADE_DATA.length; i++) {
          tradeOrderSource = [...tradeOrderSource, TRADE_DATA[i]];
        }
        let lastprice = 0;
        if (tradeOrderSource.length > 0) {
          // In case of emmpty array
          lastprice = tradeOrderSource[0].price;
        }
        let lastpriceExpo = convertExponentialToDecimal(lastprice);
        if (localStorage.getItem("lastPriceStatus") == "0") {
          props.saveLastPriceSingle(lastpriceExpo);
          localStorage.setItem("lastPriceStatus", "1");
        }

        props.saveLastPriceSingle(lastpriceExpo);
        //last price checking
        // props.saveLastPrice(lastpriceExpo);
        props.saveTradeOrder(tradeOrderSource);
      } else {
        props.saveLastPriceSingle(0);
        props.saveLastPrice(0);
      }
    });

    // .................................single trade and open orders ................................//

    socket.on("trade", (tradeMsg) => {
     
      tradeOrders = tradeOrders.reverse();
      const graphBody = {
        close: tradeMsg[0][2] / SMALLESTUNIT,
        high: tradeMsg[0][2] / SMALLESTUNIT,
        low: tradeMsg[0][2] / SMALLESTUNIT,
        time: moment(tradeMsg[0][4]).unix(),
        open: tradeMsg[0][2] / SMALLESTUNIT,
        volume: tradeMsg[0][3] / SMALLESTUNIT,
        selectedPair: selectedPair,
      };
      props.saveGraphData(graphBody);
      // this.commonService.setTrade(graphBody);

      tradeOrders.push([
        Number(tradeMsg[0][2]),
        Number(tradeMsg[0][3]),
        tradeMsg[0][4],
        tradeMsg[0][5],
        tradeMsg[0][6],
        tradeMsg[0][8],
      ]);
      tradeOrders = tradeOrders.reverse();
      lastvolumestat =
        statVolumes +
        (Number(tradeMsg[0][2]) * Number(tradeMsg[0][3])) / SMALLESTUNIT;
      props.saveStatVolume(lastvolumestat);

      TRADE_DATA_SINGLE = [];
      tradeOrders.forEach((element) => {
        TRADE_DATA_SINGLE.push({
          price: element[0],
          amount: element[1],
          date: element[2],
          fUser: element[3],
          tUser: element[4],
          side: element[5],
        });
      });

      tradeOrderSource = [];
      for (var i = 0; i < TRADE_DATA_SINGLE.length; i++) {
        tradeOrderSource = [...tradeOrderSource, TRADE_DATA_SINGLE[i]];
      }
      let lastprice = 0;

      lastprice = tradeMsg[0][2];
      lastprice = convertExponentialToDecimal(lastprice);
      // this.userService.lastPrice(lastprice);

      props.saveLastPrice(lastprice);
      // if(lastprice === 0){
      //   localStorage.setItem('lastprice',lastprice)
      // }
      lastHighstat = stat24High;
      lastLowstat = stat24Low;

      lastopenstat = statOpen;

      if (lastprice > lastHighstat) {
        props.saveStatHigh(lastprice);
      }
      if (lastprice < lastLowstat) {
        props.saveStatLow(lastprice);
      }
      let percentage_chage = ((lastLowstat - lastHighstat) / lastLowstat) * 100;
      if (!isFinite(percentage_chage)) {
        percentage_chage = 0;
      }

      props.saveStatChange(percentage_chage);
      props.saveStatChangePercentage(lastHighstat - lastHighstat);
      props.saveTradeOrder(tradeOrderSource);

      if (tradeMsg[0][7] === null || tradeMsg[0][7] === "sell") {
        let buyIndex = dataSource.findIndex(
          (elems) => elems.price == tradeMsg[0][0]
        );

        if (buyIndex != -1) {
          dataSource[buyIndex].amount =
            dataSource[buyIndex].amount - Number(tradeMsg[0][3]);
          dataSource[buyIndex].total =
            dataSource[buyIndex].total -
            Number(tradeMsg[0][0]) * Number(tradeMsg[0][3]);
          if (dataSource[buyIndex].amount <= 0) {
            dataSource.splice(buyIndex, 1);
            ELEMENT_DATA.splice(buyIndex, 1);
            dataSource = [];
            for (var i = 0; i < ELEMENT_DATA.length; i++) {
              dataSource = [...dataSource, ELEMENT_DATA[i]];
            }
            props.saveBuyOrders(dataSource);
          }

          props.saveBuyOrders(dataSource);
        }
      }
      //sell
      if (tradeMsg[0][7] === null || tradeMsg[0][7] === "buy") {
        let sellIndex = sellOrderSource.findIndex(
          (elems) => elems.price == tradeMsg[0][1]
        );

        if (sellIndex != -1) {
          sellOrderSource[sellIndex].amount =
            sellOrderSource[sellIndex].amount - Number(tradeMsg[0][3]);
          sellOrderSource[sellIndex].total =
            sellOrderSource[sellIndex].total -
            Number(tradeMsg[0][1]) * Number(tradeMsg[0][3]);

          if (sellOrderSource[sellIndex].amount <= 0) {
            sellOrderSource.splice(sellIndex, 1);

            SELLORDER_DATA.splice(sellIndex, 1);

            sellOrderSource = [];
            for (var i = 0; i < SELLORDER_DATA.length; i++) {
              sellOrderSource = [...sellOrderSource, SELLORDER_DATA[i]];
            }

            props.saveSellOrder(sellOrderSource);
          }

          props.saveSellOrder(sellOrderSource);
        }
      }
      // getOrders();
      // completeOrderList();
    });
  };

  /*---------------------runing strip wallets----------------------------------------*/

  socket.on("walletBalances", (data) => {
    if (!!data && data != "undefined" && data.length > 0) {
      const uniqueChars = data.filter((v, i, a) => a.findIndex((t) => t.coin_symbol === v.coin_symbol) === i);
      setSocketData(uniqueChars);
    }
  });
  /*-----------------------end running strip wallets----------------------------------------------*/

  const getOrders = () => {
    let data = {
      status: "OPEN", // in case of all list
      // hours: 24,
      pair: selectedPair,
      // page: 1,
      pagination: 0,
      type: "",
      search: "",
    };
    var openOrder = [];
    props.tradeOrderList(data).then(
      (res) => {
        if (res) {
          if (OPENORDER_DATA.length > 0) {
            OPENORDER_DATA = [];
          }

          let orderlist = [];
          orderlist = res.data.data;

          orderlist.forEach((res) => {
            OPENORDER_DATA.push({
              date: res.created_at,
              type: res.side,
              pair: res.pairKey,
              orderId: res.id,
              amount: res.amount,
              filled: res.filled_amount,
              units: res.pair_key,
              price: res.price,
              executionprice: res.excuted_price,
              status: res.status,
              action: "",
            });
          });

          openOrder = [];
          for (var i = 0; i < OPENORDER_DATA.length; i++) {
            openOrder = [...openOrder, OPENORDER_DATA[i]];
          }
          props.saveOpenOrders(openOrder);
        }
      },
      (error) => {
        OPENORDER_DATA = [];

        props.saveOpenOrders([]);
      }
    );
  };

  const getOpenOrderFromStat = () => {
    socket.on("openOrders", (resData) => {
      OPENORDER_DATA = [];
      let orderSocketData = [];
      orderSocketData = resData.data.data;
      orderSocketData.forEach((res) => {
        OPENORDER_DATA.push({
          date: res.created_at,
          type: res.side,
          pair: res.pairKey,
          orderId: res.id,
          amount: res.amount,
          filled: res.filled_amount,
          units: res.pair_key,
          price: res.price,
          executionprice: res.excuted_price,
          status: res.status,
          action: "", //action
        });
      });
      props.saveOpenOrders(OPENORDER_DATA);
    });
  };

  const setCurrency = () => {
    let currencies = params.pair;
    let result = currencies.split("_");
    if (result.length) {
      setBase(result[0]?.toUpperCase());
      setOther(result[1]?.toUpperCase());
    } else {
      setBase("");
      setOther("");
    }
  };

  const completeOrderListFromSocket = () => {
    socket.on("orderHistory", (resData) => {
      NEWELEMENT_DATA = [];
      completeList = [];
      const orderSocketData = resData.data.data;
      orderSocketData.forEach((res) => {
        NEWELEMENT_DATA.push({
          date: res.created_at,
          type: res.side,
          pair: res.pairKey,
          amount: res.amount,
          filled: res.filled_amount,
          orderId: res.id,
          units: res.pair_key,
          price: res.price,
          executionprice: res.excuted_price,
          status: res.status,
          action: "", //action
        });
      });

      props.saveCompletedOrders(NEWELEMENT_DATA);
    });
  };

  const completeOrderList = () => {
    let data = {
      status: "", // complete order list
      // hours: 24,
      pair: selectedPair,
      // page: 1,
      pagination: 0,
      type: "",
      search: "",
    };
    props.tradeOrderList(data).then(
      (res) => {
        if (res["data"]) {
          if (NEWELEMENT_DATA.length > 0) {
            NEWELEMENT_DATA = [];
          }

          completeList = [];
          completeList = res.data.data;

          completeList.forEach((res) => {
            NEWELEMENT_DATA.push({
              date: res.created_at,
              type: res.side,
              pair: res.pairKey,
              amount: res.amount,
              filled: res.filled_amount,
              orderId: res.id,
              units: res.pair_key,
              price: res.price,
              executionprice: res.excuted_price,
              status: res.status,
              action: "", //action
            });
          });

          completeOrder = [];
          for (var i = 0; i < NEWELEMENT_DATA.length; i++) {
            completeOrder = [...completeOrder, NEWELEMENT_DATA[i]];
          }

          props.saveCompletedOrders(completeOrder);
        } else {
          completeOrder = []; //clear record
        }
      },
      (error) => {
        completeOrder = []; //clear record
        NEWELEMENT_DATA = [];
        props.saveCompletedOrders([]);
      }
    );
  };
  const [classToggle, setClassToggle] = useState(false);

  return (
    <div fluid className="main_box exchange_area">
      <HeaderExchange totalValue={totalValue} socketData={socketData}></HeaderExchange>
      <Container className="mainBox">
        <Sidebar />
        <Row className="exchange-main-sec">
          <Col lg={12} xl={6} xxl={7} className="exchng-left-block">
            <div className="advance-trade">
              <Tradebar
                headerData={headerData}
                pair={params.pair}
                isLoggedIn={isLoggedIn}
                marketTab={marketTab}
                setMarketTab={setMarketTab}
              ></Tradebar>
            </div>
            <div className="combine_graph_pairs">
              {/* <div className="rightSidenav bg_clr ">
                <Leftside
                  pairList={props.pairList}
                  isLoggedIn={isLoggedIn}
                  marketTab={marketTab}
                  setMarketTab={setMarketTab}
                ></Leftside>
              </div> */}
              <div className="graf-sec">
                <CommonCard heading="Trade Chart">
                  <div className="TradeChartInner">
                    {Object.keys(props.markets).length > 0 &&
                      props.pair1 != "" &&
                      props.pair1 != undefined &&
                      props.pair2 != "" &&
                      props.pair2 != undefined &&
                      props.pair2 + props.pair1 && (
                        <TradingChart></TradingChart>
                      )}
                  </div>
                </CommonCard>
              </div>
            </div>
            <div className="depthChartDiv">
              <CommonCard heading="Depth Chart">
                <div className="depthChartInner">
                  <DepthChart />
                </div>
              </CommonCard>
            </div>
          </Col>
          <Col lg={12} xl={6} xxl={5} className="exchng-rgt-block">
            <div className="orderWrap_div">
              <div className="orderbook">
                <div className="order_bar exchange-table">
                  <CommonCard heading="Order Book">
                    <Order isLoggedIn={isLoggedIn}></Order>
                  </CommonCard>
                </div>
                {/* <div className="trades_area bg_clr">
                  {props.pair1 !== "" && props.pair2 != "" && (
                    <Trades isLoggedIn={isLoggedIn}></Trades>
                  )}
                </div> */}
              </div>

              <div className="buysell_bar">
                <div className="buysellmain">
                  <BuySell
                    getUserBalance={getUserBalance}
                    isLoggedIn={isLoggedIn}
                    base={base}
                    other={other}
                    pair={selectedPair}
                  ></BuySell>
                </div>
                {/* {props.pair1 !== "" && props.pair2 != "" && (
                <div className="ex-assets bg_clr">
                  <Assets isLoggedIn={isLoggedIn}></Assets>
                </div>
              )} */}
              </div>
            </div>
            <div className="orders-sec bg_clr">
              <History isLoggedIn={isLoggedIn}></History>
            </div>
          </Col>
        </Row>
      </Container>
      <Footer />
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList, //pairs list
    sidePairStat: state.exchange.sidePairStat,
    pair2: state.exchange.pair2,
    kline: state.exchange.graphData,
    markets: state.exchange.pairList,
    currentMarket: state.exchange.seletedPair,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveStatData: (data) => dispatch(saveStatData(data)),
    getPairList: () => dispatch(getPairList()),
    savePairList: (data) => dispatch(savePairList(data)),
    saveLastPriceSingle: (data) => dispatch(saveLastPriceSingle(data)),
    saveLastPrice: (data) => dispatch(saveLastPrice(data)),
    saveTradeOrder: (data) => dispatch(saveTradeOrder(data)),
    saveSidePairData: (data) => dispatch(saveSidePairData(data)),
    saveBuyWalletBalance: (data) => dispatch(saveBuyWalletBalance(data)),
    saveSellWalletBalance: (data) => dispatch(saveSellWalletBalance(data)),
    saveBuyOrders: (data) => dispatch(saveBuyOrders(data)),
    saveOpenOrders: (data) => dispatch(saveOpenOrders(data)),
    tradeOrderList: (data) => dispatch(tradeOrderList(data)),
    saveCompletedOrders: (data) => dispatch(saveCompletedOrders(data)),
    saveStatVolume: (data) => dispatch(saveStatVolume(data)),
    saveStatHigh: (data) => dispatch(saveStatHigh(data)),
    saveStatLow: (data) => dispatch(saveStatLow(data)),
    saveStatChange: (data) => dispatch(saveStatChange(data)),
    saveStatChangePercentage: (data) =>
      dispatch(saveStatChangePercentage(data)),
    saveSellOrder: (data) => dispatch(saveSellOrder(data)),
    saveGraphData: (data) => dispatch(saveGraphData(data)),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),

  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Exchange);
