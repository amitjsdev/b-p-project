import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { useParams } from "react-router-dom";

import { DEPTH_GRAPH_URL } from "../../../constant";

const DepthChart = (props) => {
  const params = useParams();

  const [depthSrc, setDepthSrc] = useState("");
  useEffect(() => {
    let selectedPair = params.pair;
    var depthsrc = `${DEPTH_GRAPH_URL}graph/depth.php?pair_id=${selectedPair}&theme=Dark`;
    setDepthSrc(depthsrc);
  }, [params.pair]);

  return (
    <iframe src={depthSrc} width="100%" height="100%" type="text/html" type="text/html" />
  );
};
const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(DepthChart);