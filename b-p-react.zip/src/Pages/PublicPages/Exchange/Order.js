import React, { useEffect, useState } from "react";
import { Tabs, Tab } from "react-bootstrap";
import arrow from "../../../assets/images/arrow.svg";
import arrowDown from "../../../assets/images/down_arrow.png";
import { connect } from "react-redux";
import { totallimit } from "../../../constant";
import {
  spliceZeroValue,
  smallestunitFormat,
  digitFormat,
  convertExponentialToDecimal,
  minifyDecimal,
} from "./Helpers/Normalize";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";

var dataSourceTemp = [];
var dataSource = [];
var sellOrderSourceTemp = [];
var sellOrderSource = [];

const Order = (props) => {
  const [buy, setBuy] = useState(true);
  const [increase, setIncrease] = useState(true);
  const [sell, setSell] = useState(true);
  const [active1, setActive1] = useState("active");
  const [active2, setActive2] = useState("");
  const [active3, setActive3] = useState("");
  const [buyDataSource, setbuyDataSource] = useState([""]);
  const [sellDataSource, setsellDataSource] = useState([""]);
  const [lastPrice, setlastPrice] = useState("");
  const [lastPpriceTemp, setLastPpriceTemp] = useState("");

  useEffect(async () => {
    let lp = convertExponentialToDecimal(props.lastPrice);
    setlastPrice(lp);

    if (lp > lastPpriceTemp) {
      setIncrease(true);
    } else {
      setIncrease(false);
    }
    setLastPpriceTemp(lp);
    if (lp == null || !lp) {
      setlastPrice(0);
    }
  }, [props.lastPrice]);

  useEffect(async () => {
    let buyOrder = [];
    buyOrder = await spliceZeroValue(props.buyOrder);
    buyOrder.sort((a, b) => b.price - a.price); //descending
    dataSource = buyOrder.slice(0, 17); //cut first tab records to 10
    dataSourceTemp = buyOrder;
    let buyTempArray = dataSourceTemp.slice(0, 24);
    dataSourceTemp = buyTempArray;
    if (active1 == "active") {
      setbuyDataSource(dataSource);
    } else {
      setbuyDataSource(buyTempArray);
    }
  }, [props.buyOrder]);

  useEffect(async () => {
    let sellOrder = [];
    sellOrder = await spliceZeroValue(props.sellOrder);
    sellOrder.sort((a, b) => a.price - b.price); //ascending
    sellOrderSource = sellOrder.slice(0, 15);
    sellOrderSourceTemp = sellOrder;
    sellOrderSource.reverse();
    let sellTempArray = sellOrderSourceTemp.slice(0, 50);
    sellOrderSourceTemp = sellTempArray.reverse();

    if (active1 == "active") {
      setsellDataSource(sellOrderSource);
    } else {
      setsellDataSource(sellTempArray);
    }
  }, [props.sellOrder]);

  const changeGroup = (value) => {
    if (value == 1) {
      setBuy(true);
      setSell(true);
      setActive1("active");
      setActive2("");
      setActive3("");
      setbuyDataSource(spliceZeroValue(dataSource));
      setsellDataSource(spliceZeroValue(sellOrderSource));
    } else if (value == 2) {
      setBuy(true);
      setSell(false);
      setActive1("");
      setActive2("active");
      setActive3("");
      setbuyDataSource(dataSourceTemp);
    } else if (value == 3) {
      setBuy(false);
      setSell(true);
      setActive1("");
      setActive2("");
      setActive3("active");
      setsellDataSource(sellOrderSourceTemp);
    }
  };
  return (
    <Tabs
      defaultActiveKey="1"
      id="uncontrolled-tab-example "
      className="buysell-tab"
      onSelect={(e) => changeGroup(e)}
    >
      <Tab eventKey="1" title="" className="bothOrder">
        <div className="table-responsive  buysell-table">
          <div className="bidorder-tbl bid_order_OverflowHdn">
            <div className="hdr-row">
              <span>
                <label>
                  Price-
                  <span>
                    {props.pair1 != "" && props.pair1 != undefined
                      ? props.pair1.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
              <span className="align-right">
                <label>
                  Amount-
                  <span>
                    {props.pair2 != "" && props.pair2 != undefined
                      ? props.pair2.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
              <span className="mb-hide">
                <label>
                  Total-
                  <span>
                    {props.pair1 != "" && props.pair1 != undefined
                      ? props.pair1.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
            </div>
     
              <div className="bid-body">
              <PerfectScrollbar
              options={{ onScrollX: true, suppressScrollX: true }}

              // onScrollX={(container) =>
              //   console.log(`scrolled to: ${container.scrollTop}.`)
              // }
            >
                {sellDataSource.map((data, index) => (
                  <div key={index} className="progress-container">
                    <div className="row-content">
                      <div className="data_row">
                        <span>{smallestunitFormat(data.price)}</span>
                        <span className="mid_text">
                          {smallestunitFormat(data.amount)}
                        </span>
                        <span className="mb-hide">
                          {data.total
                            ? minifyDecimal(
                                smallestunitFormat(
                                  digitFormat(data.total),
                                  "",
                                  totallimit
                                ),
                                8
                              )
                            : 0}
                        </span>
                      </div>
                      <div
                        className="progress-bar bid-bar"
                        style={{ transform: "translateX(-50%)", left: "100%" }}
                      ></div>
                    </div>
                  </div>
                ))}
                {sellDataSource.length == 0 && (
                  <div className="progress-container">
                    <div className="row-content">
                      <p className="no_order">No sell orders</p>
                    </div>
                  </div>
                )}
                 </PerfectScrollbar>
              </div>
           
          </div>
          <div className="order-value-table bid_order_OverflowHdn">
          {!!lastPrice && lastPrice !== 0 ? 

            <span className="positive currentStatus">
              {lastPrice ? smallestunitFormat(lastPrice) : 0}
              {increase && <img src={arrow} />}
              {!increase && <img src={arrowDown} />}
            </span>
            :
            <span className="positive currentStatus">
            </span>
              }
            {/* <span className="currentValue">${lastPrice ? smallestunitFormat(lastPrice) : 0}</span> */}
            {/* <span> $2502.96</span> */}
          </div>
          <div className="bidorder-tbl bid_order_OverflowHdn">
        
              <div className="bid-body">
              <PerfectScrollbar
              options={{ onScrollX: true, suppressScrollX: true }}

              // onScrollX={(container) =>
              //   console.log(`scrolled to: ${container.scrollTop}.`)
              // }
            >
                {buyDataSource.map((data, index) => (
                  <div key={index} className="progress-container">
                    <div className="row-content">
                      <div className="data_row">
                        <span>{smallestunitFormat(data.price)}</span>
                        <span className="mid_text">
                          {smallestunitFormat(data.amount)}
                        </span>
                        <span className="mb-hide">
                          {data.total
                            ? minifyDecimal(
                                smallestunitFormat(
                                  digitFormat(data.total),
                                  "",
                                  totallimit
                                ),
                                8
                              )
                            : 0}
                        </span>
                      </div>
                      <div
                        className="progress-bar bid-bar"
                        style={{ transform: "translateX(-50%)", left: "100%" }}
                      ></div>
                    </div>
                  </div>
                ))}
                {buyDataSource.length == 0 && (
                  <div className="progress-container">
                    <div className="row-content">
                      <p className="no_order">No buy orders</p>
                    </div>
                  </div>
                )}
            </PerfectScrollbar>

              </div>
          </div>
        </div>
      </Tab>
      <Tab eventKey="2" title="" className="forBuy_Odr">
        <div className="table-responsive  buysell-table">
          <div className="bidorder-tbl bid_order_OverflowHdn">
          <div className="hdr-row">
              <span>
                <label>
                  Price-
                  <span>
                    {props.pair1 != "" && props.pair1 != undefined
                      ? props.pair1.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
              <span className="align-right">
                <label>
                  Amount-
                  <span>
                    {props.pair2 != "" && props.pair2 != undefined
                      ? props.pair2.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
              <span className="mb-hide">
                <label>
                  Total-
                  <span>
                    {props.pair1 != "" && props.pair1 != undefined
                      ? props.pair1.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
            </div>
       
              <div className="bid-body">
              <PerfectScrollbar
              options={{ onScrollX: true, suppressScrollX: true }}

              // onScrollX={(container) =>
              //   console.log(`scrolled to: ${container.scrollTop}.`)
              // }
            >
                {buyDataSource.map((data, index) => (
                  <div key={index} className="progress-container">
                    <div className="data_row">
                      <span>
                        {data.total
                          ? minifyDecimal(
                              smallestunitFormat(
                                digitFormat(data.total),
                                "",
                                totallimit
                              ),
                              8
                            )
                          : 0}
                      </span>
                      <span className="mid_text">
                        {smallestunitFormat(data.amount)}
                      </span>
                      <span className="mb-hide">
                        {smallestunitFormat(data.price)}{" "}
                      </span>
                    </div>
                    <div
                      className="progress-bar ask-bar-"
                      style={{ transform: "translateX(-50%)", left: "100%" }}
                    ></div>
                  </div>
                ))}
                {buyDataSource.length == 0 && (
                  <div className="progress-container">
                    <div className="row-content">
                      <p className="no_order">No buy orders</p>
                    </div>
                  </div>
                )}
            </PerfectScrollbar>

              </div>
          </div>
        </div>
      </Tab>
      <Tab eventKey="3" title="" className="forSell_Odr">
        <div className="table-responsive  buysell-table">
          <div className="bidorder-tbl bid_order_OverflowHdn">
            <div className="hdr-row">
              <span>
                <label>
                  Price-{" "}
                  <span>
                    {props.pair1 != "" && props.pair1 != undefined
                      ? props.pair1.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
              <span className="align-right">
                <label>
                  Amount-{" "}
                  <span>
                    {props.pair2 != "" && props.pair2 != undefined
                      ? props.pair2.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
              <span className="mb-hide">
                <label>
                  Total-{" "}
                  <span>
                    {props.pair1 != "" && props.pair1 != undefined
                      ? props.pair1.toUpperCase()
                      : ""}
                  </span>
                </label>
              </span>
            </div>
         
              <div className="bid-body">
              <PerfectScrollbar
              options={{ onScrollX: true, suppressScrollX: true }}

              // onScrollX={(container) =>
              //   console.log(`scrolled to: ${container.scrollTop}.`)
              // }
            >
                {sellDataSource.map((data, index) => (
                  <div key={index} className="progress-container">
                    <div className="row-content">
                      <div className="data_row">
                        <span>{smallestunitFormat(data.price)}</span>
                        <span className="mid_text">
                          {smallestunitFormat(data.amount)}
                        </span>
                        <span className="mb-hide">
                          {data.total
                            ? minifyDecimal(
                                smallestunitFormat(
                                  digitFormat(data.total),
                                  "",
                                  totallimit
                                ),
                                8
                              )
                            : 0}
                        </span>
                      </div>
                      <div
                        className="progress-bar bid-bar-"
                        style={{ transform: "translateX(-50%)", left: "100%" }}
                      ></div>
                    </div>
                  </div>
                ))}
                {sellDataSource.length == 0 && (
                  <div className="progress-container">
                    <div className="row-content">
                      <p className="no_order">No sell orders</p>
                    </div>
                  </div>
                )}
            </PerfectScrollbar>

              </div>
          </div>
        </div>
      </Tab>
    </Tabs>
  );
};

const mapStateToProps = (state) => {
  return {
    buyOrder: state.exchange.buyOrder,
    sellOrder: state.exchange.sellOrder,
    pair1: state.exchange.pair1,
    pair2: state.exchange.pair2,
    lastPrice: state.exchange.lastPrice,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(Order);
