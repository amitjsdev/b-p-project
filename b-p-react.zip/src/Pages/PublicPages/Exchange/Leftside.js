import React, { useEffect, useState } from "react";
import { Tabs, Tab, Form, Table } from "react-bootstrap";
import ChangeVolumeTab from "./Components/LeftSideTab/ChangeVolumeTab";
import { pairSwap, smallestunitFormat } from "./Helpers/Normalize";
import { connect } from "react-redux";
import { useParams } from "react-router-dom";
import { useHistory } from "react-router-dom";
import socket from "../../../socket/index";
import {
  saveBuyOrders,
  saveSellOrder,
} from "../../../redux/actions/ExchangeActions";
import SearchImg from "../../../theme/images/search.svg";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";

function Leftside(props) {
  const history = useHistory();
  const params = useParams();

  const [pairListTemp, setPairListTemp] = useState(props.pairList);
  const [dataSourceUSDT, setDataSourceUSDT] = useState([]);
  const [dataSourceBTC, setDataSourceBTC] = useState([]);
  const [dataSourceALL, setDataSourceALL] = useState([]);

  const [dataSourceSearch, setDataSourceSearch] = useState([]);
  const [searchText, setSearchText] = useState("");

  const [type, setType] = useState("Change");
  const [searchOn, setSearchOn] = useState(false);
  const [selectedPair, setSelectedPair] = useState("");

  useEffect(() => {
    setSelectedPair(params.pair);
  }, [props.sidePairStat]);

  useEffect(() => {}, [dataSourceSearch]);

  useEffect(async () => {
    setPairListTemp(props.pairList);
    setDataSourceUSDT([]);
    let pairRawArray = [];
    let pairRawArrayBtc = [];
    let pairRawArrayAll = props.pairList;

    for (let element of props.pairList) {
      let pairArray = element["pair_key"].split("_");
      if (pairArray[0] == "usdt") {
        pairRawArray.push(element);
      }
      if (pairArray[0] == "btc") {
        pairRawArrayBtc.push(element);
      }
    }

    //order pair list usdt
    let pairArray = pairRawArray.map(function (data, idx) {
      return { idx: idx, data: data };
    });
    //order pair list btc
    let pairArrayBtc = pairRawArrayBtc.map(function (data, idx) {
      return { idx: idx, data: data };
    });
    //ALL order pair
    let pairArrayAll = pairRawArrayAll.map(function (data, idx) {
      return { idx: idx, data: data };
    });

    pairArray.sort(function (a, b) {
      if (a.data.pairs.split("_")[1] < b.data.pairs.split("_")[1]) return -1;
      if (a.data.pairs.split("_")[1] > b.data.pairs.split("_")[1]) return 1;
      return a.idx - b.idx;
    });
    let datasSourceUSDT = await pairArray.map(function (val) {
      return val.data;
    });
    setDataSourceUSDT(datasSourceUSDT);
    // btc pairs
    pairArrayBtc.sort(function (a, b) {
      if (a.data.pairs.split("_")[1] < b.data.pairs.split("_")[1]) return -1;
      if (a.data.pairs.split("_")[1] > b.data.pairs.split("_")[1]) return 1;
      return a.idx - b.idx;
    });
    let datasSourceBTC = await pairArrayBtc.map(function (val) {
      return val.data;
    });
    setDataSourceBTC(datasSourceBTC);
    //all pairs
    pairArrayAll.sort(function (a, b) {
      if (a.data.pairs.split("_")[1] < b.data.pairs.split("_")[1]) return -1;
      if (a.data.pairs.split("_")[1] > b.data.pairs.split("_")[1]) return 1;
      return a.idx - b.idx;
    });
    let datasSourceAll = await pairArrayAll.map(function (val) {
      return val.data;
    });
    setDataSourceALL(datasSourceAll);
  }, [props.pairList]);

  const setChangeVolume = (value) => {
    setType(value);
  };
  const filterItems = (query, tab) => {
    return pairListTemp.filter((el) => {
      if (el.pairs.toLowerCase().indexOf(query.word.toLowerCase()) > -1) {
        return true;
      } else {
        return false;
      }
    });
  };
  const search = (value, tab) => {
    setSearchText(value);

    if (value != "") {
      setSearchOn(true);
      // setMarketTab(tab);
      let dataSource = filterItems(Object.assign(search, { word: value }), tab);
      setDataSourceSearch(dataSource);
    } else {
      setSearchOn(false);
      // setMarketTab(tab);
      setDataSourceSearch([]);
    }
  };
  const disconnect = (pair) => {
    if (params.pair != pair) {
      socket.removeAllListeners();
      props.saveBuyOrders([]);
      props.saveSellOrder([]);
      history.push(`/my-exchange/${pair}`);
    }
  };

  const setMarketTab = (tab) => {
    props.setMarketTab(tab);
  };

  return (
    <div className="exchange_pair">
      {!!props.marketTab && (
        <Tabs
          // defaultActiveKey={marketTab}
          activeKey={props.marketTab}
          id="uncontrolled-tab-example"
          className="curr-tab left-tab"
          onSelect={(k) => {
            // localStorage.setItem("marketTab", k);
            setMarketTab(k);
          }}
        >
          <Tab eventKey="all" title="ALL">
            <div className="inside_tab">
              <div className="search">
                <Form.Control
                  type="text"
                  placeholder="Search"
                  value={searchText}
                  onChange={(e) => search(e.target.value, "all")}
                />
                <img src={SearchImg} className="searchImg" />
              </div>
              {/* <ChangeVolumeTab
                setChangeVolume={setChangeVolume}
              ></ChangeVolumeTab> */}
            </div>
            <div className="table-responsive change_table">
              <PerfectScrollbar
                options={{ onScrollX: true, suppressScrollX: true }}

                // onScrollX={(container) =>
                //   console.log(`scrolled to: ${container.scrollTop}.`)
                // }
              >
                <Table>
                  <thead>
                    <tr>
                      <th>Pairs</th>
                      <th>Price</th>
                      <th className="align_right">{type}</th>
                    </tr>
                  </thead>
                  {props.marketTab == "all" && !searchOn && (
                    <tbody>
                      {dataSourceALL.map((element, index) => (
                        <tr
                          key={index}
                          style={{ cursor: "pointer" }}
                          onClick={() =>
                            history.push(`/my-exchange/${element.pair_key}`)
                          }
                        >
                          <td>
                            {" "}
                            <i className="fa fa-star-o"></i>{" "}
                            {pairSwap(element.pairs)}
                          </td>

                          <td>
                            {props.sidePairStat[element.pair_key]?.price
                              ? smallestunitFormat(
                                  props.sidePairStat[element.pair_key]?.price
                                )
                              : 0}
                          </td>

                          {type === "Change" && (
                            <td className="green-text align_right">
                              {props.sidePairStat[element.pair_key]?.change &&
                              props.sidePairStat[element.pair_key]?.change !=
                                "Infinity"
                                ? (props.sidePairStat[
                                    element.pair_key
                                  ]?.change).toFixed(2) + "%"
                                : "0%"}
                            </td>
                          )}

                          {type != "Change" && (
                            <td className="green-text align_right">
                              {props.sidePairStat[element.pair_key]?.volume
                                ? smallestunitFormat(
                                    props.sidePairStat[element.pair_key]?.volume
                                  ).toFixed(2)
                                : 0}
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  )}

                  {searchOn && props.marketTab == "all" && (
                    <tbody>
                      {dataSourceSearch.map((element, index) => (
                        <tr key={index} style={{ cursor: "pointer" }}>
                          <td
                            onClick={() =>
                              history.push(`/my-exchange/${element.pair_key}`)
                            }
                          >
                            {" "}
                            <i className="fa fa-star-o"></i>{" "}
                            {pairSwap(element.pairs)}
                          </td>

                          <td>
                            {props.sidePairStat[element.pair_key]?.price
                              ? smallestunitFormat(
                                  props.sidePairStat[element.pair_key]?.price
                                )
                              : 0}
                          </td>

                          {type === "Change" && (
                            <td className="green-text">
                              {props.sidePairStat[element.pair_key]?.change &&
                              props.sidePairStat[element.pair_key]?.change !=
                                "Infinity"
                                ? props.sidePairStat[element.pair_key]?.change +
                                  "%"
                                : "0%"}
                            </td>
                          )}

                          {type != "Change" && (
                            <td className="green-text">
                              {props.sidePairStat[element.pair_key]?.volume
                                ? smallestunitFormat(
                                    props.sidePairStat[element.pair_key]?.volume
                                  )
                                : 0}
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  )}
                </Table>
              </PerfectScrollbar>
            </div>
          </Tab>
          {/* //btc pairs */}
          <Tab eventKey="btc" title="BTC">
            <div className="inside_tab">
              <div className="search">
                <Form.Control
                  type="text"
                  placeholder="Search"
                  value={searchText}
                  onChange={(e) => search(e.target.value, "btc")}
                />
                <img src={SearchImg} className="searchImg" />
              </div>
              {/* <ChangeVolumeTab
                setChangeVolume={setChangeVolume}
              ></ChangeVolumeTab> */}
            </div>
            <div className="table-responsive change_table">
              <PerfectScrollbar
                options={{ onScrollX: true, suppressScrollX: true }}

                // onScrollX={(container) =>
                //   console.log(`scrolled to: ${container.scrollTop}.`)
                // }
              >
                <Table>
                  <thead>
                    <tr>
                      <th>Pairs</th>
                      <th>Price</th>
                      <th className="align_right">{type}</th>
                    </tr>
                  </thead>
                  {props.marketTab == "btc" && !searchOn && (
                    <tbody>
                      {dataSourceBTC.map((element, index) => (
                        <tr
                          style={{ cursor: "pointer" }}
                          key={index}
                          onClick={() => disconnect(element.pair_key)}
                        >
                          <td>
                            {" "}
                            <i className="fa fa-star-o"></i>{" "}
                            {pairSwap(element.pairs)}
                          </td>

                          <td>
                            {props.sidePairStat[element.pair_key]?.price
                              ? smallestunitFormat(
                                  props.sidePairStat[element.pair_key]?.price
                                )
                              : 0}
                          </td>

                          {type === "Change" && (
                            <td className="green-text align_right">
                              {props.sidePairStat[element.pair_key]?.change &&
                              props.sidePairStat[element.pair_key]?.change !=
                                "Infinity"
                                ? (props.sidePairStat[
                                    element.pair_key
                                  ]?.change).toFixed(2) + "%"
                                : "0%"}
                            </td>
                          )}

                          {type != "Change" && (
                            <td className="green-text align_right">
                              {props.sidePairStat[element.pair_key]?.volume
                                ? smallestunitFormat(
                                    props.sidePairStat[element.pair_key]?.volume
                                  ).toFixed(2)
                                : 0}
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  )}

                  {searchOn && props.marketTab == "btc" && (
                    <tbody>
                      {dataSourceSearch.map((element, index) => (
                        <tr key={index} style={{ cursor: "pointer" }}>
                          <td
                            onClick={() =>
                              history.push(`/my-exchange/${element.pair_key}`)
                            }
                          >
                            {" "}
                            <i className="fa fa-star-o"></i>{" "}
                            {pairSwap(element.pairs)}
                          </td>

                          <td>
                            {props.sidePairStat[element.pair_key]?.price
                              ? smallestunitFormat(
                                  props.sidePairStat[element.pair_key]?.price
                                )
                              : 0}
                          </td>

                          {type === "Change" && (
                            <td className="green-text">
                              {props.sidePairStat[element.pair_key]?.change &&
                              props.sidePairStat[element.pair_key]?.change !=
                                "Infinity"
                                ? (props.sidePairStat[
                                    element.pair_key
                                  ]?.change).toFixed(2) + "%"
                                : "0%"}
                            </td>
                          )}

                          {type != "Change" && (
                            <td className="green-text">
                              {props.sidePairStat[element.pair_key]?.volume
                                ? smallestunitFormat(
                                    props.sidePairStat[element.pair_key]?.volume
                                  ).toFixed(2)
                                : 0}
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  )}
                </Table>
              </PerfectScrollbar>
            </div>
          </Tab>

          <Tab eventKey="usdt" title="USDT">
            <div className="inside_tab">
              <div className="search">
                <Form.Control
                  type="text"
                  placeholder="Search"
                  value={searchText}
                  onChange={(e) => search(e.target.value, "usdt")}
                />
                <img src={SearchImg} className="searchImg" />
              </div>
              {/* <ChangeVolumeTab
                setChangeVolume={setChangeVolume}
              ></ChangeVolumeTab> */}
            </div>
            <div className="table-responsive change_table">
              <PerfectScrollbar
                options={{ onScrollX: true, suppressScrollX: true }}

                // onScrollX={(container) =>
                //   console.log(`scrolled to: ${container.scrollTop}.`)
                // }
              >
                <Table>
                  <thead>
                    <tr>
                      <th>Pairs</th>
                      <th>Price</th>
                      <th className="align_right">{type}</th>
                    </tr>
                  </thead>
                  {props.marketTab == "usdt" && !searchOn && (
                    <tbody>
                      {dataSourceUSDT.map((element, index) => (
                        <tr
                          style={{ cursor: "pointer" }}
                          key={index}
                          onClick={() => disconnect(element.pair_key)}
                        >
                          <td>
                            {" "}
                            <i className="fa fa-star-o"></i>{" "}
                            {pairSwap(element.pairs)}
                          </td>

                          <td>
                            {props.sidePairStat[element.pair_key]?.price
                              ? smallestunitFormat(
                                  props.sidePairStat[element.pair_key]?.price
                                )
                              : 0}
                          </td>

                          {type === "Change" && (
                            <td className="green-text align_right">
                              {props.sidePairStat[element.pair_key]?.change &&
                              props.sidePairStat[element.pair_key]?.change !=
                                "Infinity"
                                ? (props.sidePairStat[
                                    element.pair_key
                                  ]?.change).toFixed(2) + "%"
                                : "0%"}
                            </td>
                          )}

                          {type != "Change" && (
                            <td className="green-text align_right">
                              {props.sidePairStat[element.pair_key]?.volume
                                ? smallestunitFormat(
                                    props.sidePairStat[element.pair_key]?.volume
                                  ).toFixed(2)
                                : 0}
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  )}

                  {searchOn && props.marketTab == "usdt" && (
                    <tbody>
                      {dataSourceSearch.map((element, index) => (
                        <tr key={index} style={{ cursor: "pointer" }}>
                          <td onClick={() => disconnect(element.pair_key)}>
                            {" "}
                            <i className="fa fa-star-o"></i>{" "}
                            {pairSwap(element.pairs)}
                          </td>

                          <td>
                            {props.sidePairStat[element.pair_key]?.price
                              ? smallestunitFormat(
                                  props.sidePairStat[element.pair_key]?.price
                                )
                              : 0}
                          </td>

                          {type === "Change" && (
                            <td className="green-text">
                              {props.sidePairStat[element.pair_key]?.change &&
                              props.sidePairStat[element.pair_key]?.change !=
                                "Infinity"
                                ? (props.sidePairStat[
                                    element.pair_key
                                  ]?.change).toFixed(2) + "%"
                                : "0%"}
                            </td>
                          )}

                          {type != "Change" && (
                            <td className="green-text">
                              {props.sidePairStat[element.pair_key]?.volume
                                ? smallestunitFormat(
                                    props.sidePairStat[element.pair_key]?.volume
                                  ).toFixed(2)
                                : 0}
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  )}
                </Table>
              </PerfectScrollbar>
            </div>
          </Tab>
        </Tabs>
      )}
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList, //pairs list
    sidePairStat: state.exchange.sidePairStat,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveBuyOrders: (data) => dispatch(saveBuyOrders(data)),
    saveSellOrder: (data) => dispatch(saveSellOrder(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Leftside);
