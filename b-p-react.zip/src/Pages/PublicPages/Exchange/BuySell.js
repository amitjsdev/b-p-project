import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Tabs, Tab } from "react-bootstrap";
import Limit from "./Limit";
import Market from "./Market";
import { placeOrder } from "../../../redux/actions/ExchangeActions";
import { connect } from "react-redux";
import CommonCard from "./Components/CommonCard/CommonCard";
import {
  smallestunitFormat,
  digitFormat,
  eightDigit,
  convertExponentialToDecimalTotal,
} from "./Helpers/Normalize";
const BuySell = (props) => {
  const {getUserBalance} = props
  const dispatch = useDispatch();

  const [tab, setTab] = useState("BUY");
  const [buySellData, setBuySellData] = useState({});

  useEffect(() => {
    if (Object.keys(buySellData).length > 0) {
      placingBuySellOrder();
    }
  }, [buySellData]);

  const placingBuySellOrder = () => {
    let values = buySellData;
    values["orderType"] = tab;
    values["pairKey"] = props.pair;
    dispatch(placeOrder(values));
  };

  // Buy  Inputs html ///
  const buyInputs = () => {
    return (
      <div className="TabsCommonSectionInner">
        <div className="tabsSectionOuter">
          <Tabs defaultActiveKey="limit" id="uncontrolled-tab-example">
            <Tab eventKey="limit" title="Limit">
              <Limit
              getUserBalance={getUserBalance}
                base={props.base}
                other={props.other}
                setBuySellData={setBuySellData}
                isLoggedIn={props.isLoggedIn}
                type="Buy"
                pair={props.pair}
              ></Limit>
            </Tab>
            <Tab eventKey="market" title="Market">
              <Market
              getUserBalance={getUserBalance}
                other={props.other}
                setBuySellData={setBuySellData}
                pair={props.pair}
                isLoggedIn={props.isLoggedIn}
                type="Buy"
              ></Market>
            </Tab>
          </Tabs>
        </div>
      </div>
    );
  };

  // Sell  Inputs html ///
  const sellInputs = () => {
    return (
      <div className="TabsCommonSectionInner">
        <div className="tabsSectionOuter">
          <Tabs defaultActiveKey="limit" id="uncontrolled-tab-example">
            <Tab eventKey="limit" title="Limit">
              <Limit
              getUserBalance={getUserBalance}
                base={props.base}
                other={props.other}
                setBuySellData={setBuySellData}
                isLoggedIn={props.isLoggedIn}
                type="Sell"
                pair={props.pair}
              ></Limit>
            </Tab>
            <Tab eventKey="market" title="Market">
              <Market
                getUserBalance={getUserBalance}
                other={props.other}
                setBuySellData={setBuySellData}
                type="Sell"
                pair={props.pair}
                isLoggedIn={props.isLoggedIn}
              ></Market>
            </Tab>
          </Tabs>
        </div>
      </div>
    );
  };

  return (
    <div className="order-col">
      {props.pair1 != "" && (
        <CommonCard
          isLoggedIn={props.isLoggedIn}
          heading="Buy"
          Balance={`${digitFormat(smallestunitFormat(props.walletbuybalance),8)}
          ${props.pair1.toUpperCase()}`}
          className="buyDiv"
        >
          {buyInputs()}
        </CommonCard>
      )}
      {props.pair2 != "" && (
        <CommonCard
          isLoggedIn={props.isLoggedIn}
          heading="Sell"
          Balance={`${digitFormat(
            smallestunitFormat(props.walletsellbalance),
            8
          )}
          ${props.pair2?.toUpperCase()}`}
          className="sellDiv"
        >
          {sellInputs()}
        </CommonCard>
      )}
      {/* <Tabs
        defaultActiveKey="BUY"
        id="uncontrolled-tab-example "
        className="order-tab bg-none buy-sell-col"
        onSelect={(e) => setTab(e)}
      >
        <Tab eventKey="BUY" title="Buy" className="buy-tab">
          <a className="fees-text" href="#">
            Fees
          </a>
          {buyInputs()}
        </Tab>

        <Tab eventKey="SELL" title="Sell" className="buy-tab">
          <a className="fees-text" href="#">
            Fees
          </a>
          {sellInputs()}
        </Tab>
      </Tabs> */}
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    pair2: state.exchange.pair2, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList, //pairs list
    tradebuyfee: state.exchange.tradebuyfee,
    walletbuybalance: state.exchange.walletbuybalance,
    walletsellbalance: state.exchange.walletsellbalance,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(BuySell);
