import React, { useState,useEffect } from "react";
import { Tabs, Tab, Table, Form } from "react-bootstrap";
import { connect } from "react-redux";
import {
  utcDate,
  pairSwap,
  smallestunitFormat,
  listDateFormat,
  minifyDecimal,
} from "./Helpers/Normalize";
import ModalCancelOrder from "./Components/ModalCancelOrder/ModalCancelOrder";
import { CancelOpenOrder } from "../../../redux/actions/ExchangeActions";
import { toast } from "./Components/Toast/Toast";
import PerfectScrollbar from "react-perfect-scrollbar";
import { getToken, removeToken } from "../../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY, SMALLESTUNIT } from "../../../constant";
import { decodeToken } from "react-jwt";

import "react-perfect-scrollbar/dist/css/styles.css";

const History = (props) => {
  let { tradeOrder } = props;

  const [cancelOrderModal, setCancelOrderModal] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [pairId, setPairId] = useState("");

  const [tradeSource, setTradeSource] = useState([]);
  const [yourOrders, setYourOrders] = useState([]);
  const [tradeType, setTradeType] = useState(["Market"]);


  useEffect(() => {
    setTradeSource(tradeOrder);
  }, [tradeOrder]);

  useEffect(() => {
    var tokens = getToken(AUTH_TOKEN_KEY);

    if (tokens !== null && tokens !== undefined) {
      // if loggedIn
      // alert(getUserId(tokens))
      let id = decodeToken(tokens);
      let myOrders = tradeOrder.filter((e, index) => {
        if (e.fUser === id.jwtData || e.tUser === id.jwtData) {
          return e;
        }
      });
      setYourOrders(myOrders);
    }
  }, [tradeOrder]);

  const cancelMyOrder = (orderId, pairId) => {
    setOrderId(orderId);
    setPairId(pairId);
    setCancelOrderModal(true);
  };
  const handleClose = () => {
    setCancelOrderModal(false);
  };

  const confirmCancelOrder = () => {
    let data = {
      orderId: orderId,
      pairId: pairId,
    };
    props.CancelOpenOrder(data).then(
      (res) => {
        handleClose();
        toast.success(res.data.message);
      },
      (error) => {
        if (error == "Unknown Error") {
          toast.error("Cancel Order Failed ! Network Error");
        } else {
          toast.error(error.data.message);
        }
        handleClose();
      }
    );
  };
  return (
    <div className="order-col bg_clr">
      {/* <div key={"custom-radio-buy"} className="mb-3 token_check">
        <Form.Check
          custom
          type={"checkbox"}
          id={"custom-checkbox"}
          name="type"
          label={"Show All Tokens"}
        />
      </div> */}
      <div className="TabsCommonSectionInner orderHistoryNew">
        <div className="tabsSectionOuter">
          <Tabs
            defaultActiveKey="marketHistory"
            id="uncontrolled-tab-example"
            className="order-tab"
          >
           <Tab eventKey="marketHistory" title="Market history">
              <div className="table-responsive order-table">
                <PerfectScrollbar
                // options={{ onScrollX: true, suppressScrollX: true, onScrollY: true, suppressScrollY: true }}
                >
                  <Table>
                    <thead>
                      <tr>
                        <th>Price </th>
                        <th>Amount</th>
                        <th>Time</th>
                      </tr>
                    </thead>
                    {tradeOrder.length > 0 && (
                      <tbody>
                        {props.tradeOrder.map((element, index) => (
                          <tr key={index}>
                          <td className={element.side != 0 ? "negative" : "green-text"}>
                            {" "}
                            {smallestunitFormat(element.price)}
                          </td>
                          <td>{smallestunitFormat(element.amount)}</td>
                          <td>{utcDate(element.date)}</td>
                        </tr>
                        ))}
                      </tbody>
                    )}
                    {props.tradeOrder.length == 0 && (
                      <tbody>
                        <tr>
                          <td colSpan="10" className="text-center no-order">
                            {" "}
                            No records found
                          </td>
                        </tr>
                      </tbody>
                    )}
                  </Table>
                </PerfectScrollbar>
              </div>
            </Tab>
            <Tab eventKey="myTrades" title="My Trades">
              <div className="table-responsive order-table">
                <PerfectScrollbar
                // options={{ onScrollX: true, suppressScrollX: true, onScrollY: true, suppressScrollY: true }}
                >
                  <Table>
                    <thead>
                      <tr>
                        <th>Price </th>
                        <th>Amount</th>
                        <th>Time</th>
                      </tr>
                    </thead>
                    {yourOrders && yourOrders.length > 0 && (
                      <tbody>
                        {props.tradeOrder.map((element, index) => (
                          <tr key={index}>
                          <td className={element.side != 0 ? "negative" : "green-text"}>
                            {" "}
                            {smallestunitFormat(element.price)}
                          </td>
                          <td>{smallestunitFormat(element.amount)}</td>
                          <td>{utcDate(element.date)}</td>
                        </tr>
                        ))}
                      </tbody>
                    )}
                    {props.tradeOrder.length == 0 && (
                      <tbody>
                        <tr>
                          <td colSpan="10" className="text-center no-order">
                            {" "}
                            No records found
                          </td>
                        </tr>
                      </tbody>
                    )}
                  </Table>
                </PerfectScrollbar>
              </div>
            </Tab>
            <Tab eventKey="openorder" title="Open Orders">
              <div className="table-responsive order-table">
                <PerfectScrollbar
                // options={{ onScrollX: true, suppressScrollX: true, onScrollY: true, suppressScrollY: true }}
                >
                  <Table>
                    <thead>
                      <tr>
                        <th>Order Date </th>
                        <th>Type</th>
                        <th>Pair</th>
                        <th>Amount</th>
                        <th>Filled</th>
                        <th>Total Units </th>
                        <th>Price</th>
                        <th>Execution Price </th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    {props.openOrder.length > 0 && (
                      <tbody>
                        {props.openOrder.map((element, index) => (
                          <tr>
                            <td>{listDateFormat(element.date)}</td>
                            <td>
                              {element.side}
                              {element.type == 0 ? "BUY" : "SELL"}
                            </td>
                            <td>{pairSwap(element.pair).toUpperCase()}</td>
                            <td>{smallestunitFormat(element.amount)}</td>
                            <td>{smallestunitFormat(element.filled)}</td>
                            <td>
                              {minifyDecimal(
                                smallestunitFormat(element.amount) *
                                  smallestunitFormat(element.price),
                                8
                              )}
                            </td>
                            <td>{smallestunitFormat(element.price)}</td>
                            <td>
                              {element.executionprice == null
                                ? 0
                                : smallestunitFormat(element.executionprice)}
                            </td>
                            <td>
                              {element.status == 1 && element.filled > 0
                                ? "Partial"
                                : "Open"}
                              {element.status == 1 && element.filled > 0 && (
                                <span>
                                  (
                                  {(
                                    (smallestunitFormat(element.filled) /
                                      smallestunitFormat(element.amount)) *
                                    100
                                  ).toFixed(2)}
                                  % Filled)
                                </span>
                              )}
                            </td>
                            <td>
                              <button
                                className="btn cancel-btn"
                                onClick={() =>
                                  cancelMyOrder(element.orderId, element.pair)
                                }
                              >
                                Cancel Order
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    )}
                    {props.openOrder.length == 0 && (
                      <tbody>
                        <tr>
                          <td colSpan="10" className="text-center no-order">
                            {" "}
                            No Open Orders found
                          </td>
                        </tr>
                      </tbody>
                    )}
                  </Table>
                </PerfectScrollbar>
              </div>
            </Tab>
            <Tab eventKey="openhistory" title="My 24h Order History">
              <div className="table-responsive order-table">
                <PerfectScrollbar
                // options={{ onScrollX: true, suppressScrollX: true, onScrollY: true, suppressScrollY: true }}

                // onScrollX={(container) =>
                //   console.log(`scrolled to: ${container.scrollTop}.`)
                // }
                >
                  <Table>
                    <thead>
                      <tr>
                        <th>Order Date </th>
                        <th>Type</th>
                        <th>Pair</th>
                        <th>Amount</th>
                        <th>Filled</th>
                        <th>Total Units </th>
                        <th>Price</th>
                        <th>Execution Price </th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    {props.completeOrder.length > 0 && (
                      <tbody>
                        {props.completeOrder.map((element, index) => (
                          <tr>
                            <td>{listDateFormat(element.date)}</td>
                            <td>
                              {element.side}
                              {element.type == 0 ? "BUY" : "SELL"}
                            </td>
                            <td>{pairSwap(element.pair).toUpperCase()}</td>

                            <td>{smallestunitFormat(element.amount)}</td>
                            <td>{smallestunitFormat(element.filled)}</td>
                            <td>
                              {/* parseFloat(1.000000003).toPrecision(8) */}
                              {element.price != 0 && (
                                <span>
                                  {minifyDecimal(
                                    smallestunitFormat(element.amount) *
                                      smallestunitFormat(element.price),
                                    8
                                  )}
                                </span>
                              )}
                              {element.price == 0 && (
                                <span>
                                  {smallestunitFormat(element.amount)}
                                </span>
                              )}
                            </td>
                            <td>
                              {element.price != 0
                                ? smallestunitFormat(element.price)
                                : "Market"}
                            </td>
                            <td>
                              {element.executionprice == null
                                ? 0
                                : smallestunitFormat(element.executionprice)}
                            </td>
                            <td>
                              {element.status == 1 && (
                                <span>
                                  {element.filled > 0
                                    ? "Partially Open"
                                    : "Open"}
                                </span>
                              )}

                              {element.status == 2 && (
                                <span>
                                  {element.filled > 0
                                    ? "Partially Cancelled"
                                    : "Cancelled"}
                                </span>
                              )}

                              {element.status == 3 && (
                                <span>
                                  {element.filled == element.amount
                                    ? "Completed"
                                    : "Partially Completed"}
                                </span>
                              )}
                            </td>
                            <td>
                              {element.status == 1 && (
                                <button className="btn cancel-btn">
                                  Cancel Order
                                </button>
                              )}
                              {element.status == 2 && (
                                <button className="btn cancel-btn">
                                  {" "}
                                  Cancelled
                                </button>
                              )}
                              {element.status == 3 && (
                                <button className="btn complete-btn">
                                  Completed
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    )}

                    {props.completeOrder.length == 0 && (
                      <tbody>
                        <tr>
                          <td colSpan="10" className="text-center no-order">
                            {" "}
                            No records
                          </td>
                        </tr>
                      </tbody>
                    )}
                  </Table>
                </PerfectScrollbar>
              </div>
            </Tab>
          </Tabs>
        </div>
      </div>

      {/* cancel modal  */}
      {cancelOrderModal && (
        <ModalCancelOrder
          show={cancelOrderModal}
          handleClose={handleClose}
          Title="Confirm your order cancellation"
          size="md"
          confirm={confirmCancelOrder}
        ></ModalCancelOrder>
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    openOrder: state.exchange.openOrder,
    completeOrder: state.exchange.completeOrder,
    tradeOrder: state.exchange.tradeOrder,

  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    CancelOpenOrder: (data) => dispatch(CancelOpenOrder(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(History);
