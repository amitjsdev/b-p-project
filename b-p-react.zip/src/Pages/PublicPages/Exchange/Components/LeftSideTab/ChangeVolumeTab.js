import React from "react";
import { Tabs, Tab } from "react-bootstrap";

function ChangeVolumeTab(props) {
  return (
    <div className="change_vol">
      <Tabs
        defaultActiveKey={props.changeVolume}
        id="uncontrolled-tab-example"
        className="curr-tab vol-tab"
      onSelect={(e) => props.setChangeVolume(e)}
      >
        <Tab eventKey="Change" title="Change"></Tab>

        <Tab eventKey="Volume" title="Volume"></Tab>
      </Tabs>
    </div>
  );
}

export default ChangeVolumeTab;
