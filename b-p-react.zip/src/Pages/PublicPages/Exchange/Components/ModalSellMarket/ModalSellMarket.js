import { Row, Col, Modal, Button } from "react-bootstrap";
import React, { useState, useEffect } from "react";
import { convertExponentialToDecimalTotal } from "../../Helpers/Normalize";
import { SMALLESTUNIT } from "../../../../../constant";
import { placeOrder } from "../../../../../redux/actions/ExchangeActions";
import { connect } from "react-redux";
import ButtonPrimary from "../../../../../components/common/ButtonPrimary/ButtonPrimary";
import { useDispatch } from "react-redux";

import "./ModalSellMarket.scss";
import { toast } from "../Toast/Toast";

const ModalSellMarket = (props) => {
  const [isBuySell, setIsBuySell] = useState(false);
  const [buysellPair, setBuysellPair] = useState("");
  const [finalFee, setFinalFee] = useState("");

  useEffect(async () => {}, []);

  const confirm = () => {
    props.placeOrder(props.sellFormData).then(
      (res) => {
        props.handleClose();
        toast.success(res.data.message);
        props.formik.resetForm();
        props.getUserBalance()
      },
      (error) => {
        props.handleClose();
        props.formik.resetForm();

        // props.formik.resetForm();
        if (error == "Unknown Error") {
          toast.error("Order Failed ! Network Error");
        } else {
          toast.error(error.data.message);
        }
      }
    );
  };

  return (
    <Modal
      show={props.show}
      onHide={props.handleClose}
      className="modal_style exchangeModal"
      size={props.size}
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>{props.Title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="limit-order">
          <ul>
            <li>
              Amount:{" "}
              <span>
                {props.sellFormData.units} {props.pair2.toUpperCase()}
              </span>
            </li>
          </ul>
        </div>
        <div class="discliamer">
          <h2>Disclaimer</h2>
          <p>
            Please verify this order before confirming. All orders are final
            once submitted and we will be unable to issue you a refund.
          </p>

          <ButtonPrimary
            onClick={() => confirm()}
            className="buy-btn internalComn_btn"
            type="button"
            buttontext="Confirm"
          />
        </div>
      </Modal.Body>
    </Modal>
  );
};

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    placeOrder: (data) => dispatch(placeOrder(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ModalSellMarket);
