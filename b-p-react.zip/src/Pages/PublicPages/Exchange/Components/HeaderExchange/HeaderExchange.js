import { useEffect, useState } from "react";
import { Navbar, Container, Nav, Badge, NavDropdown } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import moon from "../../../../../assets/images/moon.png";
import headfone from "../../../../../assets/images/headfone.svg";
import user from "../../../../../assets/images/user.png";
import MarqueeContainer from "../MarqueeContainer/MarqueeContainer";
import { connect } from "react-redux";
import ButtonPrimary from "../../../../../components/common/ButtonPrimary/ButtonPrimary";
import { changeTheme } from "../../../../../redux/actions/PersistActions";
import "./HeaderExchange.scss";
import { getUserBalance } from "../../../../../redux/actions/WalletActions";
import {
  removeToken,
  setLocalStorage,
  getToken,
} from "../../../../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY } from "../../../../../constant";
import { getUserProfile } from "../../../../../redux/actions/SecurityActions";

function HeaderExchange(props) {
  const {totalValue} = props;
  const history = useHistory();

  const [day, setDay] = useState(false);
  // const [totalValue, setTotalValue] = useState(0.0);
  let lineChartCurrency = "USD";
  var isAuthenticated = false;
  var tokens = getToken(AUTH_TOKEN_KEY);
  if (tokens !== null && tokens !== undefined) {
    isAuthenticated = true;
  }
  useEffect(async () => {
    if (isAuthenticated) {
      props.getUserProfile();
     // getUserBalance();
    }
    if (props.theme) {
      setDay(false)
      document.body.classList.add("lightTheme");
      return;
    }
    setDay(true);
    document.body.classList.remove("lightTheme");
  }, [props.theme]);

  // const getUserBalance = () => {
  //   props
  //     .getUserBalance(lineChartCurrency)
  //     .then((res) => {
  //       let record = res.data.data;
  //       let resData = [];
  //       record.forEach((item, i) => {
  //         let balance = (item?.price * item?.balance) / 100000000;
  //         resData.push({ price: balance });
  //       });

  //       let totalPrice = resData.reduce(function (accumulator, item) {
  //         return accumulator + item.price;
  //       }, 0);
  //       setTotalValue(totalPrice.toFixed(2));
  //     })
  //     .catch((error) => {});
  // };
  async function toggleTheme(mode) {
    if(mode=="day"){
     props.changeTheme(true);
    }else{
     props.changeTheme(false);
    }
   }

  const loggoutUser = (e) => {
    e.preventDefault();
    localStorage.clear();
    setTimeout(() => {
      removeToken(AUTH_TOKEN_KEY, "", 1);
      setLocalStorage("");
      history.push(`/login`);
    }, 400);
  };
  return (
    <Navbar collapseOnSelect className="navAfter_login">
      <Container fluid className="HeaderExch_Mob">
        <div className="marqueeConainer">
          <MarqueeContainer socketData={props?.socketData} />
        </div>
        <div className="userDetail_div">
          <p href="#" className="wallet_Balance">
            {`${totalValue ? totalValue : "0.00"} ${lineChartCurrency}`}
            <span>Wallet Balance</span>
          </p>
          {day ? (
            <a className="sunIcon" onClick={()=>toggleTheme("day")}></a>
            ) : (
              <a className="moonIcon" onClick={()=>toggleTheme("night")}></a>
              )}
          {isAuthenticated ? (
            !!props?.user_info?.email ? (
              <NavDropdown
                title={
                  !!props?.user_info?.first_name
                    ? props?.user_info?.first_name
                    : props?.user_info?.email
                    ? props?.user_info?.email.split("@")[0]
                    : ""
                }
                id="collasible-nav-dropdown"
                className="navDropdown_style"
              >
                <NavDropdown.Item href="/auth/profile">
                  Profile
                </NavDropdown.Item>
                <NavDropdown.Item href="/auth/setting">
                  Setting
                </NavDropdown.Item>
                <NavDropdown.Item href="/auth/kycdetail">Kyc</NavDropdown.Item>
                <NavDropdown.Item
                  onClick={(e) => {
                    loggoutUser(e);
                  }}
                  href="#"
                >
                  Logout
                </NavDropdown.Item>
              </NavDropdown>
            ) : (
              ""
            )
          ) : (
            <ButtonPrimary
             onClick={()=>{
               history.push("/login")
             }

             }
              buttontext="login"
              className="exLogin_Btn internalComn_btn"
            />
          )}{" "}
        </div>
      </Container>
    </Navbar>
  );
}

const mapStateToProps = (state) => {
  return {
    user_info: state.security.userProfile,
    theme: state.persist.theme,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getUserProfile: () => dispatch(getUserProfile()),
    changeTheme: (data) => dispatch(changeTheme(data)),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(HeaderExchange);
