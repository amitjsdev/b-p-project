import { Row, Col, Modal, Button } from "react-bootstrap";
import React, { useState, useEffect } from "react";
import { convertExponentialToDecimalTotal } from "../../Helpers/Normalize";
import { SMALLESTUNIT } from "../../../../../constant";
import { placeOrder } from "../../../../../redux/actions/ExchangeActions";
import { connect } from "react-redux";
import ButtonPrimary from '../../../../../components/common/ButtonPrimary/ButtonPrimary'
import { useDispatch } from "react-redux";

import "./ModalSellConfirmation.scss";
import { toast } from "../Toast/Toast";

const ModalSellConfirmation = (props) => {
  const [isBuySell, setIsBuySell] = useState(false);
  const [buysellPair, setBuysellPair] = useState("");
  const [finalFee, setFinalFee] = useState("");

  useEffect(async () => {
    let buyselldetails = props.sellFormData;
    let fees = props.sellFormData.tradeSellfee;
    let fee = buyselldetails.total * (fees / 100);

    let finalFees = 0;
    finalFees = await convertExponentialToDecimalTotal(fee);

    // finalFees = Math.trunc(finalFees * SMALLESTUNIT) / SMALLESTUNIT;

    setFinalFee(finalFees);

    if (buyselldetails["data"]?.buysellFee) {
      setIsBuySell(true);
      setBuysellPair(buyselldetails["data"].pairKey);
      finalFees = buyselldetails["data"].buysellFee;
      setFinalFee(finalFees);
    }
  }, []);

  const confirm = () => {
    try {
      if (!isBuySell) {
        props.placeOrder(props.sellFormData).then(
          (res) => {
            props.handleClose();
            toast.success(res.data.message);
            props.formik.resetForm();
            props.getUserBalance()
          },
          (error) => {
            props.handleClose();
            // props.formik.resetForm();
            if (error == "Unknown Error") {
              toast.error("Order Failed ! Network Error");
            } else {
              toast.error(error.data.message);
            }
          }
        );
      } else {
        // this.loadingg = true;
        // let data = {
        //   "price": this.buyselldetails["data"].price,
        //   "currency_id": this.buyselldetails["data"].currencyId,
        //   "other_currency_id": this.buyselldetails["data"].otherCurrencyId,
        //   "order_type": "buy",
        //   "qty": this.buyselldetails["data"].units,
        //   "total": this.buyselldetails["data"].total
        // }
        // this.orderService.buyRequest(data).subscribe((res)=>{
        //   toast.success(res.message);
        //   this.dialogRef.close();
        //   this.userService.resetOperation(true);
        //   setTimeout(() => {
        //     this.loadingg = false;
        //   }, 2000);
        // },
        // (error) => {
        //   if(error == "Unknown Error"){
        //     toast.error("Order Failed ! Network Error");
        //   } else {
        //     toast.error(error);
        //   }
        // })
      }
    } catch (error) {
      toast.error(error);
      // this.loadingg = false;
    }
  };

  return (
    <Modal
      show={props.show}
      onHide={props.handleClose}
      className="modal_style exchangeModal"
      size={props.size}
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          {props.pair2.toUpperCase()}/{props.pair1.toUpperCase()} {props.Title}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="limit-order">
          <ul>
            <li>
              Price:{" "}
              <span>
                {props.sellFormData.price} {props.pair1.toUpperCase()}
              </span>
            </li>
            <li>
              Amount:{" "}
              <span>
                {props.sellFormData.units} {props.pair2.toUpperCase()}
              </span>
            </li>
            <li>
              Total:{" "}
              <span>
                {props.sellFormData.total} {props.pair1.toUpperCase()}
              </span>
            </li>
            <li>
              Commission/Fee:{" "}
              <span>
                {parseFloat(finalFee)?.toFixed(8)} {props.pair1.toUpperCase()}
              </span>
            </li>
          </ul>
        </div>
        <div class="discliamer">
          <h2>Disclaimer</h2>
          <p>
            Please verify this order before confirming. All orders are final
            once submitted and we will be unable to issue you a refund.
          </p>

          <ButtonPrimary onClick={() => confirm()} className="buy-btn internalComn_btn" type="button" buttontext="Confirm"/>
          
        </div>
      </Modal.Body>
    </Modal>
  );
};

const mapStateToProps = (state) => {
  return {
    price_decimal: state.exchange.price_decimal,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    placeOrder: (data) => dispatch(placeOrder(data)),
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ModalSellConfirmation);
