import React from "react";
// import WalletImg from "../../../theme/images/WalletBalance.svg";
import "./CommonCard.scss";

function CommonCard({ heading, Balance, children, className }) {
  return (
    <div className={`commonCardDiv ${className}`}>
      <div className={`headerDiv`}>
        {" "}
        {heading ? <h3>{heading}</h3> : null}
        <div className={`BalanceDiv`}>
          {Balance ? <h4 className={`walletBalanceTxt`}>{Balance}</h4> : null}
        </div>
      </div>

      {children}
    </div>
  );
}

export default CommonCard;
