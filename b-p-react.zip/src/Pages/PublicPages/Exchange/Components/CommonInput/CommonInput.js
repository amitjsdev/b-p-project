import React from "react";
import { Form } from "react-bootstrap";
import "./CommonInput.scss";

function CommonInput(props) {
  return (
    <div className="commonInputDiv">
      <Form.Group
        className={`commonInputForm ${props.className}`}
        controlId={props.controlId}
      >
        {props.label ? <Form.Label>{props.label}</Form.Label> : null}
        <Form.Control
          disabled={props.disabled}
          type={props.type}
          value={props.value}
          placeholder={props.placeholder}
          id={id}
          onBlur={props.onBlur}
          onKeyUp={props.onKeyUp}
          onChange={props.onChange}
          maxLength={props.maxLength}
        
        />
        {props.children}
      </Form.Group>
      <div className={`CoinsDiv `}>
        {props.CoinName ? (
          <h3 className={`CoinsText `}>{props.CoinName}</h3>
        ) : null}
      </div>
    </div>
  );
}

export default CommonInput;
