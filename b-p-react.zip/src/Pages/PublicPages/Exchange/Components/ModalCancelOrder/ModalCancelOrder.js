import { Modal, Col, Button } from "react-bootstrap";
import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { toast } from "../Toast/Toast";
import ButtonPrimary from "../../../../../components/common/ButtonPrimary/ButtonPrimary";
import "./ModalCancelOrderStyle.scss";

const ModalCancelOrder = (props) => {
  return (
    <Modal
      show={props.show}
      onHide={props.handleClose}
      className="modal_style exchangeModal"
      size={props.size}
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>{props.Title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div class="discliamer">
          <p>Are you sure, You want to cancel this order?</p>

          <ButtonPrimary
            onClick={() => props.confirm()}
            className="buy-btn internalComn_btn"
            type="button"
            buttontext="Confirm"
          />
        </div>
      </Modal.Body>
    </Modal>
  );
};

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(ModalCancelOrder);
