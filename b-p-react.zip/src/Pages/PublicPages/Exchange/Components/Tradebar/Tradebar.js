import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Nav } from "react-bootstrap";
import arrow from "../../../../../assets/images/arrow.svg";
import { pairSwap, smallestunitFormat } from "../../Helpers/Normalize";
import { connect } from "react-redux";
import Leftside from "../../Leftside";
import DarkModeDropdown from "../../../../../theme/images/DarkModeDropdown.svg";
import LightModeDropdown from "../../../../../theme/images/LightModeDropdown.svg";

function Tradebar(props) {
  let {
    statChange,
    statChangeprcent,
    statHigh,
    statLow,
    statVolume,
    pair1,
    marketTab,
    setMarketTab,
    isLoggedIn,
  } = props;
  const [price, setPrice] = useState(0);

  // const [setClassToggle, classToggle]= useState(false)
  const dispatch = useDispatch();

  const setClassToggle = () => {
    let targetEl = document.getElementsByClassName("rightSidenav")[0];
    if (targetEl.classList.value.indexOf("open") != -1) {
      targetEl.classList.remove("open");
    } else {
      targetEl.classList.add("open");
    }
  };

  return (
    <div className="exchange-header ex_updates">
      <div id="basic-navbar-nav">
        <Nav className="mr-auto navbar-nav trade-bar">
          <Nav.Link
            id="basic-nav-dropdown"
            class="nav-link"
            onClick={setClassToggle}
            className="hoverTab"
          >
            <span>{props.pair ? pairSwap(props.pair).toUpperCase() : ""}</span>
            <span className="imgDropdown">
              <div className="LightModeDropdownDiv">
                <img className="LightModeDropdown" src={LightModeDropdown} />
              </div>
              <div className="DarkModeDropdownDiv">
                <img className="DarkModeDropdown" src={DarkModeDropdown} />
              </div>
            </span>
            {/* <p className="bottomCoinName">Bitcoin</p> */}

            <div className="rightSidenav">
              <Leftside
                pairList={props.pairList}
                isLoggedIn={isLoggedIn}
                marketTab={marketTab}
                setMarketTab={setMarketTab}
              ></Leftside>
            </div>
          </Nav.Link>
          <Nav.Link href="#" className="header-text">
            <p>Last Price</p>
            <p className="white-sm">{smallestunitFormat(props.lastPrice)}</p>
          </Nav.Link>
          <Nav.Link href="#" className="header-text">
            <p>24h Change</p>
            <p className="green-bold font-sm">
              {statChange.toFixed(2)}% ({statChange < 0 ? "-" : "+"}
              {smallestunitFormat(statChangeprcent)}) <img src={arrow} />
            </p>
          </Nav.Link>
          <Nav.Link href="#" className="header-text">
            <p>24h High </p>
            <p className="white-sm">{smallestunitFormat(statHigh)}</p>
          </Nav.Link>
          <Nav.Link href="#" className="header-text">
            <p>24h Low</p>
            <p className="white-sm">{smallestunitFormat(statLow)}</p>
          </Nav.Link>
          <Nav.Link href="#" className="header-text">
            <p>24h Volume</p>
            <p className="white-sm">
              {smallestunitFormat(statVolume).toFixed(2)}{" "}
              {pair1 ? pair1.toUpperCase() : ""}
            </p>
          </Nav.Link>
        </Nav>
      </div>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetag
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList, //pairs list
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(Tradebar);
