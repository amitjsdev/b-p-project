import React from "react";
import { Form, Table, Button } from "react-bootstrap";
import { connect } from "react-redux";
import { smallestunitFormat } from "./Helpers/Normalize";
import { useHistory } from "react-router-dom";

const Assets = (props) => {
  const history = useHistory();

  return (
    <div className="asset-col">
      <div className="asset-box">
        <h5 className="table-heading">Assets</h5>
        <div key={"custom-radio-buy"} className=" token_check assets-check">
          <Form.Check
            custom
            type={"checkbox"}
            id={"custom-tokens"}
            name="type"
            label={"Show All Tokens"}
          />
        </div>
      </div>
      <div className="table-responsive change_table mt-0">
        <Table>
          <thead>
            <tr>
              <th>Token</th>
              <th className="text-right">Balance</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td> {props.pair1.toUpperCase()}</td>
              {props.isLoggedIn && (
                <td className="text-right">
                  {smallestunitFormat(props.walletbuybalance)}
                </td>
              )}
              {!props.isLoggedIn && <td className="text-right">Login</td>}
            </tr>
            <tr>
              <td> {props.pair2 && props.pair2.toUpperCase()}</td>
              {props.isLoggedIn && (
                <td className="text-right">
                  {smallestunitFormat(props.walletsellbalance)}
                </td>
              )}
              {!props.isLoggedIn && <td className="text-right">Login</td>}
            </tr>
          </tbody>
        </Table>
      </div>
      <Button
        className="buy-btn deposit-btn"
        onClick={() => history.push("/auth/wallet")}
      >
        Deposit
      </Button>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    pair1: state.exchange.pair1,
    pair2: state.exchange.pair2,
    walletbuybalance: state.exchange.walletbuybalance,
    walletsellbalance: state.exchange.walletsellbalance,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(Assets);
