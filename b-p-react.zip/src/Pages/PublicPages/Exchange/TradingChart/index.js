import React, { Component } from "react";

import { connect } from "react-redux";

import { widget } from "../charting_library/charting_library.min";

import { dataFeedObject, print } from "./api";
import { saveGraphData } from "../../../../redux/actions/ExchangeActions";
export class TradingChartComponent extends Component {
  constructor() {
    super(...arguments);

    this.currentKlineSubscription = {};

    this.state = {
      period: "5m",
      theme: this.props.theme,
    };

    this.params = {
      interval: "1",
      containerId: "tv_chart_container",
      libraryPath: "../charting_library/",
      chartsStorageUrl: "https://saveload.tradingview.com",
      chartsStorageApiVersion: "1.1",
      clientId: "tradingview.com",
      userId: "public_user_id",
      fullscreen: false,
      autosize: false,
      studiesOverrides: {},
    };

    this.tvWidget = null;

    this.datafeed = dataFeedObject(this, this.props.markets);

    this.setChart = (markets, currentMarket, pair1, pair2) => {
      this.datafeed = dataFeedObject(this, markets);
      const widgetOptions = {
        debug: false,
        symbol:
          pair1 != "" &&
          pair1 != undefined &&
          pair2 != "" &&
          pair2 != undefined &&
          pair2 + pair1,
        datafeed: this.datafeed,
        interval: this.params.interval,
        container_id: this.params.containerId,
        library_path: this.params.libraryPath,
        locale: "en",
        disabled_features: [
          "volume_force_overlay",
          "use_localstorage_for_settings",
          "header_symbol_search",
          // 'header_indicators',
          "header_compare",
          "header_saveload",
          "display_market_status",
        ],
        enabled_features: [
          "show_animated_logo",
          "hide_left_toolbar_by_default",
        ],
        charts_storage_url: this.params.chartsStorageUrl,
        charts_storage_api_version: this.params.chartsStorageApiVersion,
        client_id: this.params.clientId,
        user_id: this.params.userId,
        fullscreen: this.params.fullscreen,
        autosize: this.params.autosize,
        popup_width: "000",
        enable_publishing: false,
        withdateranges: false,
        hide_side_toolbar: true,
        theme: this.props.theme,
        allow_symbol_change: false,
        details: true,
        hotlist: true,
        calendar: true,
        show_popup_button: true,
        popup_height: "50",

        // overrides: {
        //   "paneProperties.background":
        //     this.state.theme === "dark" ? "#0C0C0C" : "#fff",
        // },

        overrides: {
          "mainSeriesProperties.showCountdown": true,
          "paneProperties.background": this.state.theme === 'dark' ?  "#050823" : '#fff',
          // "paneProperties.vertGridProperties.color": "#25324d",
          // "paneProperties.horzGridProperties.color": "#25324d",
          // "symbolWatermarkProperties.transparency": 90,
          // "scalesProperties.textColor": "#AAA",
          // "scalesProperties.bgColor": "#AAA",
          // "scalesProperties.fontSize": 11,
          // "paneProperties.topMargin": 15,
          // "mainSeriesProperties.candleStyle.upColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.downColor": "#e4224a",
          // "mainSeriesProperties.candleStyle.wickUpColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.wickDownColor": "#e4224a",
          // "mainSeriesProperties.candleStyle.borderColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.borderUpColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.borderDownColor": "#e4224a",
          // "mainSeriesProperties.barStyle.upColor": "#5cbf8c",
          // "mainSeriesProperties.barStyle.downColor": "#e4224a",
          // "mainSeriesProperties.barStyle.dontDrawOpen": true,
          // "mainSeriesProperties.barStyle.barColorsOnPrevClose": true,
          // "mainSeriesProperties.candleStyle.barColorsOnPrevClose": true,
          // "mainSeriesProperties.haStyle.barColorsOnPrevClose": true,
        },
        custom_css_url:
          this.state.theme === "dark"
            ? `${process.env.PUBLIC_URL}/charting_library/static/css/header.css`
            : "",
      };

      this.tvWidget = new widget(widgetOptions);
      this.tvWidget.onChartReady(() => {
        const split_data = currentMarket.split("_");
        let cM =
          split_data[1]?.toUpperCase() + "/" + split_data[0]?.toUpperCase();
        this.tvWidget.activeChart().setSymbol(cM, () => {
          print("Symbol set", cM);
        });
      });
    };

    this.updateChart = (currentMarket) => {
      this.tvWidget = null;
      this.datafeed = dataFeedObject(this, this.props.markets);
      const widgetOptions = {
        debug: false,
        symbol:
          this.props.pair1 != "" &&
          this.props.pair1 != undefined &&
          this.props.pair2 != "" &&
          this.props.pair2 != undefined &&
          this.props.pair2 + this.props.pair1,
        datafeed: this.datafeed,
        interval: this.params.interval,
        container_id: this.params.containerId,
        library_path: this.params.libraryPath,
        locale: "en",
        disabled_features: [
          "volume_force_overlay",
          "use_localstorage_for_settings",
          "header_symbol_search",
          // 'header_indicators',
          "header_compare",
          "header_saveload",
          "display_market_status",
        ],
        enabled_features: [
          "show_animated_logo",
          "hide_left_toolbar_by_default",
        ],
        charts_storage_url: this.params.chartsStorageUrl,
        charts_storage_api_version: this.params.chartsStorageApiVersion,
        client_id: this.params.clientId,
        user_id: this.params.userId,
        fullscreen: this.params.fullscreen,
        autosize: this.params.autosize,
        popup_width: "000",
        enable_publishing: false,
        withdateranges: false,
        hide_side_toolbar: true,
        theme: this.props.theme,
        allow_symbol_change: false,
        details: true,
        hotlist: true,
        calendar: true,
        show_popup_button: true,
        popup_height: "50",

        // overrides: {
        //   "paneProperties.background":
        //     this.props.theme === "dark" ? "#0C0C0C" : "#fff",
        // },

        overrides: {
          "mainSeriesProperties.showCountdown": true,
          "paneProperties.background": this.state.theme === 'dark' ?  "#050823" : '#fff',
          // "paneProperties.vertGridProperties.color": "#25324d",
          // "paneProperties.horzGridProperties.color": "#25324d",
          // "symbolWatermarkProperties.transparency": 90,
          // "scalesProperties.textColor": "#AAA",
          // "scalesProperties.bgColor": "#AAA",
          // "scalesProperties.fontSize": 11,
          // "paneProperties.topMargin": 15,
          // "mainSeriesProperties.candleStyle.upColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.downColor": "#e4224a",
          // "mainSeriesProperties.candleStyle.wickUpColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.wickDownColor": "#e4224a",
          // "mainSeriesProperties.candleStyle.borderColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.borderUpColor": "#5cbf8c",
          // "mainSeriesProperties.candleStyle.borderDownColor": "#e4224a",
          // "mainSeriesProperties.barStyle.upColor": "#5cbf8c",
          // "mainSeriesProperties.barStyle.downColor": "#e4224a",
          // "mainSeriesProperties.barStyle.dontDrawOpen": true,
          // "mainSeriesProperties.barStyle.barColorsOnPrevClose": true,
          // "mainSeriesProperties.candleStyle.barColorsOnPrevClose": true,
          // "mainSeriesProperties.haStyle.barColorsOnPrevClose": true,
        },
        custom_css_url:
          this.state.theme === "dark"
            ? `${process.env.PUBLIC_URL}/charting_library/static/css/header.css`
            : "",
      };
      this.tvWidget = new widget(widgetOptions);
      const split_data = currentMarket.split("_");
      let cM =
        split_data[1]?.toUpperCase() + "/" + split_data[0]?.toUpperCase();
      if (this.tvWidget) {
        this.tvWidget.onChartReady(() => {
          this.tvWidget.activeChart().setSymbol(cM, () => {
            print("Symbol set", cM);
          });
        });
      }
    };
  }

  componentWillReceiveProps(next) {
    if (
      next.currentMarket &&
      (!this.props.currentMarket ||
        next.currentMarket !== this.props.currentMarket)
    ) {
      if (this.props.currentMarket && this.tvWidget) {
        this.updateChart(next.currentMarket);
      } else {
        this.setChart(next.markets, next.currentMarket);
      }
    }

    if (next.kline && next.kline !== this.props.kline) {
      this.datafeed.onRealtimeCallback(next.kline);
    }

    if (next.theme && next.theme !== this.state.theme) {
      this.setState({ theme: next.theme }, () => {
        this.updateChart(next.currentMarket);
      });
    }
  }

  componentDidMount() {
    if (this.props.currentMarket) {
      this.setChart(
        this.props.markets,
        this.props.currentMarket,
        this.props.pair1,
        this.props.pair2
      );
    }
  }

  componentWillUnmount() {
    if (this.tvWidget) {
      try {
        this.tvWidget.remove();
      } catch (error) {
        console.log(`TradingChart unmount failed: ${error}`);
      }
    }
  }

  render() {
    return (
      <>
        <div id={this.params.containerId}></div>
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    markets: state.exchange.pairList,
    currentMarket: state.exchange.seletedPair,
    pair1: state.exchange.pair1,
    pair2: state.exchange.pair2,
    theme: state.persist.theme ? "light" : "dark",
    tradeOrder: state.exchange.tradeOrder,
    kline: state.exchange.graphData,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    saveGraphData: (data) => dispatch(saveGraphData(data)),
  };
};
export const TradingChart = connect(
  mapStateToProps,
  mapDispatchToProps
)(TradingChartComponent);
