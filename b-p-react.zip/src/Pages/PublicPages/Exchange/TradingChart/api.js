import axios from "axios";
import { GRAPH_URL } from "../../../../constant";

export const print = (...x) => console.log.apply(null, [">>>> TC", ...x]);
const historyLast = {};
const isTradeList = false;

const resolutionToSeconds = (r) => {
  const minutes = parseInt(r, 10);

  if (r === "1D") {
    return 1440;
  } else if (r === "D") {
    return 4320;
  } else if (!isNaN(minutes)) {
    return minutes;
  } else {
    return 1;
  }
};

const config = {
  supports_time: false,

  supported_resolutions: [
    "1",
    "5",
    "15",
    "30",
    "60",
    "120",
    "240",
    "360",
    "720",
    "d",
    "3d",
  ],
};

export const dataFeedObject = (tradingChart, markets) => {
  const dataFeed = {
    onReady: (cb) => {
      setTimeout(() => cb(config), 0);
    },

    searchSymbols: (userInput, exchange, symbolType, onResultReadyCallback) => {
      const symbols = markets.map((m) => ({
        symbol: m.pairsCombined, //"xrpusdt"
        full_name: m.pairs, //"USDT_XRP"
        description: m.pairs, //"USDT_XRP"
        ticker: m.pairsCombined, //"xrpusdt"
        type: "bitcoin",
      }));

      setTimeout(() => onResultReadyCallback(symbols), 0);
    },

    resolveSymbol: (
      symbolName,
      onSymbolResolvedCallback,
      onResolveErrorCallback
    ) => {
      // expects a symbolInfo object in response
      let newSymbol = symbolName.replace("/", "");
      const symbol = markets.find(
        (m) => m.pairsCombined === newSymbol.toLowerCase()
      );
      if (!symbol) {
        return setTimeout(() => onResolveErrorCallback("Symbol not found"), 0);
      }

      const symbolStub = {
        name: symbol.pairsRevOrder, //"btc_usdt"
        description: "",
        type: "bitcoin",
        session: "24x7",
        timezone: "Etc/UTC",
        ticker: symbol.pairsCombined,
        minmov: 1,
        pricescale: 100000000,
        has_intraday: true,
        intraday_multipliers: [
          "1",
          "5",
          "15",
          "30",
          "60",
          "120",
          "240",
          "360",
          "720",
          "d",
          "3d",
        ],

        supported_resolutions: [
          "1",
          "5",
          "15",
          "30",
          "60",
          "120",
          "240",
          "360",
          "720",
          "d",
          "3d",
        ],

        volume_precision: 8,
        data_status: "streaming",
      };

      return setTimeout(() => onSymbolResolvedCallback(symbolStub), 0);
    },

    getBars: async (
      symbolInfo,
      resolution,
      from,
      to,
      onHistoryCallback,
      onErrorCallback,
      firstDataRequest
    ) => {
      const split_data = symbolInfo.name.split("_");
      const url = `${GRAPH_URL}trading/trade/garphTrading/${
        split_data[1] + "_" + split_data[0]
      }/history?symbol=${
        split_data[1] + "_" + split_data[0]
      }&resolution=${resolution}&from=${from}&to=${to}`;
      return axios
        .get(url)
        .then(({ data }) => {
          if (!data || data === "Error") {
            onHistoryCallback([], { noData: true });
          }
          if (data) {
            var bars = [];
            for (let i = 0; i < data.t.length; i++) {
              bars.push({
                time: data.t[i] * 1000,
                low: data.l[i],
                high: data.h[i],
                open: data.o[i],
                close: data.c[i],
                volume: data.v[i],
              });
            }
            console.log(bars);
            if (firstDataRequest) {
              var lastBar = bars[bars.length - 1];
              historyLast[symbolInfo.name] = { lastBar: lastBar };
            }
            if (bars.length) {
              onHistoryCallback(bars, { noData: false });
            } else {
              onHistoryCallback([], { noData: true });
            }
          }
        })
        .catch((err) => {
          onHistoryCallback([], { noData: true });
        });
    },

    subscribeBars: (
      symbolInfo,
      resolution,
      onRealtimeCallback,
      subscribeUID,
      onResetCacheNeededCallback
    ) => {
      let coeff = resolution * 60;
      dataFeed.onRealtimeCallback = (kline) => {
        let rounded = Math.floor(kline.time / coeff) * coeff;
        if (Object.keys(kline).length > 0) {

          const newKlineData = {
            time: rounded * 1000,
            low: kline.low,
            high: kline.high,
            open: kline.open,
            close: kline.close,
            volume: kline.volume,
          };
          onRealtimeCallback(newKlineData);
        }
      };
    },

    unsubscribeBars: (subscribeUID) => {
      const { marketId, periodString } = tradingChart.currentKlineSubscription;

      if (marketId && periodString) {
        tradingChart.props.unSubscribeKline(marketId, periodString);
      }

      tradingChart.currentKlineSubscription = {};
    },

    onRealtimeCallback: (kline) => {
      console.log("Kline Data 12=> ", kline);
      // window.console.log(`default onRealtimeCallback called with ${JSON.stringify(bar)}`);
    },
  };

  return dataFeed;
};
