import React, { useEffect, useState } from "react";
import { Table } from "react-bootstrap";
import { getToken } from "../../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY } from "../../../constant";
import { connect } from "react-redux";
import { decodeToken } from "react-jwt";
import { smallestunitFormat, utcDate } from "./Helpers/Normalize";

const Trades = (props) => {
  let { tradeOrder } = props;

  const [tradeSource, setTradeSource] = useState([]);
  const [yourOrders, setYourOrders] = useState([]);
  const [tradeType, setTradeType] = useState(["Market"]);
  useEffect(() => {
    setTradeSource(tradeOrder);
  }, [tradeOrder]);

  useEffect(() => {
    var tokens = getToken(AUTH_TOKEN_KEY);

    if (tokens !== null && tokens !== undefined) {
      // if loggedIn
      // alert(getUserId(tokens))
      let id = decodeToken(tokens);
      let myOrders = tradeOrder.filter((e, index) => {
        if (e.fUser === id.jwtData || e.tUser === id.jwtData) {
          return e;
        }
      });
      setYourOrders(myOrders);
    }
  }, [tradeOrder]);

  const setTableData = (type) => {
    setTradeType(type);
    if (type == "Market") {
      setTradeSource(tradeOrder);
    } else {
      setTradeSource(yourOrders);
    }
  };
  return (
    <>
      <div className="trade_hdr">
        <h5 className="table-heading">Trades</h5>
        <div className="trades_tab">
          <span
            className={tradeType == "Market" ? "tab active" : "tab"}
            onClick={() => setTableData("Market")}
          >
            Market
          </span>
          {props.isLoggedIn && (
            <span
              className={tradeType == "Yours" ? "tab active" : "tab"}
              onClick={() => setTableData("Yours")}
            >
              Yours
            </span>
          )}
        </div>
      </div>
      <div className="table-responsive change_table trade_data">
        <Table>
          <thead>
            <tr>
              <th>Price</th>
              <th className="align-right">Amount</th>
              <th className="align-right">Time</th>
            </tr>
          </thead>
          <tbody className="flowarea">
            {tradeSource.map((element, index) => (
              <tr key={index}>
                <td className={element.side != 0 ? "negative" : "green-text"}>
                  {" "}
                  {smallestunitFormat(element.price)}
                </td>
                <td>{smallestunitFormat(element.amount)}</td>
                <td>{utcDate(element.date)}</td>
              </tr>
            ))}
            {tradeSource.length == 0 && (
              <tr>
                <td colSpan="10" className="text-center no-order">
                  {" "}
                  No Open Orders found
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange, //24H Change
    statChangeprcent: state.exchange.statChangeprcent, //24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    tradeOrder: state.exchange.tradeOrder,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(mapStateToProps, mapDispatchToProps)(Trades);
