import React, { useState, useEffect } from "react";
import { Row, Col, Tabs, Tab, Form, Table, Card } from "react-bootstrap";

import { Link } from "react-router-dom";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CommonCont from "../../../components/CommonCont/CommonCont";
import PassworHide from "../../../theme/images/eye_slash.svg";
import PassworShow from "../../../theme/images/eye_open.svg";

import {
  userLogin,
  getUserIpAddress,
  getUserInfoAfterLoginOnly,
  send2faEmailVerification,
  token_verification,
  token_verification_google,
  verifygoogle2fa,
  resendVerificationMail,
} from "../../../redux/actions/AuthActions";
import { updateFirstTimeLoginState } from "../../../redux/actions/PersistActions";
import "./Login.scss";
import { connect } from "react-redux";
import ReCAPTCHA from "react-google-recaptcha";
import { CAPTCHA_KEY, AUTH_TOKEN_KEY } from "../../../constant";
import { setToken, setLocalStorage } from "../../../Helpers/storageHelper";
import Modal2fa from "../../../components/common/Modal2fa/Modal2fa";
import {
  browserName,
  browserVersion,
  osName,
  isDesktop,
  isMobile,
  isTablet,
  isSmartTV,
} from "react-device-detect";

function Login(props) {
  const [checkEmail, setCheckEmail] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [formData, setFormData] = useState([]);
  const [setCaptchaValue, setMyCaptchaValue] = useState("");
  const [ip, setIp] = useState("");
  const [location, setLocation] = useState("");
  const [showOption2fa, setShowOption2fa] = useState(false);
  const [googleAuth, setGoogleAuth] = useState(false);
  const [emailAuth, setEmailAuth] = useState(false);
  const [loginTempToken, setLoginTempToken] = useState("");
  const [sendEmail, setSendEmail] = useState(false);
  const [securityToken2fa, setSecurityToken2fa] = useState("");
  const [googleToken, setGoogleToken] = useState("");
  const [emailToken, setEmailToken] = useState("");
  const [showResend, setShowResend] = useState(false);
  const [verificationMail, setVerificationMail] = useState(false);
  const [checkCaptcha, setCheckCaptcha] = useState(false);

  const capthaKey = CAPTCHA_KEY;

  let deviceType;
  if (isDesktop) {
    deviceType = `Desktop ${osName}`;
  } else if (isMobile) {
    deviceType = `Mobile ${osName}`;
  } else if (isTablet) {
    deviceType = `Tablet ${osName}`;
  } else if (isSmartTV) {
    deviceType = `SmartTV ${osName}`;
  } else {
    deviceType = `Other device ${osName}`;
  }

  var navigator_info = window.navigator;
  var screen_info = window.screen;
  var uid = navigator_info.mimeTypes.length;
  uid += navigator_info.userAgent.replace(/\D+/g, "");
  uid += navigator_info.plugins.length;

  const getUserIpAddress = () => {
    props.getUserIpAddress().then((res) => {
      setIp(res.data.ip);
      let ipLocation = res.data.city + "," + res.data.country_name;
      setLocation(ipLocation);
    });
  };
  const showHide = (e, value) => {
    e.preventDefault();
    setShowPass(!showPass);
  };

  const handleChange = (e, type) => {
    let value = e.target.value;
    let data = {
      user_device: deviceType,
      capReq: "0",
      device_type: "3",
      user_browser: `${browserName} ${browserVersion}`,
    };
    if (formData && formData?.data) {
      data = { ...formData.data };
    }
    data[type] = value;
    setFormData({ ...formData, data });
  };

  const verifyTokenReq = (e) => {
    e.preventDefault();
    if (emailAuth) {
      let data = {
        token: securityToken2fa,
        isEnabled: true,
        userToken: loginTempToken,
        type: "login",
      };
      props.token_verification_email(data).then((res) => {
        setEmailAuth(false);
        setToken(AUTH_TOKEN_KEY, loginTempToken, 1); // 6 hrs
        setLocalStorage(ip);
        props.history.push(`/auth/dashboard`);
      });
    } else if (googleAuth) {
      let data = {
        token: securityToken2fa,
        userToken: loginTempToken,
        type: "login",
      };
      props.token_verification_google(data).then((res) => {
        setGoogleAuth(false);
        setToken(AUTH_TOKEN_KEY, loginTempToken, 1); // 6 hrs
        setLocalStorage(ip);
        props.history.push(`/auth/dashboard`);
      });
    } else {
      let data = {
        twofatoken: googleToken,
        emailToken: emailToken,
        accessToken: loginTempToken,
      };
      props.verifygoogle2fa(data).then((res) => {
        setShowOption2fa(false);
        setToken(AUTH_TOKEN_KEY, loginTempToken, 1); // 6 hrs
        setLocalStorage(ip);
        props.history.push(`/auth/dashboard`);
      });
    }
  };

  const onFormSubmit = (e) => {
    e.preventDefault();
    if (setCaptchaValue == "") {
      setCheckCaptcha(true);
      return;
    }
    props
      .userLogin(formData.data)
      .then(async (resp) => {
        //  let isUserLogin = res.isFirstLogin;
        let isUserLogin = resp.data.isFirstLogin;
        await props.updateFirstTimeLoginState(isUserLogin);
        await setLoginTempToken(resp.data.JwtToken);
        if (resp.data.JwtToken) {
          props
            .getUserInfoAfterLoginOnly(resp.data.JwtToken)
            .then(async (res) => {
              let user_info = res.data.data;
              //  check if any 2fa security is enabled
              if (
                user_info?.is_google_2fa_active == 1 ||
                user_info?.is_email_active == 1
              ) {
                if (
                  user_info?.is_google_2fa_active == 1 &&
                  user_info?.is_email_active == 1
                ) {
                  setSendEmail(true);
                  setShowOption2fa(true);
                } else if (user_info?.is_google_2fa_active == 1) {
                  setGoogleAuth(true);
                } else if (user_info?.is_email_active == 1) {
                  setEmailAuth(true);
                  // requesting to send token on users email
                  setSendEmail(true);
                  // send2faEmailVerification();
                } else {
                  setShowOption2fa(true);
                }
              } else {
                setLocalStorage(ip);
                // if none of any 2fA Security is enabled
                setLoginTempToken(resp.data.JwtToken);
                await setToken(AUTH_TOKEN_KEY, resp.data.JwtToken, 1); // 6 hrs
                props.history.push(`/auth/dashboard`);
              }
              //   setLoginTempToken(resp.data.JwtToken);
              //  // setShowOption2fa(false);
              //   await setToken(
              //     AUTH_TOKEN_KEY,
              //     resp.data.JwtToken,
              //     1
              //   ); // 6 hrs
              //   props.history.push(`/auth/dashboard`);
            });
        }
      })
      .catch((error) => {
        resetCaptcha();
      });
    // actions.setSubmitting(false);
  };

  const handleChangeRecaptcha = (value) => {
    setCheckCaptcha(false);
    setMyCaptchaValue(value);
    let data = {};
    if (formData && formData?.data) {
      data = { ...formData?.data };
    }
    data["ip"] = ip;
    data["location"] = location;
    data["deviceId"] = uid;

    data["captchatext"] = value;
    setFormData({ ...formData, data });
  };

  const resetCaptcha = () => {
    window["grecaptcha"].reset();
    setMyCaptchaValue("");
  };

  const checkEmailValidity = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const checkEmailExist = () => {
    if (checkEmailValidity(formData?.data?.email)) {
      setCheckEmail(false);
    } else {
      setCheckEmail(true);
    }
  };

  useEffect(() => {
    getUserIpAddress();
  }, []);

  const checkPassword = (e) => {};

  const send2faEmailVerification = () => {
    props
      .send2faEmailVerification(loginTempToken)
      .then((res) => {})
      .catch((error) => {});
  };

  const handleClose2Auth = () => {
    setEmailAuth(false);
    setGoogleAuth(false);
    resetCaptcha();
  };
  //for both email and google
  const handleCloseAuth = () => {
    setShowOption2fa(false);
    resetCaptcha();
  };

  useEffect(() => {
    if (sendEmail) {
      send2faEmailVerification();
    }
  }, [sendEmail]);
  //code  for paste google code
  var el = document.getElementById("paste");
  if (el) {
    el.addEventListener("click", () => {
      let pasteArea = document.getElementById("pasteArea");
      pasteArea.value = "";

      navigator.clipboard.readText().then((text) => {
        pasteArea.value = text;
      });
      navigator.clipboard.readText().then((text) => {
        pasteArea.value = text;
        setGoogleToken(pasteArea.value);
      });
      //setGoogleToken(navVal)
    });
  }

  //end google code

  const resendMailVerification = () => {
    props.resendVerificationMail({ email: verificationMail }).then((res) => {
      setShowResend(false);
    });
  };

  const handleCloseMail = () => {
    setShowResend(false);
  };
  return (
    <>
      <CommonCont
        heading="Sign In"
        subheading="Welcome back! Sign In with your Email"
        className="loginCont_Style"
      >
        <Form onSubmit={onFormSubmit} className="commonForm_style">
          <CustomInput
            name="email"
            handleChange={handleChange}
            placeholder="Email*"
            checkEmailExist={checkEmailExist}
          >
            {" "}
            {!!formData?.data?.email && checkEmail && (
              <p style={{ marginTop: "10px", color: "red" }}>
                Email is not valid
              </p>
            )}
          </CustomInput>
          <CustomInput
            checkPassword={checkPassword}
            name="password"
            handleChange={handleChange}
            type={showPass ? `text` : `password`}
            placeholder="Password*"
          >
            <a
              onClick={(e) => {
                showHide(e, "password");
              }}
              className="showPassword"
            >
              {showPass ? <img src={PassworShow} /> : <img src={PassworHide} />}
            </a>
          </CustomInput>
          <div className="d-flex justify-content-between reverify_Txt">
            <a
              href="#"
              onClick={() => {
                setShowResend(true);
              }}
              className="forgotLink"
            >
              Resend verification mail
            </a>

            <a href="/forgot-password" className="forgotLink forForgot_Pswd">
              Forgot Password?
            </a>
          </div>
          <div className="reCaptcha_div">
            <ReCAPTCHA
              required={true}
              theme="light"
              sitekey={capthaKey}
              onExpired={() => resetCaptcha()}
              onChange={handleChangeRecaptcha}
            />
            {checkCaptcha && (
              <p style={{ marginTop: "10px", color: "red" }}>
                This is required field
              </p>
            )}
          </div>

          <ButtonPrimary
            style={{ marginTop: "10px" }}
            // disabled={setCaptchaValue == ""}
            buttontext="Sign In"
          />
        </Form>

        <p>
          New User? <Link to="/signup">Sign Up</Link>
        </p>
      </CommonCont>
      {/* showOption2fa both */}
      <Modal2fa
        className="modal_gemailauth"
        show={showOption2fa}
        handleClose={handleCloseAuth}
        Title="Security Verification"
        size="md"
      >
        <CommonCont
          subheading="To open your account, please complete the following verification."
          className="securityCont_Style"
        >
          <Form className="commonForm_style">
            <Form.Group className="customInput">
              <Form.Control
                placeholder="Enter email token*"
                type="text"
                onChange={(e) => {
                  setEmailToken(e.target.value);
                }}
                required={true}
              />
              <a onClick={send2faEmailVerification} className="showPassword">
                Send code
              </a>
              <p>Enter the 5 digit code received by your mail</p>
            </Form.Group>
            <Form.Group className="customInput">
              <Form.Control
                id="pasteArea"
                placeholder="Enter google token*"
                type="text"
                onChange={(e) => {
                  setGoogleToken(e.target.value);
                }}
                required={true}
              />
              <a id="paste" className="showPassword">
                Paste
              </a>
              <p>Enter the 6 digit code from Google Authenticator.</p>
            </Form.Group>

            <ButtonPrimary
              disabled={!emailToken && !googleToken}
              onClick={(e) => verifyTokenReq(e)}
              buttontext="send"
            />
          </Form>
        </CommonCont>
      </Modal2fa>

      {/* showOption2fa single */}

      <Modal2fa
        className="modal_gemailauth"
        show={googleAuth || emailAuth}
        handleClose={handleClose2Auth}
        Title={`${googleAuth ? "Google" : "Email"} Authentication`}
        size="md"
      >
        <Form.Group className="customInput internalInput">
          <Form.Control
            placeholder="Enter token*"
            type="text"
            onChange={(e) => {
              setSecurityToken2fa(e.target.value);
            }}
          />
        </Form.Group>
        <ButtonPrimary
          className="mb-0"
          onClick={(e) => verifyTokenReq(e)}
          buttontext={"Submit"}
        />
      </Modal2fa>
      {/* send login verification mail */}
      <Modal2fa
        className="modal_gemailauth"
        show={showResend}
        handleClose={handleCloseMail}
        Title={`Resend verification mail`}
        size="md"
      >
        <Form.Group className="customInput internalInput">
          <Form.Control
            placeholder="Enter Email*"
            type="text"
            onChange={(e) => {
              setVerificationMail(e.target.value);
            }}
          />
        </Form.Group>
        <ButtonPrimary
          className="mb-0"
          onClick={(e) => resendMailVerification(e)}
          buttontext={"Send"}
        />
      </Modal2fa>
    </>
  );
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    userLogin: (data) => dispatch(userLogin(data)),
    getUserIpAddress: () => dispatch(getUserIpAddress()),
    updateFirstTimeLoginState: (data) =>
      dispatch(updateFirstTimeLoginState(data)),
    getUserInfoAfterLoginOnly: (token) =>
      dispatch(getUserInfoAfterLoginOnly(token)),
    send2faEmailVerification: (token) =>
      dispatch(send2faEmailVerification(token)),
    token_verification_email: (data) => dispatch(token_verification(data)),
    token_verification_google: (data) =>
      dispatch(token_verification_google(data)),
    verifygoogle2fa: (data) => dispatch(verifygoogle2fa(data)),
    resendVerificationMail: (data) => dispatch(resendVerificationMail(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Login);
