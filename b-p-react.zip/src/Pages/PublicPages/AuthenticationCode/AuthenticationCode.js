import React from "react";
import ReactCodeInput from "react-code-input";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CommonCont from "../../../components/CommonCont/CommonCont";
import CopyIcon from "../../../theme/images/copy_icon.svg";
import "./AuthenticationCode.scss";

function AuthenticationCode() {
  return (
    <>
      <CommonCont
        heading="Keep a physical or digital copy of your backup code to stay secure."
        className="authCont_Style"
      >
        <CustomInput
          placeholder="btrpfazltor3h52wjrrnfvsmkrnge525shju"
          disabled
        >
          <a className="showPassword">
            <img src={CopyIcon} />
          </a>
        </CustomInput>
        <p className="info_msg">
          We do not recommend sharing or publishing the backup code anywhere or
          with anyone.
        </p>
        <h3>6 digit code displayed by your app</h3>
        <ReactCodeInput type="number" fields={6} />
        <ButtonPrimary buttontext="Continue" />
      </CommonCont>
    </>
  );
}

export default AuthenticationCode;
