import CardSquare from '../../../components/CardSquare/CardSquare'
// import './index.scss'
import {Link} from 'react-router-dom'
import { Container, Row, Col } from 'react-bootstrap';
// import Header from '../../../Components/Header/Header'
// import qrCode from '../../../assets/images/qr_code_img.png'
import ButtonCustom from '../../../components/ButtonCustom/ButtonCustom'
import appleStoreBtn from '../../../assets/images/apple_store_btn.png'
import playStore from '../../../assets/images/google_play_btn.png'
import { connect } from "react-redux";
import {updateFirstTimeLoginState} from "../../../redux/actions/PersistActions";
import { withRouter } from "react-router";


const Authenticator = (props) =>{
   const goTokyc = async()=>{
        await props.updateFirstTimeLoginState(1);

        props.history.push(`/auth/kyc-process`);

    }
    return(
        <>
        {/* <Header /> */}
        <Container fluid className="containerFullWidth">
            <CardSquare className="auth_card">
                <Col className="auth_card__header">
                    <h1>Additional Security using Authenticator</h1>
                    <p>Using the Authenticator app, Scan the QR code below</p>
                </Col>
                <Col className="auth_card__qrcode">
                    <img src={props.qrImgUrl} />
                </Col>
                <Col className="auth_card__btnCustom">
                    <ButtonCustom
                        className="auth_card__continue" 
                        type="button"
                        buttontext="Continue"
                        onClick={()=>props.changeStep(2)}
                    />
                    <Link className="auth_card__skipBtns" onClick={()=>goTokyc()}>Skip</Link>
                </Col>
                <Col className="auth_card__appBtns">
                    <ul>
                        <li><p>Don’t have Authenticator app?</p></li>
                        <li><a href="https://apps.apple.com/us/app/google-authenticator/id388497605"  target="_blank"><img src={appleStoreBtn} /></a></li>
                        <li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en_IN&gl=US"  target="_blank"><img src={playStore} /></a></li>                        
                    </ul>
                </Col>
            </CardSquare>
        </Container>
        </>
    )
}


const mapStateToProps = state => {
    return {
        isUserFirstTimeLogin:state.persist.isUserFirstTimeLogin,
        secret: state.security.secret,
        qrImgUrl:state.security.qrImgUrl

    };
  };
  
  const mapDispatchToProps = dispatch => {
    return {
        updateFirstTimeLoginState:(data)=>dispatch(updateFirstTimeLoginState(data)),

    };
  };
  export default withRouter(connect(
    mapStateToProps,
    mapDispatchToProps
  )(Authenticator));