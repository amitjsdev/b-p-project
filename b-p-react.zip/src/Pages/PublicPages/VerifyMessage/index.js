import React , {useEffect} from 'react'
import { Container, Row, Col } from 'react-bootstrap';
import {Link} from 'react-router-dom'
import 'react-multi-carousel/lib/styles.css';
import { useParams } from "react-router";

import { connect } from "react-redux";
import { verifyUserEmail } from "../../../redux/actions/AuthActions";

const VerifyMessage = props => {
    const { hashCode } = useParams();

    useEffect(() => {
      let data = {
        hash: hashCode,
      };
      props.verifyUserEmail(data).then(
        (res) => {
          props.history.push(`/login`);
        },
        (err) => {
          props.history.push(`/login`);
        }
      );
    }, []);
  
    return <></>;

}
const mapStateToProps = state => {
    return {
        email: state.register.email,

    };
};

const mapDispatchToProps = dispatch => {
    return {
        verifyUserEmail: (data) => dispatch(verifyUserEmail(data)),
      

    };
};
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(VerifyMessage);
