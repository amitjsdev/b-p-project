import React, { useState, useEffect } from "react";
import { Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CommonCont from "../../../components/CommonCont/CommonCont";
import { connect } from "react-redux";
import {resetUserPassword} from "../../../redux/actions/AuthActions";
import "./index.scss";
import PassworHide from "../../../theme/images/eye_slash.svg";
import PassworShow from "../../../theme/images/eye_open.svg";
import { useParams } from "react-router";


function ResetPassword(props){

    const [checkEmail, setCheckEmail] = useState(false);
    const [showPassConfirm, setShowPassConfirm] = useState(false);
    const [matchPass, setMatchPass] = useState(false);

    const [formData, setFormData] = useState([]);
    const [showPass, setShowPass] = useState(false);
    const [showPassMin, setShowPassMin] = useState(false);
    const [showPassSpecial, setShowPassSpecial] = useState(false);
    const [showPassUpperCase, setShowPassUpperCase] = useState(false);
    const [showPassLowerCase, setShowPassLowerCase] = useState(false);
    const [showPassNumber, setShowPassNumber] = useState(false);
    const { hash } = useParams();

    const checkEmailValidity = (email) => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      }

      const showHide = (e, value) => {
        e.preventDefault();
        if (value === 'confirmPassword') {
          setShowPassConfirm(!showPassConfirm)
        } else {
          setShowPass(!showPass)
        }
      }
    
      const handleChange = (e, type) => {
        let value = e.target.value;
        let data = {
            hash: hash
        }
        if (type === 'confirmPassword') {
            if (formData?.data?.new_password) {
              if (formData?.data?.new_password === value) {
                setMatchPass(false)
               // setShowPass(false)
              } else {
                setMatchPass(true)
               // setShowPass(true)
      
              }
            }
          }
      
          if (type === 'new_password') {
            if (formData?.data?.confirmPassword) {
              if (formData?.data?.confirmPassword === value) {
                setMatchPass(false)
               // setShowPass(false)
              } else {
              //  setShowPass(true)
                setMatchPass(true)
              }
            }
          }

        if (formData && formData?.data) {
          data = { ...formData.data }
        }
        data[type] = value;
        setFormData({ ...formData, data })
      }


      const onFormSubmit = e => {
        e.preventDefault()
        props.resetUserPassword(formData?.data).then((res)=>{
            props.history.push(`/login`)
        }).catch((error) => {
        })
    
      }

      const checkPassword = (e) => {
        if (!(/[A-Z]/).test(e.target.value)) {
          //setShowPass(true)
          setShowPassUpperCase(true)
          setShowPassMin(false)
          setShowPassLowerCase(false)
          setShowPassNumber(false)
          setShowPassSpecial(false)
        } else if (!(/[a-z]/).test(e.target.value)) {
         // setShowPass(true)
          setShowPassLowerCase(true)
          setShowPassMin(false)
          setShowPassUpperCase(false)
          setShowPassNumber(false)
          setShowPassSpecial(false)
        } else if(!(/[0-9]/).test(e.target.value)) {
        //  setShowPass(true)
          setShowPassNumber(true)
          setShowPassMin(false)
          setShowPassUpperCase(false)
          setShowPassLowerCase(false)
          setShowPassSpecial(false)
        }  else if(!(/[^a-zA-Z0-9]/).test(e.target.value)) {
          //setShowPass(true)
          setShowPassSpecial(true)
          setShowPassNumber(false)
          setShowPassMin(false)
          setShowPassUpperCase(false)
          setShowPassLowerCase(false)
        }  else if (e.target.value.toString().length < 8) {
         // setShowPass(true)
          setShowPassMin(true)
          setShowPassNumber(false)
          setShowPassUpperCase(false)
          setShowPassLowerCase(false)
          setShowPassSpecial(false)
        } else if (e.target.value === formData?.data?.old_password) {
         // setShowPass(true)
          setShowPassMin(false)
          setShowPassNumber(false)
          setShowPassUpperCase(false)
          setShowPassLowerCase(false)
          setShowPassSpecial(false)
        } else {
          setShowPass(false)
          setShowPassMin(false)
          setShowPassUpperCase(false)
          setShowPassLowerCase(false)
          setShowPassNumber(false)
          setShowPassSpecial(false)
        }
    
      }


  return (
    <>
      <CommonCont
        heading="Reset Your Password Now"
        className="loginCont_Style"
      >
        <Form onSubmit={onFormSubmit} className="commonForm_style">
        <CustomInput checkPassword={checkPassword} name="new_password" handleChange={handleChange} type={showPass ? `text` : `password`} placeholder="Password">
            <a onClick={(e) => { showHide(e, 'new_password') }} className="showPassword">
              {showPass ? <img src={PassworShow} /> : <img src={PassworHide} />}
            </a>
                  {showPassUpperCase && <p style={{ color: 'red' }}>One uppercase character</p>}
                  {showPassLowerCase && <p style={{ color: 'red' }}>One lowercase character</p>}
                  {showPassNumber && <p style={{ color: 'red' }}>One number</p>}
                  {showPassSpecial && <p style={{ color: 'red' }}>One special character</p>}
                  {showPassMin && <p style={{ color: 'red' }}>8 characters minimum</p>}

          </CustomInput>
          <CustomInput name="confirmPassword" handleChange={handleChange} type={showPassConfirm ? `text` : `password`} placeholder="Confirm Password">
            <a onClick={(e) => { showHide(e, 'confirmPassword') }} className="showPassword">
              {showPassConfirm ? <img src={PassworShow} /> : <img src={PassworHide} />}
            </a>
            {formData?.data?.new_password && formData?.data?.confirmPassword && (formData?.data?.new_password !== formData?.data?.confirmPassword)
              && <p style={{ marginTop: '10px', color: 'red' }}>Confirm password doesn't match</p>}
          </CustomInput>
          <ButtonPrimary
          disabled={matchPass}
            style={{ marginTop: '10px' }}
            buttontext="Reset Password" />
        </Form>


        <p>
         <Link to="/login">Back to Sign In</Link>
        </p>
      </CommonCont>
    </>
  );
}

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    resetUserPassword: (data) => dispatch(resetUserPassword(data))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword);
