export const ENV_VAR = process.env.ENV_VAR;
export const EXCHANGE_LINK = process.env.REACT_APP_EXCHANGE_URL;
export const TRANSAK_API_KEY =process.env.REACT_APP_TRANSAK_API_KEY;
export const TRANSAK_API_ENV=process.env.REACT_APP_TRANSAK_API_KEY_STAGING
export const  ENCRYPT_KEY = process.env.REACT_APP_ENCRYPT_KEY
export const  DECRYPT_KEY =process.env.REACT_APP_DECRYPT_KEY
export const  GRAPH_URL =process.env.REACT_APP_GRAPH_URL
export const DEPTH_GRAPH_URL = process.env.REACT_APP_DEPTH_GRAPH_URL;


export const rootName = "";
export const API_HOST = process.env.REACT_APP_API_URL;
export const CAPTCHA_KEY = process.env.REACT_APP_GOOGLE_CAPTCHA_KEY;
// export const ENV_VAR = process.env.ENV_VAR;
export const SOCKET_URL = process.env.REACT_APP_SOCKET_URL;
export const P2P_SOCKET_URL = process.env.REACT_APP_P2P_SOCKET_URL;
export const S3_BASE_PATH = process.env.REACT_APP_S3_BASE_PATH
export const globalResErrMsg =
  "Woops something went wrong, Please try again.";
export const SUCCESS_200 = 200;
export const BAD_REQUEST = 400;
export const UNAUTHORISED = 401;
export const AUTH_TOKEN_KEY = "JwtToken";
export const PASSPORT_FRONT = 0;
export const PASSPORT_BACK = 2;
export const LICENSE_FRONT = 3;
export const LICENSE_BACK = 4;
export const NATIONAL_ID = 1;
export const KYC_SUBMITTED = 0;
export const KYC_APPROVED = 1;
export const KYC_DECLINED = 2;
export const KYC_RE_SUBMITTED = 3;
export const SMALLESTUNIT = 100000000;
export const totallimit = 10000000000000000;
export const txnWaiting = 0 //WAITING FOR ADMIN APPROVAL
export const txnUnconfirmed = 1 //UNCONFIRMED
export const txnCompleted = 2 //CONFIRMED
export const txnRjected = 3 //REJECTED BY ADMIN 
export const currencyDivison = 100000000;


