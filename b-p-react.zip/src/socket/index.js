import { SOCKET_URL } from "../constant";
import io from "socket.io-client";

const socket = io.connect(SOCKET_URL, {
  reconnect: true,
  transports: ["websocket"],
});
console.log("scoket--", socket,'url',SOCKET_URL);
socket.on("joined", () => {
  console.log("**Socket joined successfully");
});

  // socket.emit("Bittexx_market_page", {
  //   // member: getToken(AUTH_TOKEN_KEY),
  //   // accessToken: getToken(AUTH_TOKEN_KEY),
  // });



// socket.on('allStat', (data) => {
//   // console.log('allStat', data)
// });

export default socket;
