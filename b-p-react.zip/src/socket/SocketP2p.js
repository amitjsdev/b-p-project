import { P2P_SOCKET_URL } from "../constant";
import io from "socket.io-client";
const socket_p2p = io.connect(P2P_SOCKET_URL, {
  path: "/ptp-socket",
  reconnect: true,
  transports: ["websocket"],
});

console.log("Socket_p2p", socket_p2p);
socket_p2p.on("joined", () => {
  console.log("**Socket joined successfully");
});





//"39e42664-d27a-11eb-8272-029184833070" //buyer
//"cb62fac8-c1d9-11eb-8272-029184833070" // seller

export default socket_p2p;
