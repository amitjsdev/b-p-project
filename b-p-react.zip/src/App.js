import "./App.css";
import "./styles.scss";
import { Provider } from "react-redux";
import configureStore from "./redux/store";
import { BrowserRouter } from "react-router-dom";
import { PersistGate } from "redux-persist/lib/integration/react";

import Application from "./Application";
let { store, persistor } = configureStore();

function App() {
  return (
    // <Application/>
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <Application />
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
}
export const storeInstance = store;
export default App;
