import { SMALLESTUNIT, totallimit } from "../constant";
var BigNumber = require("big-number");

export const getFormatedCountries = (counties) => {
  let result = [];
  try {
    counties.forEach((item) => {
      result.push({
        key: item.code,
        value: item.name,
        label: item.name,
      });
    });
    return result;
  } catch (err) {
    return result;
  }
};

export const smallestunitFormat = (value, args, limit) => {
  value = parseFloat(value);
  if (value > 0 && value < 1) {
    args = 8;
  }
  if (value <= 0) {
    value = "0.0";
  } else {
    let firstBlncTest = String(value).split(".", 2);
    if (firstBlncTest.length > 1) {
      if (firstBlncTest[1].length > args) {
        let presc3 = firstBlncTest[1].substring(0, args);
        value = firstBlncTest[0] + "." + presc3;
        if (value <= 0) value = "0.0";
      }
    }
  }

  if (limit) {
    value = value / totallimit;
  } else {
    value = value / SMALLESTUNIT;
  }
  value = convertExponentialToDecimal(value);
  if (!!value && value > 0){
    // string.indexOf(".") == -1
    let resultVal;
    if(value.toString().indexOf(".") != -1){
       resultVal = value.toString().split('.')[1]
    }else{
       resultVal = '';
    }
    
    if (!!resultVal && resultVal.length > 8) {
      return parseFloat(value).toFixed(8);
    } else {
      return value;
    }
  }else{
    return value;
  }
  
};

export const caseTitle = (value) => {
  if (value.toLowerCase() == "fxt" || value.toLowerCase() == "usdt")
    return value.toUpperCase();
  let first = value.substr(0, 1).toUpperCase();
  return first + value.substr(1).toLowerCase();
};

export const convertExponentialToDecimal = (exponentialNumber) => {
  const str = exponentialNumber.toString();
  if (str.indexOf("e") !== -1) {
    const exponent = parseInt(str.split("-")[1], 18);
    const result = exponentialNumber.toFixed(20);

    return result;
  } else {
    return exponentialNumber;
  }
};

// <----------------------------------DIGIT--------------------------------------------------------------------
export const digitFormat = (value, args = 2) => {
  let getNum = value;

  let newval = convertExponentialToDecimalDigit(getNum);
  return toFixedTrunc(newval, args);
};
export const toFixedTrunc = (value, n) => {
  const v = value.toString().split(".");
  if (n <= 0) return v[0];
  let f = v[1] || "";
  if (f.length > n) return `${v[0]}.${f.substr(0, n)}`;
  while (f.length < 2) f += "0";
  return `${v[0]}.${f}`;
};

export const convertExponentialToDecimalDigit = (exponentialNumber) => {
  // sanity check - is it exponential number
  const str = exponentialNumber.toString();

  if (str.indexOf("e") !== -1) {
    const exponent = parseInt(str.split("-")[1], 10);
    // Unfortunately I can not return 1e-8 as 0.00000001, because even if I call parseFloat() on it,
    // it will still return the exponential representation
    // So I have to use .toFixed()

    const result = exponentialNumber.toFixed(exponent);
    return result;
  } else {
    return exponentialNumber;
  }
};
//  ------------------------------------------digit end--------------------------------------

export const bn_operations = (firstNum, secondNum, operation) => {
  const a = new BigNumber(firstNum.toFixed());
  const b = new BigNumber(secondNum);

  // alert(new BigNumber(b));

  switch (operation.toLowerCase()) {
    case "-":
      return a.minus(b).toString();

    case "+":
      return a.plus(b).toString();

    case "*":
    case "x":
      return a.multipliedBy(b).toString();

    case "÷":
    case "/":
      return a.dividedBy(b).toString();

    case ">=":
      return a.isGreaterThanOrEqualTo(b);

    case ">":
      return a.isGreaterThan(b);

    case "<=":
      return a.isLessThanOrEqualTo(b);

    case "<":
      return a.isLessThan(b);

    case "==":
      return a.isEqualTo(b);

    default:
  }
};

export const appEightDecimalDirective = (event) => {
  var specialKeys = ["Backspace", "Tab", "End", "Home", "-"];

  if (
    specialKeys.indexOf(event.key) !== -1 ||
    (event.key === "c" && event.ctrlKey === true) ||
    (event.key === "v" && event.ctrlKey === true)
  ) {
    return;
  }
  let current = this.el.nativeElement.value;
  let next = current.concat(event.key);
  if (next && !String(next).match(this.regex)) {
    event.preventDefault();
  }
};

export const listDateFormat = (date) => {
  let newDAte = new Date(date);
  let parsedDate = newDAte.toLocaleDateString("default", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
  let time = newDAte.toLocaleTimeString("default", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
  });
  return parsedDate + " " + time;
};

export const pairSwap = (value) => {
  let stringToSplit = value;
  if (stringToSplit.indexOf("-") > -1) {
    var x = stringToSplit.split("-");
  } else {
    var x = stringToSplit.split("_");
  }
  var retVal = "" + x[1] + "/" + x[0] + "";
  return retVal;
};

export const listTimeFormat = (date) => {
  let newDAte = new Date(date);
  let time = newDAte.toLocaleTimeString("default", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  return time;
};

export const pairDiff = (value) => {
  let stringToSplit = value;
  if (stringToSplit.indexOf("-") > -1) {
    var x = stringToSplit.split("-");
  } else {
    var x = stringToSplit.split("_");
  }
  var retVal = x[1];
  var retVal2 = x[0];
  return (
    <div>
      <p>{retVal2?.toUpperCase()}</p>
      <br />
      <p>{retVal?.toUpperCase()}</p>
    </div>
  );
};

export const justPairSwap = (value) => {
  let stringToSplit = value;
  if (stringToSplit) {
    if (stringToSplit?.indexOf("-") > -1) {
      var x = stringToSplit?.split("-");
    } else {
      var x = stringToSplit?.split("_");
    }
    var retVal = "" + x[1] + "-" + x[0] + "";
    return retVal;
  }
};
