import React, { useState } from 'react'

import { Form } from 'react-bootstrap';
import btc from '../../assets/images/icon_btc.png'
import eth from '../../assets/images/eth_icon.png'
import bch from "../../assets/images/icon_bch.png"
import './InputCustomStyle.scss'

const SelectToken = props => {
    const getCoinSymbol = () => {
        for(var i=0;i<props.options.length;i++){
            if(props.options[i].symbol==props.coin){
                return props.options[i].image
            }
        }
    }

    return (
        <Form.Group className="select_token_style" controlId={props.controlId}>
            <div>
                {props.coin !== "" && (
                    <span className="select-token__icon">
                        <img alt={props.coin} src={getCoinSymbol()} />
                    </span>
                )}
                <Form.Control style={{ cursor: "pointer" }} defaultValue={props.defaultValue} value={props.defaultValue} onChange={(e) => props.onSelect(e.target.value)} className="select_token_option_style" as="select">
                   
                    {props.defaultValue == "" && <option value={props.value}>{props.placeholder}</option>}

                    {props.options.map((coins, index) => (
                        <option key={index} value={coins.symbol}>{coins.symbol.toUpperCase()}</option>
                    ))}
                </Form.Control>
            </div>
        </Form.Group>
    )
}

export default SelectToken;
