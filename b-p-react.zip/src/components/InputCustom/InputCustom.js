
import { Form } from 'react-bootstrap';
// import './InputCustomStyle.scss'

const InputCustom = props => {
    return(
        <Form.Group className={`customInput ${props.className}`}  controlId={props.controlId}>
            <Form.Label>{props.label}</Form.Label>
            <Form.Control 
                disabled={props.disabled}
                type={props.type} 
                value={props.value}
                placeholder={props.placeholder} 
                onBlur={props.onBlur}
                onChange={(e)=>props.onChange(e.target.value)}
                value={props.value}
                maxLength={props.maxLength? props.maxLength:""}
            />  
            {props.children}          
        </Form.Group>
    )
}
export default InputCustom