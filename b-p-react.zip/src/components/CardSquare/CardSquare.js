import { Col } from 'react-bootstrap';
import './CardSquareStyle.scss'

const CardSquare = props => {
    return(
        <Col className={`cardStyle ${props.className}`}>{props.children}</Col>
    )
}
export default CardSquare
