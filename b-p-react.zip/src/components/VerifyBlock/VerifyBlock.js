// import './VerifyBlockStyle.scss'
import { Link} from 'react-router-dom'
import cancel from '../../assets/images/crossBtn.png'

const VerifyBlock = props => {
    return(
        <div className="verifyBlock_style">
            <Link className={`close_btn ${props.hideCloseBtn}`} to="/auth/profile" ><img src={cancel} /></Link>
            <img src={props.icon} />
            <h2 className={props.verifyBlockTitle}>{props.title}</h2>
            <p className={props.subtitlestyle}>{props.subTitle}</p>
            {props.children}
        </div>
    )

}

export default VerifyBlock