import { Modal } from "react-bootstrap";
import ButtonPrimary from "../ButtonPrimary/ButtonPrimary";
import "./index.scss";

const ImageModal = (props) => {
  return (
    <Modal
      show={props.show}
      onHide={props.handleClose}
      className={`imageModalDiv modal_style ${props.className} `}
      size={props.size}
      centered
    >
      <Modal.Header>
        {/* <Modal.Title>{props.Title}</Modal.Title> */}
      </Modal.Header>
      <Modal.Body>{props.children}</Modal.Body>
      <Modal.Footer>
        <ButtonPrimary
          onClick={props.handleClose}
          buttontext="close"
          className="internalComn_btn"
        />
      </Modal.Footer>
    </Modal>
  );
};

export default ImageModal;
