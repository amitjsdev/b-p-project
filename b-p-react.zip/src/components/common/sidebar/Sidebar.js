import React from "react";
import { Link } from "react-router-dom";
import SidebarLogo from "../../../theme/images/MobLogo.svg";
import "./SidebarStyle.scss";
import { useLocation } from "react-router-dom";

function Sidebar() {
  const location = useLocation();

  const { pathname } = location;
  const splitLocation = pathname.split("/");

  return (
    <div className="sidebar_Style">
      <ul>
        <li className="sidebar_Logo">
          <a href="/"><img src={SidebarLogo} /></a>
        </li>
        <li>
          <Link title="My exchange" to="/my-exchange/usdt_eth" className={splitLocation[1] == 'my-exchange' ? `exchangeIcon is_Active` : 'exchangeIcon'} />
        </li>
        <li>
          <Link title="Dashboard" to="/auth/dashboard" className={splitLocation[2] == 'dashboard' ? `dashboardIcon is_Active` : 'dashboardIcon'} />
        </li>
        <li>
          <Link title="Orders" to="/auth/orders" className={splitLocation[2] == 'orders' ? `orderIcon is_Active` : 'orderIcon'} />
        </li>
        <li>
          <Link title="Wallet" to="/auth/wallet" className={splitLocation[2] == 'wallet' || splitLocation[2] == 'deposit' ? `walletIcon is_Active` : 'walletIcon'} />
        </li>
        <li>
          <Link title="Swap" to="/auth/swap" className={splitLocation[2] == 'swap' ? `swapIcon is_Active` : 'swapIcon'} />
        </li>
        <li>
          <Link title="Profile" to="/auth/profile" className={splitLocation[2] == 'profile' ? `userIcon is_Active` : 'userIcon'} />
        </li>
        <li>
          <Link title="Setting" to="/auth/setting" className={splitLocation[2] == 'setting' || splitLocation[2].includes('kyc')  || splitLocation[2] == 'password-reset' || splitLocation[2] == 'authentication' || splitLocation[2] ==  'device-management' ? `settingIcon is_Active` : 'settingIcon'} />
        </li>
        <li>
          <Link title="Notification" to="/auth/notification" className={splitLocation[2] == 'notification' ? `notificationIcon is_Active` : 'notificationIcon'} />
        </li>
      </ul>
      <div className="sidebarCopyrightDiv">
        <p className="copyrightText">
          ©2021
          <br />
          BitBubble
        </p>
      </div>
    </div>
  );
}

export default Sidebar;
