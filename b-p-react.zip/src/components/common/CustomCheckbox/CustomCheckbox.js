import React from "react";
import { Form } from "react-bootstrap";
import "./CustomCheckbox.scss"

function CustomCheckbox(props) {
  return (
    <>
            {/* <Form.Check.Label>{props.label}</Form.Check.Label> */}

      <Form.Check type="checkbox" name="checkbox" className={`form-check ${props.className}`}>
        <Form.Check.Input onClick={props.onClick} value={props.value} type="checkbox" name="checkbox" required={true} />
        <Form.Check.Label>{props.label}</Form.Check.Label>
      </Form.Check>
    </>
  );
}

export default CustomCheckbox;
