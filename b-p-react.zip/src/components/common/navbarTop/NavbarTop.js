import React from "react";
import { Navbar, Container, Nav, Badge } from "react-bootstrap";
import { NavLink, Link } from "react-router-dom";
import BitBubble_logo from "../../../theme/images/BitBubblePng.png";
import MObLogo from "../../../theme/images/MobLogo.svg";
import "./NavbarStyle.scss";
import { useLocation } from "react-router-dom";

const NavbarTop = () => {
  const location = useLocation();

  const { pathname } = location;
  const splitLocation = pathname.split("/");
  return (
    <Navbar collapseOnSelect expand="lg" variant="dark">
      <Container fluid>
        <Navbar.Brand href="/">
          <img className="fullscreenImg" src={BitBubble_logo} />
          <img src={MObLogo} className="mobLogo" />
        </Navbar.Brand>
        {/* <Navbar.Toggle aria-controls="responsive-navbar-nav" /> */}
        <div className="navTopDiv">
          <div className="ButtonsDiv">
            {/* <button >Login</button> */}
            <Link to="/login" className={splitLocation[1] == 'login' || splitLocation[1] == '' ? `LoginBtn commonBtns is_Active` : 'LoginBtn commonBtns'}>
            Sign in
            </Link>
            <Link to="/signup" className={splitLocation[1] == 'signup' ? `SignupBtn commonBtns is_Active` : 'SignupBtn commonBtns'}>
              Sign up
            </Link>
            {/* <button className="SignupBtn commonBtns">Signup</button> */}
          </div>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />

          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto"></Nav>
            <Nav>
              <NavLink
               to={`/my-exchange/usdt_eth`}
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Exchange
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Markets
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Service Swap
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Merchant Solution
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Fiat on Ramp
              </NavLink>
            </Nav>
          </Navbar.Collapse>
        </div>
      </Container>
    </Navbar>
  );
};

export default NavbarTop;
