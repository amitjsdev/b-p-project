import React, { useState, useRef } from "react";
import { Col, Overlay, Tooltip } from "react-bootstrap";
import MozillaIcon from "../../../theme/images/mozilla_icon.svg";
import Chrome from "../../../theme/images/chrome.svg";
import Sfari from "../../../theme/images/safari.svg";
import OtherIcon from "../../../theme/images/microsoft-edge.svg";
import "./DeviceCard.scss";
import moment from "moment";
function DeviceCard(props) {
  const [show, setShow] = useState(false);
  const target = useRef(null);
  return (
    <Col className="deviceCard_Style" xs={12} sm={12} md={6} lg={4} xl={4}>
      <div className="imageDiv">
        <img src={props.icon} alt={props.alt} />
        {/* <button ref={target} onClick={() => setShow(!show)}>
          {props.iconsecond ? (
            <img
              src={props.iconsecond}
              alt={props.alt}
              className="securityIcon"
            />
          ) : null}
          {props.iconsecondLite ? (
            <img
              src={props.iconsecondLite}
              alt={props.alt}
              className="securityIcon_lite"
            />
          ) : null}
        </button> */}

        {/* <Overlay target={target.current} show={show} placement="bottom">
          {(props) => (
            <Tooltip
              id="overlay-example"
              {...props}
              className="customTooltip_Style"
            >
              <a>Rename</a>
              <a>Delete</a>
            </Tooltip>
          )}
        </Overlay> */}
      </div>
      <div className="deviceDetail">
        <p>
          Device - <span>{props.device}</span>
        </p>
        <p>
          IP Address - {props.ip} 
          {/* | {props.location} */}
        </p>
        <p className="statusText">
          <img src={props.browser.split(' ')[0] == 'Chrome' ? Chrome :
                  props.browser.split(' ')[0] == 'Firefox' ? MozillaIcon:
                  props.browser.split(' ')[0] == 'Safari' ? Sfari :
                  OtherIcon
                }/> {props.browser} <span>{props.status}</span>
        </p>
        {props.activeStatus == 0 && 
        <p>Last Login - <span>{moment(props.loginDate).format('MMM DD YY, h:mm:ss a')}</span></p>
        }     
      </div>
    </Col>
  );
}

export default DeviceCard;
