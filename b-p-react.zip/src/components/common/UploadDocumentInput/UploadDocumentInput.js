import React, { useState } from "react";
import "./UploadDocumentInput.scss";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import {
  removeKycDoc,
  saveKycFormData,
  getImageBuffer,
} from "../../../redux/actions/SecurityActions";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import ImageModal from "../../../components/common/ImageModal";
import CheckedIcon from "../../../theme/images/checked.png";

function UploadDocumentInput(props) {
  const [previewImg, setPreviewImg] = useState("");
  const [showModal, setShowModal] = useState(false);

  const onDeleteDoc = (id) => {
    let data = {
      fileId: id,
    };
    props
      .removeKycDoc(data)
      .then((res) => {
        props.saveKycFormData({ prop: props.type, value: "" });
      })
      .catch((error) => {});
  };

  const handleClose = () => {
    setShowModal(false);
  };

  const handlePreview = (path) => {
    props.getImageBuffer({ fileUrl: path }).then((res) => {
      setPreviewImg(res);
      setShowModal(true);
    });
  };
  return (
    <>
      <h2 className="upload_file__header">{props.label}</h2>
      {props.isDoc == "" && (
        <div className="upload_file">
          <div className="upload_file__container">
            <input
              type="file"
              onChange={(e) => props.onChange(e)}
              required={!props.isDoc}
            />
            <span className="upload_file__container">
              <img src={props.icon} className="upload_doc" />
              <img src={props.iconLight} className="upload_doc_light" />
              {props.isDoc == "" ||
                (props.isDoc == undefined && <h3>Select File</h3>)}
            </span>
          </div>
        </div>
      )}

      {props.isDoc != "" && (
        <div className="document_upload_successfully">
          <h3>Document uploaded successfully</h3>
          <img src={CheckedIcon} alt="check icon" />
          <div className="uploadDoc_btn">
            <button className="editFile_btn">
              <input
                onChange={(e) => {
                  props.removeKycDoc({ fileId: props.isDoc });
                  props.onChange(e);
                }}
                required={!props.isDoc}
                type="file"
              />
              Edit
            </button>
            <button
              onClick={() => {
                handlePreview(props.docPath);
              }}
              type="button"
              className="change_btn mb-0 doc"
            >
              Preview
            </button>
          </div>
        </div>
      )}

      {/* {props.isDoc == "" && <div>nofile</div>}

      {props.isDoc != "" && <div>file</div>}
      <h2 className="upload_file__header">{props.label}</h2>
      <div className="upload_file">
        <div className="upload_file__container">
          <input
            type="file"
            onChange={(e) => props.onChange(e)}
            required={!props.isDoc}
          />
          <span className="upload_file__container">
            <img src={props.icon} className="upload_doc" />
            <img src={props.iconLight} className="upload_doc_light" />
            {props.isDoc == "" && <h3>Select File</h3>}

            {props.isDoc != "" && (
              <div className="document_upload_successfully">
                <h3>Document uploaded successfully</h3>
                <div className="uploadDoc_btn">
                  <button type="button" className="change_btn mb-0 doc">
                    Edit
                  </button>
                
                </div>
              </div>
            )}
          </span>
        </div>
      </div>
      {/* <a href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==" class="contact100-form-btn" target="_blank">
      Download
    </a> */}

      <ImageModal
        className="imageModal_Design"
        show={showModal}
        handleClose={handleClose}
        Title={``}
        size="lg"
      >
        <img src={`data:image/jpg;base64,${previewImg}`} />
      </ImageModal>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    doc_type: state.security.doc_type,
    doc_front: state.security.doc_front,
    doc_back: state.security.doc_back,
    national_id: state.security.national_id,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    removeKycDoc: (data) => dispatch(removeKycDoc(data)),
    saveKycFormData: (data) => dispatch(saveKycFormData(data)),
    getImageBuffer: (data) => dispatch(getImageBuffer(data)),
  };
};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(UploadDocumentInput)
);
