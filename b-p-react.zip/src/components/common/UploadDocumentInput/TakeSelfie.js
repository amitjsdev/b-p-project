import React from "react";
import "./UploadDocumentInput.scss";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import Webcam from "react-webcam";
import ButtonCustom from "../../ButtonCustom/ButtonCustom";
import {
  saveKycFormData,
  uploadRawFileSelfie,
  removeKycDoc,
  removeSelfieDoc,
  getImageBuffer,
} from "../../../redux/actions/SecurityActions";
import ImageModal from "../ImageModal";
import CheckedIcon from "../../../theme/images/checked.png";

function TakeSelfie(props) {
  const [previewImg, setPreviewImg] = React.useState("");
  const [showModal, setShowModal] = React.useState(false);
  const [webcamEnabled, setWebcamEnabled] = React.useState(false);
  const [enableBtn, setEnableBtn] = React.useState(false);

  const handleClose = () => {
    setShowModal(false);
  };

  const handlePreview = (path) => {
    props.getImageBuffer({ fileUrl: path }).then((res) => {
      setPreviewImg(res);
      setShowModal(true);
    });
  };

  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: "user",
  };

  const webcamRef = React.useRef(null);
  navigator.getMedia =
    navigator.getUserMedia || // use the proper vendor prefix
    navigator.webkitGetUserMedia ||
    navigator.mozGetUserMedia ||
    navigator.msGetUserMedia;

  const capture = React.useCallback(() => {
    navigator.getMedia(
      { video: true },
      function () {
        if (!enableBtn) {
          const imageSrc = webcamRef.current.getScreenshot();

          setWebcamEnabled(false);
          const base64 = imageSrc; // Place your base64 url here.
          fetch(base64)
            .then((res) => res.blob())
            .then((blob) => {
              const formData = new FormData();
              const file = new File([blob], "selfie.jpeg");
              formData.append("upload_file", file);
              props
                .uploadRawFileSelfie(formData)
                .then((res) => {
                  let fileId = res.data.data.fileId;
                  let filePath = res.data.data.fullS3FilePath;
                  props.saveKycFormData({ prop: "selfie", value: fileId });
                  props.saveKycFormData({
                    prop: "kyc_selfie_path",
                    value: filePath,
                  });

                  props.setCheckSelfiImg(false);
                })
                .catch((error) => {});
            });
        }
      },
      function () {
        // webcam is not available
      }
    );
  }, [webcamRef]);

  const onCamera = () => {
    props.saveKycFormData({ prop: "kyc_selfie_path", value: "" });
    setWebcamEnabled(true);
  };

  const onDeleteDoc = (id) => {
    let data = {
      fileId: id,
      isSelfie: true,
    };
    props
      .removeSelfieDoc(data)
      .then((res) => {
        props.saveKycFormData({ prop: "selfie", value: "" });
        props.saveKycFormData({ prop: "kyc_selfie_path", value: "" });
      })
      .catch((error) => {});
  };

  navigator.getMedia(
    { video: true },
    function () {
      setEnableBtn(false);
    },
    function () {
      // webcam is not available
      setEnableBtn(true);
    }
  );

  return (
    <>
      <h2 className="upload_file__header">{props.label}</h2>
      {webcamEnabled ? (
        <div className="upload_file">
          <div className="upload_file__container">
            {/* <input type="file" required={true}/> */}
            <Webcam
              audio={false}
              height={720}
              ref={webcamRef}
              screenshotFormat="image/jpeg"
              width={1280}
              videoConstraints={videoConstraints}
            />
            <ButtonCustom
              disabled={enableBtn}
              buttontext="Take photo"
              className="btn_takePhoto"
              onClick={() => capture()}
            />
          </div>
        </div>
      ) : (
        <div className="upload_file">
          {/* <div className="upload_file__container"> */}
          <span
            // onClick={() => {
            //   onCamera();
            // }}
            className="upload_file__container"
          >
            {props.imgUrl == null && (
              <span  
              onClick={() => {
                  onCamera();
                }}
                >
                <img src={props.icon} className="upload_doc" />
                <img src={props.iconLight} className="upload_doc_light" />
                <h3>Take Selfie</h3>
              </span>
            )}

            {props.imgUrl != null &&(
              <div className="document_upload_successfully">
                <h3>Document uploaded successfully</h3>
                <img src={CheckedIcon} alt="check icon" />
                <div className="uploadDoc_btn">
                  <button
                    className="editFile_btn"
                    onClick={() => {
                      props.removeKycDoc({fileId: props.isDoc,isSelfie: true})
                      onCamera();
                    }}
                  >
                    Edit selfie
                  </button>
                  <button
                    onClick={() => {
                      handlePreview(props.imgUrl);
                    }}
                    type="button"
                  >
                    Preview
                  </button>
                </div>
              </div>
            )}
          </span>
          {/* </div> */}
        </div>
      )}

      <ImageModal
        className="imageModal_Design"
        show={showModal}
        handleClose={handleClose}
        Title={``}
        size="lg"
      >
        <img src={`data:image/jpg;base64,${previewImg}`} />
      </ImageModal>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    selfie: state.security.selfie,
    kyc_selfie_path: state.security.kyc_selfie_path,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveKycFormData: (data) => dispatch(saveKycFormData(data)),
    uploadRawFileSelfie: (data) => dispatch(uploadRawFileSelfie(data)),
    removeKycDoc: (data) => dispatch(removeKycDoc(data)),
    removeSelfieDoc: (data) => dispatch(removeSelfieDoc(data)),
    getImageBuffer: (data) => dispatch(getImageBuffer(data)),
  };
};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(TakeSelfie)
);
