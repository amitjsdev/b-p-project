import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "../PhoneInput/PhoneInput.scss";
import Select from "react-select";
import BitcoinIcon from "../../../theme/images/bitcoin.svg";
import UniswapIcon from "../../../theme/images/uniswap.svg";
import DotIcon from "../../../theme/images/dot.svg";
import TronIcon from "../../../theme/images/tron.svg";
import BnbIcon from "../../../theme/images/bnb.svg";
import "./CurrencyInput.scss";

const CurrencyInput = (props) => {
  const {tokenData} = props;
  return (
    <Form.Group className={`customInput ${props.className}`}>
      {props.label ? <Form.Label>{props.label}</Form.Label> : null}
      <div className="comboFieldStyle currencyInput">
        <Form.Control
          type="text"
          name={props.name}
          className="d-flex align-items-center"
          placeholder={props.inputPlaceholder}
          value={props.amountValue}
          onChange={props.handleChange}
        />
        <Select
          options={tokenData}
          defaultValue={props.defaultValue}
          classNamePrefix="react-select"
          placeholder="Select Coin"
          label="deposit"
          value={props.value}
          onChange={(e) => {
            props.handleChangeToken(e);
          }}
        />
      </div>
      {props.children}
    </Form.Group>
  );
};
export default CurrencyInput;
