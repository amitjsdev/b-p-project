import { Navbar, Container, Nav, Badge, NavDropdown } from "react-bootstrap";
import { useEffect, useState } from "react";
import MobLogo from "../../../theme/images/MobLogo.svg";
import "./NavbarAfterlogin.scss";
import { AUTH_TOKEN_KEY } from "../../../constant";

import { removeToken, setLocalStorage } from "../../../Helpers/storageHelper";
import { useHistory } from "react-router-dom";

import { getUserBalance,saveTotalBalance } from "../../../redux/actions/WalletActions";
import { connect } from "react-redux";
import { changeTheme } from "../../../redux/actions/PersistActions";

const NavbarAfterlogin = (props) => {
  const { walletbalance } = props;
  const [day, setDay] = useState(false);
  const [totalValue, setTotalValue] = useState(0.0);

  const history = useHistory();

  let lineChartCurrency = "USD";

  useEffect(async () => {
    props.getUserBalance();
    if (props.theme) {
      setDay(false);

      document.body.classList.add("lightTheme");
      return;
    }
    setDay(true);

    document.body.classList.remove("lightTheme");
  }, [props.theme]);

  useEffect(async () => {
    if (walletbalance.length > 0) {
      getUserBalance();
    }
  }, [walletbalance]);

  const getUserBalance = () => {
    // props.getUserBalance(lineChartCurrency).then((res) => {
    // let resData = walletbalance;
    let sumArray = [];
    walletbalance.forEach((item, i) => {
      let balance = item?.price * (item?.balance / 100000000);
      sumArray.push({ price: balance });
    });

    let totalPrice = sumArray.reduce(function (accumulator, item) {
      return accumulator + item.price;
    }, 0);
    setTotalValue(totalPrice.toFixed(2));
    props.saveTotalBalance(totalPrice.toFixed(2));

    // }).catch((error) => {

    // })
  };

  // useEffect(async () => {
  //   if (!props.theme) {
  //     setDay(true);
  //     document.body.classList.add("lightTheme");
  //     return;
  //   }
  //   setDay(false)
  //   document.body.classList.remove("lightTheme");
  // }, [props.theme]);

  async function toggleTheme(mode) {
    if (mode == "day") {
      props.changeTheme(true);
    } else {
      props.changeTheme(false);
    }
  }
  // async function toggleTheme() {
  //   const theme = await localStorage.getItem("theme");
  //   if (theme === "dark") {
  //     setDay(false);
  //     document.body.classList.remove("lightTheme");
  //     localStorage.removeItem("theme");
  //   } else {
  //     setDay(true);
  //     document.body.classList.add("lightTheme");
  //     localStorage.setItem("theme", "dark");
  //   }
  //   window.location.reload();
  // }

  const loggoutUser = (e) => {
    e.preventDefault();
    localStorage.clear();
    setTimeout(() => {
      removeToken(AUTH_TOKEN_KEY, "", 1);
      setLocalStorage("");
      history.push(`/login`);
    }, 400);
  };

  return (
    <Navbar collapseOnSelect className="navAfter_login">
      <Container fluid>
        <div className="d-flex align-items-center">
          <img src={MobLogo} className="navafterLogin_logo" />
          {/* <p>Profile</p> */}
        </div>

        <div className="userDetail_div">
          <p href="#" className="wallet_Balance">
            {`${totalValue} ${lineChartCurrency}`}
            <span>Wallet Balance</span>
          </p>
          {day ? (
            <a className="sunIcon" onClick={() => toggleTheme("day")}></a>
          ) : (
            <a className="moonIcon" onClick={() => toggleTheme("night")}></a>
          )}

          <NavDropdown
            title={
              !!props?.user_info?.first_name
                ? props?.user_info?.first_name
                : props?.user_info?.email
                ? props?.user_info?.email.split("@")[0]
                : ""
            }
            id="collasible-nav-dropdown"
            className="navDropdown_style"
          >
            <NavDropdown.Item href="/auth/profile">Profile</NavDropdown.Item>
            <NavDropdown.Item href="/auth/setting">Settings</NavDropdown.Item>
            <NavDropdown.Item href="/auth/kycnotsubmit">KYC</NavDropdown.Item>
            <NavDropdown.Item
              onClick={(e) => {
                loggoutUser(e);
              }}
              href="#"
            >
              Logout
            </NavDropdown.Item>
          </NavDropdown>
        </div>
      </Container>
    </Navbar>
  );
};

const mapStateToProps = (state) => {
  return {
    user_info: state.security.userProfile,
    walletbalance: state.walletbalance.walletbalance,
    theme: state.persist.theme,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveTotalBalance: (data)=> dispatch(saveTotalBalance(data)),
    changeTheme: (data) => dispatch(changeTheme(data)),
    getUserBalance: (currency) => dispatch(getUserBalance(currency)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(NavbarAfterlogin);
