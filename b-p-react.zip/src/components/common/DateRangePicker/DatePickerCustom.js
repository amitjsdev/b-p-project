import { Form } from "react-bootstrap";
import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "../CustomInput/CustomInput.scss";
import "react-datepicker/dist/react-datepicker.css";
import "./DatePickerCustom.scss";

const DobCustom = (props) => {
  return (
    <Form.Group
      className={`customInput ${props.className}`}
      controlId={props.controlId}
    >
      <Form.Label>{props.label}</Form.Label>
      <DatePicker
        placeholderText="MM/DD/YYYY - MM/DD/YYYY"
        className="selectDate"
        selectsRange={true}
        startDate={props.startOrderDate}
        endDate={props.endOrderDate}
        onChange={(update) => {
          props.onChange(update);
        }}
      />
    </Form.Group>
  );
};
export default DobCustom;
