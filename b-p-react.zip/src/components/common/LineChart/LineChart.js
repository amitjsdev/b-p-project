import React from "react";
import "react-perfect-scrollbar/dist/css/styles.css";
import { Line } from "react-chartjs-2";
import "./LineChart.scss";


function LineChart(props) {

  const { chartData,lastchange } = props

  //line chart start
let date = [];
let coinData = [];
  chartData.forEach(item => {
      
    date.push(item[0])
    coinData.push(item[1])

  })

  const LineChartData = {
    labels: date,

    datasets: [
      {
        data: coinData,
        fill: false,
        backgroundColor: "rgb(63, 191, 63, 0.2)",
        borderColor: lastchange && lastchange.toString().includes('-') ? "#f24423" : '#00be00',
        radius: 0,
      }
    ],

  };
  const options = {
    scales: {
      yAxes: [{
        scaleLabel: {
          display: false
        },
        gridLines: {
          // color: "#fff",  
          display: false
        },
        ticks: {
          display: false // it should work
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: false
        },
        gridLines: {
          // color: "#fff",  
          display: false
        },
        ticks: {
          display: false // it should work
        }
      }],
    },
    legend: {
      display: false
    },
  }

  //line chart end 


  return (

    <Line  height="10px" width="10px" data={LineChartData} options={options} />

  );
}

export default LineChart;
