import React from "react";
import { Row, Col, Card } from "react-bootstrap";
import { useHistory, Link } from "react-router-dom";
import "./CoinCard.scss";
import { Line } from "react-chartjs-2";
import LineChart from "../LineChart/LineChart";

function CoinCard(props) {
  let history = useHistory();
  // const redirect = () => {
  //   // history.push("/auth/deposit");
  //   window.location.replace(`/auth/deposit?getCoin=${props.coin}`);
  // };

  return (
    <Card
      className="coinCard_style walletCoin"
      // onClick={() => {
      //   redirect();
      // }}
    >
      <Card.Body>
        <Row>
          <Col className="coinName_txt">
            <img src={props.icon} />
            {props.name.charAt(0).toUpperCase() +
              props.name.slice(1).toUpperCase()}
          </Col>
          <Col className="text-right coinBalance_txt">
            {props.price}
            <span>
              {" "}
              {props.symbol.charAt(0).toUpperCase() +
                props.symbol.slice(1).toUpperCase()}
            </span>
          </Col>
        </Row>
        <Row>
          <Col>
            {props.graphData && props?.graphData.length > 0 ? (
              <LineChart
                lastchange={props.lastchange}
                chartData={props?.graphData}
              />
            ) : (
              ""
            )}
          </Col>
        </Row>
        <Row className="coinChange_row">
          <Col className="coinChange_detail">{props.date}</Col>
          <Col className="text-right coinChange_detail">{props.lastchange}</Col>
          <Col xs={12} className="bottom_txt">
            <Link to={`/auth/deposit?getCoin=${props?.symbol}`}> Deposit </Link>
            <Link to={`/auth/deposit?getCoin=${props?.symbol}&tab=Withdraw`}> Withdraw </Link>
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}

export default CoinCard;
