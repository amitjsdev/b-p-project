import React from "react";
import { Card, Modal } from "react-bootstrap";
import "./CommonModal.scss";

function CommonModal(props) {
  return (
    <div className="commonModal">
      <Modal
        className={`CommonModal_style ${props.className}`}
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        {props.header ? (
          <Modal.Header
            className={`CommonModal_Header ${props.className}`}
            closeButton
          >
            <Modal.Title className={`CommonModal_Title ${props.className}`}>
              {props.header}
              </Modal.Title>
          </Modal.Header>
        ) : null}
        <Modal.Body className={`CommonModal_Body ${props.className}`}>
          {props.children}
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default CommonModal;
