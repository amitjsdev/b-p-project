import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "./CountryPicker.scss";

const CountryPicker = (props) => {
  return (
    <Form.Group className={`customSelect ${props.className}`}>

      <Form.Label>{props.label}</Form.Label>
      <Form.Control name={props.name}
       onChange={(e) => props.handleChange(e, props.name)} as="select" 
       required={props.name == 'doc_type'  ? false : true}>
           {(!props.defaultValue && props.name == 'country_id' || props.name == 'country') &&
                <option value="">Select Country</option>
              }

          {(!props.defaultValue && props.name == 'currencyPreferences') &&
                <option value="">Select Currency</option>
              }

        {props.countryName && props.countryName.length > 0 && props.countryName.map((item) => {
          return (
            <>
                <option selected={props.defaultValue == item.value ? true : false} value={item.value}>{item.label}</option>
            </>

          )
        })}
        {/* <option>{props.placeholder}</option> */}
      </Form.Control>
      {props.children}
    </Form.Group>
  );
};

export default CountryPicker;
