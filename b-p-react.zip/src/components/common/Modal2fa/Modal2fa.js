import { Row, Modal,Button } from 'react-bootstrap';

import "./Modal2fa.scss";


const Modal2fa = props => {
    return(
      
        <Modal show={props.show} onHide={props.handleClose} className={`modal_style ${props.className}`} size={props.size} centered>
        <Modal.Header closeButton>
          <Modal.Title>{props.Title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{props.children}</Modal.Body>       
      </Modal>
    )
}

export default Modal2fa;