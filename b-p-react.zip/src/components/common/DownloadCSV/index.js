import React from "react";
import { Table, Form, Button, Dropdown } from "react-bootstrap";
import { CSVLink, CSVDownload } from "react-csv";

export default class ImportCsv extends React.Component {
  componentDidMount(props) {
    setTimeout(function () {
      document.getElementById("csvBtn").click();
    }, 2000);
    this.fetchUser();
  }

  fetchUser = () => {
    this.props.emptyData();
  };
  render() {
    let { stateCsvData } = this.props;

    return (
      <>
        {stateCsvData &&
        stateCsvData != undefined &&
        stateCsvData.length > 0 ? (
          <Button variant="white">
            <CSVLink
              id="csvBtn"
              data={
                stateCsvData &&
                stateCsvData != undefined &&
                stateCsvData.length > 0
                  ? stateCsvData
                  : [{}]
              }
              target="_blank"
              filename={`${
                this.props.file_name
                  ? this.props.file_name.replace(" ", "_")
                  : ""
              }_${new Date().toISOString()}.csv`}
              onClick={(event) => {
                return stateCsvData.length > 0 ? true : false;
              }}
            >
              Import as CSV
            </CSVLink>
          </Button>
        ) : (
          ""
        )}
      </>
    );
  }
}
