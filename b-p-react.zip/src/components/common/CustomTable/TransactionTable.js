import React, { useState } from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "./CustomTable.scss";
import moment from "moment";
import Pagination from "react-bootstrap/Pagination";
import ReactPaginate from "react-paginate";

function TransactionTable(props) {
  const { typeVal, setPageVal, getWithdrawDepositTxnHistory } = props;
  const [itemOffset, setItemOffset] = useState(0);
  const columns = [
    {
      dataField: "created_at",
      text: "Time",
      sort: true,
      formatter: (item) => moment(item).format("DD-MMM-YYYY"),
    },
    {
      dataField: "source",
      text: "Type",
      sort: true,
    },
    {
      dataField: "coinName",
      text: "Asset",
    },
    {
      dataField: "amount",
      text: "Amount",
    },
    {
      dataField: "address_to",
      text: "Destination",
    },
    {
      dataField: "tx_id",
      text: "TxID",
    },
    {
      dataField: "status",
      text: "Status",
    },
  ];

  const handlePageClick = (event) => {
    const newPage = event.selected + 1;
    setPageVal(newPage);
    props.getWithdrawDepositTxnHistory(typeVal, newPage);
  };

  return (
    <div className="tableOuter_Div deposit_Table">
      <PerfectScrollbar
      // onScrollY={(container) =>
      //   console.log(`scrolled to: ${container.scrollTop}.`)
      // }
      >
        {props.withdrawHistory != undefined &&
        props.withdrawHistory.length > 0 ? (
          <Table className={`customTable ${props.className}`}>
            <thead>
              <tr>
                <th>Time</th>
                <th>Type</th>
                <th>Asset</th>
                <th>Amount</th>
                <th>Destination</th>
                <th>TxID</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {props.withdrawHistory &&
                props.withdrawHistory.length > 0 &&
                props.withdrawHistory.map((item) => {
                  return (
                    <tr>
                      <td>{moment(item.created_at).format("DD-MMM-YYYY")}</td>
                      <td>{item.source}</td>
                      <td>{props.assetName.toUpperCase()}</td>
                      <td>{(item.amount/100000000).toFixed(4)}</td>
                      <td>{item?.address_to}</td>
                      <td>{item?.tx_id ? item?.tx_id : "-"}</td>
                      <td>
                        {item.status == 0 && item.source == "withdraw"
                          ? "Waiting for admin approval"
                          : item.status == 1 && item.source == "withdraw"
                          ? "Unconfirmed"
                          : item.status == 2 && item.source == "withdraw"
                          ? "Confirmed"
                          : item.status == 3 && item.source == "withdraw"
                          ? "Declined"
                          : item.status == 4 && item.source == "withdraw"
                          ? "Failed"
                          : item.status == 0 && item.source == "deposit"
                          ? "Pending"
                          : item.status == 1 && item.source == "deposit"
                          ? "Unconfirmed"
                          : item.status == 2 && item.source == "deposit"
                          ? "Confirmed"
                          : "Unconfirmed"}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        ) : (
          <Table className={`customTable ${props.className}`}>
            <thead>
              <tr>
                <th>Time</th>
                <th>Type</th>
                <th>Asset</th>
                <th>Amount</th>
                <th>Destination</th>
                <th>TxID</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colSpan="7" className="text-center noTransaction_found">
                  No Transactions Found
                </td>
              </tr>{" "}
            </tbody>
          </Table>
        )}

        {props.withdrawHistoryRecords > 0 && (
          <ReactPaginate
            className="paginationStyle"
            breakLabel="..."
            nextLabel=">"
            onPageChange={handlePageClick}
            pageRangeDisplayed={5}
            // pageCount={100}
            pageCount={Math.ceil(props.withdrawHistoryRecords / 5)}
            previousLabel="<"
            renderOnZeroPageCount={null}
          />
        )}
      </PerfectScrollbar>
    </div>
  );
}

export default TransactionTable;
