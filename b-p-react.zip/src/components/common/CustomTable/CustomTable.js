import React from "react";
import { Table } from "react-bootstrap";
// import BitcoinIcon from "../../../theme/images/bitcoin.svg";
// import UniswapIcon from "../../../theme/images/uniswap.svg";
// import DotIcon from "../../../theme/images/dot.svg";
// import TronIcon from "../../../theme/images/tron.svg";
// import BnbIcon from "../../../theme/images/bnb.svg";
// import GraphGreen from "../../../theme/images/graph_green.svg";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "./CustomTable.scss";
import { Link } from "react-router-dom";
// import { Line } from "react-chartjs-2";
import LineChart from "../LineChart/LineChart";
import { SMALLESTUNIT } from "../../../constant";

function CustomTable(props) {
  const { currency } = props;

  return (
    <PerfectScrollbar
    // onScrollY={(container) =>
    //   console.log(`scrolled to: ${container.scrollTop}.`)
    // }
    >
      <Table className={`customTable ${props.className}`}>
        <thead>
          <tr>
            <th>Asset Name</th>
            <th>Price</th>
            <th>24h Change</th>
            <th>30d Graph</th>
            <th>My Balance(USD)</th>
            <th>My Balance</th>
            <th>Locked Balance</th>
            <th className="linkTo_Wallet">Actions</th>
          </tr>
        </thead>
        <tbody>
          {props.socketData &&
            props.socketData.length > 0 &&
            props.socketData.map((item) => {
              let balance =
                (item?.marketCoinData?.current_price[currency] *
                  item?.coin_balance) /
                SMALLESTUNIT;
              return (
                <tr>
                  <td>
                    <img
                      src={
                        item?.marketCoinData?.images
                          ? item?.marketCoinData?.images["large"]
                          : ""
                      }
                      className="coin_icon"
                    />
                    {item?.coin_name.toUpperCase()}
                  </td>
                  <td>
                    {item?.marketCoinData?.current_price
                      ? props.numberFormat.format(
                          item?.marketCoinData?.current_price[currency],
                          0
                        )
                      : ""}
                  </td>
                  <td
                    className={
                      item?.marketCoinData?.price_change_percentage_24h
                        .toString()
                        .includes("-")
                        ? `inRed`
                        : "inGreen"
                    }
                  >
                    {item?.marketCoinData?.price_change_percentage_24h
                      ? `${item?.marketCoinData?.price_change_percentage_24h.toFixed(
                          2
                        )}%`
                      : ""}
                  </td>
                  <td>
                    {item.marketPrices30d &&
                    item?.marketPrices30d.length > 0 ? (
                      <LineChart
                        lastchange={item?.marketCoinData?.price_change_percentage_24h.toFixed(
                          2
                        )}
                        chartData={item?.marketPrices30d}
                      />
                    ) : (
                      ""
                    )}
                  </td>
                  {/* <td>${item?.coin_Currencybalance}</td> */}
                  <td>${balance.toFixed(2)}</td>
                  <td>
                    {(item?.coin_balance / SMALLESTUNIT)}{" "}
                    {item?.coin_symbol.toUpperCase()}
                  </td>
                  <td>
                    {item?.locked_balance/ SMALLESTUNIT}
                  </td>
                  
                  <td className="linkTo_Wallet">
                    <Link to={`/auth/deposit?getCoin=${item?.coin_symbol}`}>
                      Deposit
                    </Link>
                    <Link
                      to={`/auth/deposit?getCoin=${item?.coin_symbol}&tab=Withdraw`}
                    >
                      Withdraw
                    </Link>
                  </td>
                </tr>
              );
            })}
        </tbody>
        {/* NO RECORD FOUND */}
        {/* <tbody>
          <tr>
            <td colSpan="6" className="text-center noTransaction_found">
              No Transactions Found
            </td>
          </tr>
        </tbody> */}
      </Table>
    </PerfectScrollbar>
  );
}

export default CustomTable;
