import React from "react";
import { Link } from "react-router-dom";
import "./Footer.scss";
import { useLocation } from "react-router-dom";

function Footer() {
  const location = useLocation();

  const { pathname } = location;
  const splitLocation = pathname.split("/");
  return (
    <div className="FooterOuter">
      <div className="footerDiv">
        <div className="copyrightDiv">
          <p className="copyrightText">{splitLocation[1] == 'my-exchange' ? '' : `©2021Bitbubble`}</p>
        </div>
        <div className="linksDiv">
          <Link to="/" className="linksText">
            Privacy Policy
          </Link>
          <span className="spaceLine">-</span>
          <Link to="/" className="linksText">
            Terms & Conditions
          </Link>
          <span className="spaceLine">-</span>
          <Link to="/" className="linksText">
            Faq
          </Link>
          <span className="spaceLine">-</span>
          <Link to="/" className="linksText">
            Contact us
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Footer;
