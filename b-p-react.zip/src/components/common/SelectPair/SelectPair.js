import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "./SelectPair.scss";

function SelectPair(props) {
  const { pairList,handleChange,name,selectedVal } = props;
  return (
    <Form.Group className="customSelect pairSelect">
      {props.label ? <Form.Label>{props.label}</Form.Label> : null}
      {name == 'swapPair' ? 
      <Form.Control name={name} onChange={props.handleChangeSwapPair} as="select">
        <option>{props.placeholder}</option>
        {pairList &&
          pairList.length > 0 &&
          pairList.map((item) => {
            return <option selected={selectedVal == item?.symbol} >{item?.symbol}</option>;
          })}
      </Form.Control>
      : 
      <Form.Control name={name} onChange={handleChange} as="select">
      <option value="all">{props.placeholder}</option>
      {pairList &&
        pairList.length > 0 &&
        pairList.map((item) => {
          return <option selected={selectedVal == item?.pair_name} >{item?.pair_name}</option>;
        })}
    </Form.Control>
      }
      {props.children}
    </Form.Group>
  );
}

export default SelectPair;
