import React from "react";
import "./ButtonPrimary.scss";

function ButtonPrimary(props) {
  return (
    <button
      disabled={props.disabled}
      type={props.type}
      block
      onClick={props.onClick}
      className={`commonBtn_style ${props.className}`}
    >
      {props.buttontext}
    </button>
  );
}
export default ButtonPrimary;
