import React from "react";
import { Form } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "../CustomInput/CustomInput.scss";
import "react-datepicker/dist/react-datepicker.css";
import "./DatePickerCustom.scss";

function DatePickerCustom(props) {
  return (
    <>
      <Form.Group
        className={`customInput ${props.className}`}
        controlId={props.controlId}
      >
        <Form.Label>{props.label}</Form.Label>
        <DatePicker
          showMonthDropdown
          showYearDropdown
          selected={props.startDate ? new Date(props.startDate) : ""}
          className={`form-control ${props.className}`}
          placeholderText={props.placeholderText}
          onChange={(date) => {
            props.handleChange(date, props.name);
          }}
          required={true}
        />
        {props.children}
      </Form.Group>
    </>
  );
}

export default DatePickerCustom;
