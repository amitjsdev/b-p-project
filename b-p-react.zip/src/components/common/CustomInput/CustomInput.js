import React from "react";
import { Form } from "react-bootstrap";
import "./CustomInput.scss";

function CustomInput(props) {
  return (
    <>
      {/* onChange={(e)=>{handleChange(e,'password')}} */}
      <Form.Group
        className={`customInput ${props.className}`}
        controlId={props.controlId}
      >
        {props.label ? <Form.Label>{props.label}</Form.Label> : null}
        {props.name === 'email' ?
          <Form.Control
            disabled={props.disabled}
            type={props.type}
            value={props.value}
            placeholder={props.placeholder}
            required={props.referralId ? false : true}
            onChange={(e) => props.handleChange(e, props.name)}
            onBlur={() => { props.checkEmailExist(props.value) }}
          />
          :

          props.name === 'password' || props.name === 'new_password' ?
            <Form.Control
              disabled={props.disabled}
              type={props.type}
              value={props.value}
              placeholder={props.placeholder}
              required={props.referralId ? false : true}
              onChange={(e) => { props.handleChange(e, props.name)
                props.checkPassword(e, props.name)  }}
              onBlur={(e) => { props.checkPassword(e, props.name) }}

            />
            :
            <Form.Control
              defaultValue={props.defaultValue}
              name={props.name}
              disabled={props.disabled}
              type={props.type}
              value={props.value}
              placeholder={props.placeholder}
              required={props.referralId ? false : true}
              onChange={(e) => { props.handleChange(e, props.name) }}
              onBlur={props.onBlur}

            />

        }

        {props.children}
      </Form.Group>
    </>
  );
}

export default CustomInput;
